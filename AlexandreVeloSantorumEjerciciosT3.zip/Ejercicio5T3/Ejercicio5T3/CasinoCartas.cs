﻿using System;
using System.Collections.Generic;
using System.Text;
using CasinoInterfaz;

namespace CasinoCartasClase
{
    class CasinoCartas : ICasino
    {
        public string resolverCasino()
        {
            Random rn = new Random();
            return (rn.Next(1, 13).ToString());
        }

        public int jugar(string apuestaUsuario, string cantidad)
        {
            string resultado = resolverCasino();
            Console.WriteLine("La carta correcta es " + resultado);
            if(apuestaUsuario == resultado)
            {
                Console.WriteLine("Has acertado tú apuesta en las cartas");
                return Int32.Parse(cantidad) * 3;
            }
            else
            {
                return -Int32.Parse(cantidad);
            }
        }
    }
}
