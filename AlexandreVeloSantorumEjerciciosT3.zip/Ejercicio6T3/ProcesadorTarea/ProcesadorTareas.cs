﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Consola   
{
    public class ProcesadorTareas
    {
        Tarea t = new Tarea();
        Usuario u = new Usuario();
        TareaViewModel tvm = new TareaViewModel();
        HttpClient client = new HttpClient();
        private async Task Procesar()
        {
            try{

                List<Tarea> tasktLT = await t.procesarTareasNoRealizadas(client);
                Usuario[] tasktUsuario = await u.procesarUsuarios(client);
                tvm.procesarTareas(tasktLT, tasktUsuario);


            }
            catch (IOException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    }

    public class Tarea
    {
        public int UserId { get; set; }
        public int Id { get; set; }
        public string Title { get; set; }
        public bool Completed { get; set; }

        public async Task<List<Tarea>> procesarTareasNoRealizadas(HttpClient client)
        {
            Console.WriteLine("Inicio de procesamiento");
            client = new HttpClient();
            var urlTareas = "https://jsonplaceholder.typicode.com/todos";
            var respuestaTareas = await client.GetAsync(urlTareas);
            respuestaTareas.EnsureSuccessStatusCode();
            var cuerpoRespuestaTareas = await respuestaTareas.Content.ReadAsStringAsync();
            Console.WriteLine(cuerpoRespuestaTareas);

            var tareas = JsonConvert.DeserializeObject<Tarea[]>(cuerpoRespuestaTareas);
            var tareasNoRealizadas = tareas.Where(x => !x.Completed).ToList();

            return tareasNoRealizadas;
        }


    }

    public class Usuario
    {
        public int Id { get; set; }
        public string Nombre { get; set; }

       

        public async Task<Usuario[]> procesarUsuarios(HttpClient client)
        {
            var urlUsuarios = "https://jsonplaceholder.typicode.com/users";
            var respuestaUsuarios = await client.GetAsync(urlUsuarios);
            respuestaUsuarios.EnsureSuccessStatusCode();
            var cuerpoRespuestaUsuarios = await respuestaUsuarios.Content.ReadAsStringAsync();
            Console.WriteLine(cuerpoRespuestaUsuarios);

            var usuarios = JsonConvert.DeserializeObject<Usuario[]>(cuerpoRespuestaUsuarios);

            return usuarios;
        }
    }

    public class TareaViewModel
    {
        public int Id { get; set; }
        public string NombreUsuario { get; set; }
        public string Title { get; set; }

        public void procesarTareas(List<Tarea> tareasNoRealizadas, Usuario[] usuarios)
        {
            Console.WriteLine("Inicio transformación ViewModels");

            var tareasViewModel = new List<TareaViewModel>();
            foreach (var tarea in tareasNoRealizadas)
            {
                var tareaViewModel = new TareaViewModel()
                {
                    Id = tarea.Id,
                    Title = tarea.Title.Trim(),
                    NombreUsuario = usuarios.Where(x => x.Id == tarea.UserId).First().Nombre.Trim()
                };
                tareasViewModel.Add(tareaViewModel);
            }

            Console.WriteLine("Inicio escritura de tareas en archivo");
            using (StreamWriter writetext = new StreamWriter($@"{Directory.GetCurrentDirectory()}\tareas pendientes.txt")) ;
        }
    }

}
