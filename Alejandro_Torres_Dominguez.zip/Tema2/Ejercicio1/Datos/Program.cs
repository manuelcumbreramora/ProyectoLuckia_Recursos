﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public class Dato
    {

        public void procesaDT(string nombre,int edad)
        {
            Console.WriteLine(String.Format("Añadido usuario con los siguientes datos:\nNombre: {0}\nEdad: {1}",nombre,edad));
        }
    }
}
