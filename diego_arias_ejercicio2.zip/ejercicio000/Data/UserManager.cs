﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace DataLayer
{
    public sealed class UserManager
    {
        public const String FILENAME = "ejercio_000.csv";

        private readonly string dir;
        private string filename;
        private string _csvFile;

        private static readonly UserManager instance = new UserManager();

        static UserManager() { }

        private UserManager()
        {
            this.filename = FILENAME;

            string homePath = ((Environment.OSVersion.Platform == PlatformID.Unix) || (Environment.OSVersion.Platform == PlatformID.MacOSX))
                ? Environment.GetEnvironmentVariable("HOME")
                : Environment.ExpandEnvironmentVariables("%HOMEDRIVE%%HOMEPATH%");
            this.dir = homePath;

            this._csvFile = this.dir + Path.DirectorySeparatorChar + this.filename;
        }

        public static UserManager get() 
        {
            return instance;
        }

        public string getDir()
        {
            return this.dir;
        }

        public string getFilename()
        {
            return this.filename;
        }

        public List<User> getAllUsers()
        {
            List<User> allUsers = new List<User>();

            // If the data file does not exist, return an empty list.
            if (File.Exists(this._csvFile))
            {
                string line;
                System.IO.StreamReader file = new System.IO.StreamReader(this._csvFile);
                while ((line = file.ReadLine()) != null)
                {
                    line = line.Trim();
                    if (line.Length == 0)
                    {
                        continue;
                    }

                    string[] _line = line.Split(';');
                    string username = _line[0];
                    string email = _line[1];
                    allUsers.Add(new User(username, email));
                }

                file.Close();
            }

            return allUsers;
        }

        public void addUser(User user)
        {
            // If the file does not exist, first create an empty one.
            if (!File.Exists(this._csvFile))
            {
                using (File.Create(this._csvFile)) { }
            }

            string username = user.getUsername();
            string email = user.getEmail();

            using (StreamWriter sw = File.AppendText(this._csvFile))
            {
                sw.WriteLine(username + ';' + email);
            }
        }
    }
}