﻿using System;
using System.IO;
using System.Diagnostics;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace CargaArchivo
{
    partial class Archivos : ServiceBase
    {
        public Archivos()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            //Entrar en modo depuración, para hacerlo en tiempo de ejecución
            //System.Diagnostics.Debugger.Launch();
            sleep1.Start();
        }

        protected override void OnStop()
        {
            sleep1.Stop();
        }

        //Lanzar y parar el servicio
        internal void lestStartAndStop(string[] args)
        {
            this.OnStart(args);
            Console.ReadLine();
            this.OnStop();
        }

        private void sleep1_Tick(object sender, EventArgs e)
        {
            try
            {
                string rutaEntrada = @"C:\Prueba\";
                string rutaSalida = @"C:\Prueba\copia\";
                DirectoryInfo directorio = new DirectoryInfo(rutaEntrada);
                if (Directory.Exists(rutaEntrada))
                {
                    foreach (var archivo in directorio.GetFiles("*", SearchOption.AllDirectories))
                    {
                        if (File.Exists(rutaSalida + archivo.Name))
                        {
                            File.SetAttributes(rutaEntrada + archivo.Name, FileAttributes.Normal);
                            File.Delete(rutaSalida + archivo.Name);
                        }

                        File.Copy(rutaEntrada + archivo.Name, rutaSalida + archivo.Name);
                        File.SetAttributes(rutaSalida + archivo.Name, FileAttributes.Normal);

                        if (File.Exists(rutaSalida + archivo.Name))
                        {
                            //Cambiar a popUp
                            EventLog.WriteEntry("Listo, archivo copiado!", EventLogEntryType.Information);
                        }
                        else
                        {
                            EventLog.WriteEntry("Error, archivo no copiado!", EventLogEntryType.Information);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                EventLog.WriteEntry(ex.Message, EventLogEntryType.Error);
            }
        }
    }
}
