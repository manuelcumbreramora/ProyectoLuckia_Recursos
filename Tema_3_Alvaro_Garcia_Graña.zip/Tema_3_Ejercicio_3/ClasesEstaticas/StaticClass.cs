﻿using System;

namespace ClasesEstaticas
{
    public static class StaticClass
    {
        public static int refuerzos = 40;

    }
}
