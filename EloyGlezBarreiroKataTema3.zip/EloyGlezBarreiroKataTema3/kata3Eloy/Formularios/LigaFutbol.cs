﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using kata3Eloy;

namespace kata3Eloy.Formularios
{
    public partial class LigaFutbol : Form
    {
        


        public LigaFutbol()
        {
            InitializeComponent();
        }

        private void LigaFutbol_Load(object sender, EventArgs e)
        {

            //Agrego Campos prefefinidos

            dataGridView1.Rows.Add(5);
            dataGridView1.Rows[0].Cells[0].Value = 1;
            dataGridView1.Rows[0].Cells[1].Value = "R.Madrid";
            dataGridView1.Rows[0].Cells[2].Value = "Barcelona";
            dataGridView1.Rows[1].Cells[0].Value = 2;
            dataGridView1.Rows[1].Cells[1].Value = "Sevilla";
            dataGridView1.Rows[1].Cells[2].Value = "Valencia";
            dataGridView1.Rows[2].Cells[0].Value = 3;
            dataGridView1.Rows[2].Cells[1].Value = "Celta";
            dataGridView1.Rows[2].Cells[2].Value = "Betis";
            dataGridView1.Rows[3].Cells[0].Value = 4;
            dataGridView1.Rows[3].Cells[1].Value = "Espanyol";
            dataGridView1.Rows[3].Cells[2].Value = "Getafe";
            dataGridView1.Rows[4].Cells[0].Value = 5;
            dataGridView1.Rows[4].Cells[1].Value = "Atlético M.";
            dataGridView1.Rows[4].Cells[2].Value = "Real Sociedad";
        }

        private void pbvuelta_Click(object sender, EventArgs e)
        {
            this.Hide();

            MenuPrincipal menup = new MenuPrincipal();

            menup.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(tbId.Text)>0 && Convert.ToInt32(tbId.Text)<6) {

                if (rbEquipo1.Checked)
                {
                    HistoricoApuestas.seleccion.Add("tbId");


                    HistoricoApuestas.seleccion.Add(dataGridView1.Rows[Convert.ToInt32(tbId.Text)].Cells[1].Value.ToString());
                }
                else if (rbEquipo2.Checked)
                {
                    HistoricoApuestas.seleccion.Add("tbId");


                    HistoricoApuestas.seleccion.Add(dataGridView1.Rows[Convert.ToInt32(tbId.Text)].Cells[2].Value.ToString());

                }
                //Falta comentar si no se ha elegido equipo
                frmConfirmacion frmc = new frmConfirmacion();
                frmc.ShowDialog();

            }

        }
    }
}
