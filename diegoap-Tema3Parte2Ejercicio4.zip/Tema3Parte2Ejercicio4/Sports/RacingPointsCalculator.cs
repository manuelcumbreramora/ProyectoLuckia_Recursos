﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PointsCalculator
{
    public class RacingPointsCalculator : AbstractPointsCalculator
    {
        public RacingPointsCalculator() : base("racing") { }

        public override float calculatePoints(params string[] args)
        {
            int points;
            if (! int.TryParse(args[0], out points)) {
                return float.MinValue;
            }

            float _points = (points * 1f) / 10f;
            return _points;
        }
    }
}
