﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMonedero
{
    public class Monedero
    {
        private int Saldo;
        private String TipoMoneda;
        
        public Monedero(int saldo)
        {
            Saldo = saldo;
            TipoMoneda = "Euros";
        }

        public bool ComprobarCash()
        {
            bool exitoComprobar= false;
            if (this.Saldo > 0)
            {
                exitoComprobar = true;
                Console.WriteLine("Tiene saldo");
            }
            else
            {
                Console.WriteLine("No tiene saldo");
            }
            return exitoComprobar;
        }
        public int GetCash()
        {
            return this.Saldo;
        }
        public string getTipoMoneda()
        {
            return this.TipoMoneda;
        }
        public void RetirarSaldo(int cashRetirar)
        {
            this.Saldo = this.Saldo - cashRetirar;
        }
        public void SumarSaldo(int cashSumar)
        {

            this.Saldo = this.Saldo + cashSumar;
        }
    }
}
