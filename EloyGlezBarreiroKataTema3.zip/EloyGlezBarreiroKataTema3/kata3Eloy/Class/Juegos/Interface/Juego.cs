﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kata3Eloy
{
    interface Juego
    {

        int resolverEvento();

        void calculaCuota(double importeGanado);

    }
}
