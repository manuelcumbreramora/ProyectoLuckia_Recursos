﻿/*
 * 
 * Kata 3
 * 
 * Usuario por defecto LOGIN: Admin CONTRASEÑA:Admin. Esta habilitada la opcion para registrase
 * Hay eventos disponibles, pero pueden crearse más.
 * No hay apuestas disponibles, es necesario loguearse y apostar.
 * Tras apostar es necesario resolver Eventos
 * Tras resolver eventos es necesario Resolver apuestas, esto añadira el saldo al monedero.
 * 
 * No esta implementado control de valores de entrada.
 * Implementado un control muy simple de sesiones.
 * No implementado control de eventos repetidos. 
 
 */


using PEventos;
using PJugador;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KataTema3
{
    class Program
    {
        static void Main(string[] args)
        {
            String login;
            String contrasena;
            String lectura;
            string lecturaSaldo;
            String lecturaEventos;
            String lecturaNombreEvento;
            String lecturaEquipo1;
            String lecturaEquipo2;
            String lecturaNumParticipantes;
            String lecturaImporte;
            String lecturaResultadoApuesta;
            int lResultadoApuesta;
            int limporte;
            int lNumParticipantes;
            int salir = 99;
            int saldoIni = 0;
            int selectorEventos = 0;
            int sesionIniciada = 0;
            RepositorioJugadores jugadoresDB = new RepositorioJugadores();
            RepositorioEventos eventosDB = new RepositorioEventos();
            EventoFutbol efut1 = new EventoFutbol("Partido Copa", "Real Madrid", "Barcelona");
            EventoFutbol efut2 = new EventoFutbol("Partido Liga", "Villareal", "Atletico de Madrid");
            EventoFutbol efut3 = new EventoFutbol("Partido de Derbi", "Deportivo", "Celta");
            EventoBaloncesto eBal1 = new EventoBaloncesto("Partido ACB", "Compostela", "Boiro");
            EventoBaloncesto eBal2 = new EventoBaloncesto("Partido NBA", "Bulls", "Lakers");
            EventoF1 eCarrera1 = new EventoF1("Campeonato España", 10);
            EventoF1 eCarrera2 = new EventoF1("Campeonato Francia", 20);

            jugadoresDB.InsertarJugador("Admin", "Admin", 1000);
            Jugador jugadorSesion = jugadoresDB.BuscarJugador("Admin");
            
           
        
            eventosDB.InsertarEvento(efut1);            
            eventosDB.InsertarEvento(efut2);          
            eventosDB.InsertarEvento(efut3);          
            eventosDB.InsertarEvento(eBal1);            
            eventosDB.InsertarEvento(eBal2);           
            eventosDB.InsertarEvento(eCarrera1);          
            eventosDB.InsertarEvento(eCarrera2);
      

            while (salir != 0)
            {
                Console.Clear();
                
                if (sesionIniciada == 0)
                {
                    Console.WriteLine("Bienvenido a Luckia (para iniciar sesión sin registrar utilice Login: Admin, Pass:Admin)");
                    Console.WriteLine("1-Loguearse.");
                    Console.WriteLine("2-Registrarse.");
                    Console.WriteLine("3-Añadir eventos(opcion debug)");
                    Console.WriteLine("0- Salir");
                }
                else
                {
                    Console.WriteLine("Bienvenido a Luckia {0}",jugadorSesion.getLogin());
                    Console.WriteLine("3- Añadir eventos(opcion debug)");
                    Console.WriteLine("4- Mostrar Eventos");
                    Console.WriteLine("5- Apostar");
                    Console.WriteLine("6- Resolver Eventos");
                    Console.WriteLine("7- Resolver Apuestas");
                    Console.WriteLine("8- Mostrar Informacion Jugador");
                    Console.WriteLine("9- Mostrar Historial de apuestas de Jugador");
                    Console.WriteLine("0- Salir");
                }
                try
                {
                    lectura = Console.ReadLine();
                    salir = Int32.Parse(lectura);
                    switch (salir)
                    {
                        case 1:
                            Console.WriteLine("Dame el nombre Login: ");
                            login = Console.ReadLine();
                            Console.WriteLine("Dame la contraseña: ");
                            contrasena = Console.ReadLine();
                            if (jugadoresDB.VerificarJugador(login, contrasena)==true)
                            {
                                jugadorSesion = jugadoresDB.BuscarJugador(login);
                                sesionIniciada = 1;
                            }
                            break;

                        case 2:
                           Console.WriteLine("Dame el nombre Login: ");
                            login = Console.ReadLine();
                            Console.WriteLine("Dame la contraseña: ");
                            contrasena = Console.ReadLine();
                            Console.WriteLine("Dame la saldo: ");
                            lecturaSaldo = Console.ReadLine();
                            saldoIni = Int32.Parse(lecturaSaldo);
                            if (jugadoresDB.ComprobarExisteLogin(login) == false)
                            {
                                jugadoresDB.InsertarJugador(login, contrasena, saldoIni);
                                Console.WriteLine("Jugador Creado, ya puede loguearse");
                            }
                            
                            break;
                        case 3:
                            Console.WriteLine("¿Que tipo de Evento desea añadir?");
                            Console.WriteLine("1.Evento de F1");
                            Console.WriteLine("2.Evento de Futbol");
                            Console.WriteLine("3.Evento de Baloncesto");
                            lecturaEventos=Console.ReadLine();
                            selectorEventos = Int32.Parse(lecturaEventos);
                            switch (selectorEventos)
                            {
                                case 1:
                                    Console.WriteLine("Nombre: ");
                                    lecturaNombreEvento = Console.ReadLine();
                                    Console.WriteLine("Numero de Participantes: ");
                                    lecturaNumParticipantes = Console.ReadLine();
                                    lNumParticipantes = Int32.Parse(lecturaNumParticipantes);
                                    EventoF1 eventoNuevoCarrera = new EventoF1(lecturaNombreEvento, lNumParticipantes);
                                    eventosDB.InsertarEvento(eventoNuevoCarrera);
                                    break;
                                case 2:
                                    Console.WriteLine("Dame Nombre: ");
                                    lecturaNombreEvento = Console.ReadLine();
                                    Console.WriteLine("Dame Equipo1: ");
                                   lecturaEquipo1 = Console.ReadLine();
                                    Console.WriteLine("Dame Equipo2: ");
                                   lecturaEquipo2 = Console.ReadLine();
                                    EventoFutbol eventoNuevoF = new EventoFutbol(lecturaNombreEvento, lecturaEquipo1, lecturaEquipo2);
                                    eventosDB.InsertarEvento(eventoNuevoF);
                                    break;
                                case 3:
                                    Console.WriteLine("Nombre: ");
                                    lecturaNombreEvento = Console.ReadLine();
                                    Console.WriteLine("Equipo1: ");
                                    lecturaEquipo1 = Console.ReadLine();
                                    Console.WriteLine("Equipo2: ");
                                    lecturaEquipo2 = Console.ReadLine();
                                    EventoBaloncesto eventoNuevoB = new EventoBaloncesto(lecturaNombreEvento, lecturaEquipo1, lecturaEquipo2);
                                    eventosDB.InsertarEvento(eventoNuevoB);
                                    break;

                            }

                            break;
                        case 4:
                            if (sesionIniciada == 1) {
                            eventosDB.ListarEventos();
                            }
                            else
                            {
                                Console.WriteLine("Debe tener una sesión iniciada para esta opción");
                            }
                            break;
                        case 5:
                            if (sesionIniciada == 1)
                            {
                                
                                Console.WriteLine("Eventos disponibles");
                                Console.WriteLine("...........................");
                                eventosDB.ListarEventos();
                                Console.WriteLine("¿Porque evento quiere apostar (Dame nombre)?");
                                lecturaNombreEvento = Console.ReadLine();
                                Console.WriteLine("¿Cuanta cantidad quiere apostar?");
                                lecturaImporte = Console.ReadLine();
                                limporte = Int32.Parse(lecturaImporte);
                                Console.WriteLine("¿Cual es el resultado?");
                                Console.WriteLine("Para evento Futbol seleccione: 1 para equipo1, 2  para equipo2,3 para empate");
                                Console.WriteLine("Para evento Baloncesto seleccione: 1 para equipo1, 2  para equipo2,3 para empate");
                                Console.WriteLine("Para evento Formula1: 1 a MaximoParticipantes");
                                lecturaResultadoApuesta=Console.ReadLine();
                                lResultadoApuesta = Int32.Parse(lecturaResultadoApuesta);

                                IEventos eveApuesta= eventosDB.BuscarEvento(lecturaNombreEvento);
                                jugadorSesion.CrearApuesta(limporte, eveApuesta, lResultadoApuesta);
                                
   
                            }
                            else
                            {
                                Console.WriteLine("Debe tener una sesión iniciada para esta opción");
                            }

                            break;
                        case 6:
                            if (sesionIniciada == 1)
                            {
                                eventosDB.ResolverEventosPendientes();
                            }
                            else
                            {
                                Console.WriteLine("Debe tener una sesión iniciada para esta opción");
                            }

                            break;
                        case 7:
                            if (sesionIniciada == 1)
                            {
                                jugadorSesion.ResolverApuestas();
                            }
                            else
                            {
                                Console.WriteLine("Debe tener una sesión iniciada para esta opción");
                            }
                            break;
                        case 8:
                            if (sesionIniciada == 1)
                            {
                                jugadorSesion.MostrarJugador();
                            }
                            else
                            {
                                Console.WriteLine("Debe tener una sesión iniciada para esta opción");
                            }
                            break;
                        case 9:
                            if (sesionIniciada == 1)
                            {
                                jugadorSesion.MostrarHistorialApuestas();
                            }
                            else
                            {
                                Console.WriteLine("Debe tener una sesión iniciada para esta opción");
                            }
                            break;


                    }
                }
                catch (FormatException)
                {
                    Console.WriteLine("Introduzca solo numeros");
                    salir = 5;
                }
                Console.WriteLine("Pulse una tecla para volver a menu");
                Console.ReadLine();

            }


           

        }
        

 
    }
}
