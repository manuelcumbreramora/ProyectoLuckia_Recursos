﻿using InterfazTipoJugador;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PJugadorBasico
{
    public class JugadorBasico : IJugador
    {
        public String Nombre;
        public int Edad;
        public Boolean Saldo;
        public JugadorBasico (String nombre, int edad, Boolean saldo)
        {
            Nombre = nombre;
            Edad = edad;
            Saldo = saldo;
        }
        public bool comprobarEdad()
        {
            Boolean mayorE=false;
            if (this.Edad > 17)
            {
                mayorE = true;
                Console.WriteLine("Jugador Basico es Mayor de edad");
            }
            return mayorE;
        }

        public bool Pago()
        {
            Boolean sPago = false;
            if (this.Saldo) { 
            Console.WriteLine("Jugador Basico tiene saldo y  puede pagar");
                sPago = true;
            }
            else
            {
                Console.WriteLine("Jugador Basico NO tiene saldo y NO puede pagar");
            }
            return sPago;
        }
    }
}
