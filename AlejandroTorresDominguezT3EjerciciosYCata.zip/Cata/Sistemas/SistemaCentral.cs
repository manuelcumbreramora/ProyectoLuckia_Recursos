﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cata
{
    class SistemaCentral
    {
        private List<Jugador> jugadoresconapuestas { get; set; }
        public SistemaCentral(List<Jugador> jugador)
        {
            this.jugadoresconapuestas = jugador;
        }

        public void gestionarApuestas()
        {
            foreach (var juga in this.jugadoresconapuestas)
            {
                foreach (var apuesta in juga.listaApuestas)
                {
                    if (comprobarApuesta(apuesta))
                    {
                        juga.monedero.llenarMonedero(new Random().Next(500, 100));
                    }
                }
            }
        }

        public bool comprobarApuesta(Apuesta apuesta)
        {
            apuesta.evento.registrarResultadoFinal(apuesta.evento.resolverEvento());
            return apuesta.evento.devolverResultadFinal() == apuesta.resultadoapostado;
        }
    }
}
