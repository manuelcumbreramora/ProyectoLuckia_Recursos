﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_3
{
    class Profesor:Usuario, INotas
    {
        //Esto esta asi por sencillez, en realidad seria un array de la Clase clases con su campos,....
        private Array asignaturas { get; set; }
        public Profesor(String nombre, string contra,Array asignaturas):base(nombre, contra)
        {
            this.asignaturas = asignaturas;
        }

        public Profesor() 
        {
        }

        public void verNotas(int asignatura)
        {
            Console.WriteLine("Ver las notas de todos los alumnos de una asignatura");
        }
        public override void verNotas()
        {
            Console.WriteLine("Ver las notas de todos los alumnos de todas las asignaturas que tenga asignado");
        }

        public void cargarNotasBBDD()
        {
            Console.WriteLine("Lee las notas de la base de datos  y lo carga en el Array");

        }

        public void cargarNotasFichero()
        {
            Console.WriteLine("Lee las notas de un fichero y lo carga en el array");
        }
        public void ponerNotaFinal()
        {
            double trab, ex, act;
            Console.WriteLine("Escribe nota de los trabajos");
            trab = double.Parse(Console.ReadLine());
            Console.WriteLine("Escribe nota del examen");
            ex = double.Parse(Console.ReadLine());
            Console.WriteLine("Escribe nota de actitud");
            act = double.Parse(Console.ReadLine());
            Funcionalidades.notaFinal(trab, ex, act);
        }
    }
}
