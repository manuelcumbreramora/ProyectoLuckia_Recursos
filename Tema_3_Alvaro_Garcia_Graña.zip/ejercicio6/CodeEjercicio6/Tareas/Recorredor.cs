﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tareas
{
    class Recorredor
    {
        public List<Tarea> tareas { get; set; }
    }
}
