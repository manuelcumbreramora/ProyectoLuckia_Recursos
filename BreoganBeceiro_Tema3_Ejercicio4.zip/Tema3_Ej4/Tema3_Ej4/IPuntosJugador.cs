﻿//BreoBeceiro:24/03/2020
//PLEXUS | Tema3

//El método calculaPuntos() para la clase Futbol se diferencia del otro en que no se calculan los puntos, sino que éstos se
//  obtienen en función de los fallos o aciertos del resultado y de la quiniela. ¿Se podría omitir una de las firmas para 
//  desarrollar el método en la clase Fútbol sin tenerlo definido en la Interfaz?

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ej4
{
    public interface IPuntosJugador
    {
        //Método para Carreras y Atletismo:
        float calculaPuntos(int points);
    }
}
