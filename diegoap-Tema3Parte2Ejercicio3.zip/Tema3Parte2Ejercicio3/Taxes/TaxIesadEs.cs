﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taxes
{
    public class TaxIesadEs : AbstractTax
    {
        public TaxIesadEs() : base("IESAD", "ES", "Impuesto Especial Sobre Apuestas Deportivas") {}

        public override float calculateTax(float amount)
        {
            // If the amount is below 2000 EUR, the tax is 2.5%; else, it is 4.5%.
            float tax = (amount < 2000) ? (amount * 0.025f) : (amount * 0.045f);
            return tax;
        }
    }
}
