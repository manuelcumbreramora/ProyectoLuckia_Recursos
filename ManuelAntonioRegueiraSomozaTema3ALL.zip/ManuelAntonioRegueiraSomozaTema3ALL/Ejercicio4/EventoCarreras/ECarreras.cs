﻿using InterfaceEventos;
using InterfaceSistemaCentral;
using PUtilidadesAleatorias;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventoCarreras
{
    public class ECarreras : IEvento
    {
        private DateTime Fecha;
        private String Nombre;
        private String Pista;
        private int Resultado;

        public ECarreras(String nombreE, String pista)
        {
            Fecha = DateTime.Now;
            Nombre = nombreE;
            Pista = pista;
            Resultado = 0;
        }

        public int GetResultado()
        {
           return this.Resultado;
        }

        public void JugarEvento()
        {
            this.Resultado = FuncionesAleatorias.generarAleatorio();
        }

        public void MostrarEvento()
        {
            Console.WriteLine("Nombre: {0} ", this.Nombre);
            Console.WriteLine("Fecha: {0} ", this.Fecha);
            Console.WriteLine("Pista: {0} ", this.Pista);
            Console.WriteLine("Resultado Actual (en puntos): {0} ", this.Resultado);
        }
    }
}
