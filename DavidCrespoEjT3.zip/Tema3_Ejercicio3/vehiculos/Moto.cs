﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ejercicio3
{
    class Moto:Vehiculo

    {
        public int cilindrada { get; set; }

        public override int generarMatricula()
        {
            var rand = new Random();
            matricula = rand.Next(1000, 9999);
            return matricula;

        }



    }
}
