﻿using EventoAtletismo;
using InterfaceEventos;
using InterfaceSistemaCentral;
using PJugador;
using PUtilidadesAleatorias;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PSistemaApuestaAtletismo
{
    public class ApuestaAtletismo : ISistemaCentral
    {
        public Jugador Player; //Para hacer Private, nesitariamos un metodo que devolviera el los atributos necesarios pero como Tipo base(ejemplo Player.nombre jugador, devolver un string)
        public EAtletismo Evento;
        private DateTime FechaApuesta;
        
        

        public ApuestaAtletismo(Jugador player, EAtletismo evento)
        {
            Player = player;
            Evento = evento;
            FechaApuesta = DateTime.Now;
          
           
        }
        public void JugarApuesta()
        {
            this.Evento.JugarEvento();
            int puntosTotal = this.CalculoPuntos();
            int importe = this.calculoImporte(puntosTotal);
            this.abonarApuesta(importe);

        }
   

        public int CalculoPuntos()
        {
            int puntosTotal = this.Evento.GetResultado() / 2;//cambiar por funcion
            return puntosTotal;
        }

        public int calculoImporte(int puntos)
        {

            return (puntos * 15);
        }

        public void abonarApuesta(int importe)
        {
            this.Player.ModificarMonedero(importe);
        }
        public void mostrarApuesta()
        {
            Console.WriteLine("Apuesta para Evento ");
            Console.WriteLine(".......................");
            this.Evento.MostrarEvento();
            Console.WriteLine("Apostado por el jugador de nombre: {0} ", this.Player.ConsultarNombre());
            Console.WriteLine("En Fecha {0} ", this.FechaApuesta);
        }
        
    }
}
