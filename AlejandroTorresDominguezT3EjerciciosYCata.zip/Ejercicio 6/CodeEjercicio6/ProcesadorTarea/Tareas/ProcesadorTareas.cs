﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;


namespace Consola   
{
    public class ProcesadorTareas
    {
        public async Task<List<Tarea>> Procesar(HttpClient client)
        {
            IOLog.EscribirLog("Inicio de procesamiento de tareas");

            var urlTareas = "https://jsonplaceholder.typicode.com/todos";
            var respuestaTareas = await client.GetAsync(urlTareas);
            respuestaTareas.EnsureSuccessStatusCode();
            var cuerpoRespuestaTareas = await respuestaTareas.Content.ReadAsStringAsync();
            Console.WriteLine(cuerpoRespuestaTareas);

            var tareas = JsonConvert.DeserializeObject<Tarea[]>(cuerpoRespuestaTareas);
            var tareasNoRealizadas = tareas.Where(x => !x.Completed).ToList();
            return tareasNoRealizadas;
        }
    }

    

    

    

}
