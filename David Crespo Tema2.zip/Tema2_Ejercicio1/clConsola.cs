﻿/*Crear solución (proyecto) de consola, con tres proyectos: Consola, Negocio y Datos
Simular un guardado de usuario, donde desde consola se inserten los datos, se pasen a negocio y negocio los pase a 
Datos, que será el que finalmente los guardará*/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Consola
{
    public class clConsola
    {

        public String PasarDatos(String usuario, String DNI, String ciudad)
        {
            return usuario;
            return DNI;
            return ciudad;
        }

        public clConsola ()
        {
        }

        public static void Main(string[] args)
        {
             Console.WriteLine("Introduzca nombre usuario");
                String usuario = Console.ReadLine();
                Console.WriteLine("Introduzca DNI");
                String DNI = Console.ReadLine();
                Console.WriteLine("Introduzca ciudad de nacimiento");
                String ciudad = Console.ReadLine();
                Console.ReadKey();

            clConsola clCon = new clConsola();

            clCon.PasarDatos(usuario, DNI, ciudad);

        }
    }
}
