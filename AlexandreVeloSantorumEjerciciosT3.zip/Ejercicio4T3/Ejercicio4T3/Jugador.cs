﻿using System;
using System.Collections.Generic;
using System.Text;
using SistemaCentralClase;

namespace JugadorClase
{
    class Jugador
    {
        private int Puntos { get; set; }

        public void generarApuesta()
        {
            int puntosGanados;
            puntosGanados = SistemaCentral.generarImporte();
            Puntos += puntosGanados;
            Console.WriteLine("Los puntos ganados son: "+puntosGanados);
            Console.WriteLine("Sumas un total de: "+ Puntos+ " puntos");
        }

    }
}
