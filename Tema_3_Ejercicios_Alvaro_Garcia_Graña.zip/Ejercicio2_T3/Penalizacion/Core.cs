﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Penalizacion
{
    class Core : Penalizador
    {
        static void Main(string[] args)
        {
            String nombre = "", tipo = "";
            Persona persona = new Persona();
            Juego juego = new Juego();
            juego.tipo = new List<String>();
            persona.jugador = new Jugador();
            juego.tipo.Add("Futbol");
            juego.tipo.Add("Balonmano");
            juego.tipo.Add("Voleibol");
            while (persona.nombre == "" || persona.nombre == null)
            {
                Console.WriteLine("Introduzca el nombre del jugador: ");
                nombre = Console.ReadLine();
                if (nombre != "" && nombre != null)
                {
                    persona.registrarPersona(persona, nombre);
                    
                    while (tipo != juego.tipo[0] || tipo != juego.tipo[1] || tipo != juego.tipo[2])
                    {

                        Console.WriteLine("Elige el tipo de Juego (Futbol, Baloncesto, Voleibol)");
                        tipo = Console.ReadLine();
                        if (tipo == juego.tipo[0] || tipo == juego.tipo[1] || tipo == juego.tipo[2])
                        {
                            persona.jugador.penalizar(tipo, juego, persona.jugador);
                            Console.WriteLine("Penalizado el jugador " + persona.nombre + " de " + tipo + ", su saldo actual es " + persona.jugador.monedero.saldo);
                            Console.ReadKey();
                        }
                        else
                        {
                            Console.WriteLine("No existe en nuestras bases de datos el deporte introducido.");
                        }
                    }   
                }
                else
                {
                    Console.WriteLine("Jugador vacio, introduzca un jugador para realizar la solicitud.");
                }
               
            }
            
        }
    }

    class Persona
    {
        public string nombre { get; set; }
        public Jugador jugador { get; set; }

        public void registrarPersona(Persona persona, String nombre)
        {
            persona.nombre = nombre;
        }
    }

    class Juego
    {
        public List<String> tipo { get; set; }
    }

    class Jugador: Penalizador
    {
        public Monedero monedero { get; set; }
    }

    class Monedero
    {
        public int saldo = 100;
    }

    abstract class Penalizador
    {
        public virtual void penalizar(String tipo, Juego juego, Jugador jugador)
        {
            jugador.monedero = new Monedero();
            if (tipo == juego.tipo[0])
            {
                jugador.monedero.saldo = jugador.monedero.saldo - 30;
            }else if (tipo == juego.tipo[1])
            {
                jugador.monedero.saldo = jugador.monedero.saldo - 20;
            }
            else if (tipo == juego.tipo[2])
            {
                jugador.monedero.saldo = jugador.monedero.saldo - 10;
            }
        }
    }

}
