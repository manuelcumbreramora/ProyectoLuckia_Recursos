﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3Ej5
{
    class Casino1 : ICasino
    {
        string nombreCasino = "Casino1";
        public void RealizarJuego()
        {
            Console.WriteLine("Se ha realizado un juego en "+this.nombreCasino);
        }
    }
}
