﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BibliotecaClases
{
    public class Jugador : Persona
    {
        private int Bonus { get; set; }
        private int Juegos { get; set; }
        private int Monedero { get; set; }

        public Jugador(Persona p) : base(p)
        {
            Nombre = p.Nombre;
            Edad = p.Edad;
            Suscripcion = p.Suscripcion;
            Bonus = 0;
            Juegos = 0;
            Monedero = 1000;
        }

        public void apostar(string cantidad)
        {
            if (Suscripcion)
            {
                int juegos = Int32.Parse(cantidad);
                Random rn = new Random();
                Juegos += juegos;
                Bonus = rn.Next(100);
                Monedero = Monedero + (Bonus - juegos);
                Console.WriteLine("Has jugado " + Juegos + " euros y tienes un bonus de " + Bonus);
                Console.WriteLine("Tú monedero es de " + Monedero);
            }
            else
            {
                Console.WriteLine("Tienes que activar tú cuenta para apostar");
            }

        }

        public void Penalizar(int penalizar)
        {
            Monedero = Monedero - penalizar;
        }
    }
}
