﻿using ConsoleApp3;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Consola   
{
    public class ProcesadorTareas
    {

        private String ObtenerNombreUsuario(Usuario[] usuarios, int UserId)
        {
            return usuarios.Where(x => x.Id == UserId).First().Nombre.Trim();
        }

        private List<TareaViewModel> TransformarTareasEnTareasViewModel(Tarea[] tareas, Usuario[] usuarios)
        {
            var tareasViewModel = new List<TareaViewModel>();
            foreach (var tarea in tareas)
            {
                var tareaViewModel = new TareaViewModel()
                {
                    Id = tarea.Id,
                    Title = tarea.Title.Trim(),
                    NombreUsuario = ObtenerNombreUsuario(usuarios, tarea.UserId)
                };
                tareasViewModel.Add(tareaViewModel);
            }
            return tareasViewModel;
        }
        public async Task Procesar(EntradaSalida io, CodificacionDecodificacion codificacion)
        {
            try{


                io.EscribirPantalla("Inicio de procesamiento");


                var cuerpoRespuestaTareas = await io.LeerCadenaClientesAsync();
                io.EscribirPantalla(cuerpoRespuestaTareas);


                var tareas = codificacion.DescodificarTareas(cuerpoRespuestaTareas);

                var tareasNoRealizadas = Tarea.FiltrarRealizadas(tareas);

                var cuerpoRespuestaUsuarios = await io.LeerCadenaUsuariosAsync();
                io.EscribirPantalla(cuerpoRespuestaUsuarios);

                var usuarios = codificacion.DescodificarUsuarios(cuerpoRespuestaUsuarios);

                io.EscribirPantalla("Inicio transformación ViewModels");

                var tareasViewModel = new List<TareaViewModel>();
                tareasViewModel = TransformarTareasEnTareasViewModel(tareas, usuarios);

                io.EscribirPantalla("Inicio escritura de tareas en archivo");
                io.EscribirFichero(codificacion.CodificarTareasViewModel(tareasViewModel));
            }catch (IOException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    }

    public class Tarea
    {
        public int UserId { get; set; }
        public int Id { get; set; }
        public string Title { get; set; }
        public bool Completed { get; set; }

        public static ICollection<Tarea> FiltrarRealizadas(ICollection<Tarea> tareas)
        {
            return tareas.Where(x => !x.Completed).ToList();
        }
    }

    public class Usuario
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
    }

    public class TareaViewModel
    {
        public int Id { get; set; }
        public string NombreUsuario { get; set; }
        public string Title { get; set; }
    }

}
