﻿using InterfazTipoJuego;
using InterfazTipoJugador;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PApuesta
{
    public class ApuestaPremium:Apuesta
    {
        private String Consultor;
        public ApuestaPremium(IJuego juego, IJugador jugador,String consultor)
        {
            Tjuego = juego;
            Tjugador = jugador;
            Consultor = consultor;

        }

      public bool ConsultarApuestaConsultor()
        {
            Random random = new Random();
            int numAleatorio = random.Next(0, 1);
            bool exitoApostar = false;
            if (numAleatorio == 0)
            {
                exitoApostar = true;
                Console.WriteLine("El experto {0} aconseja seguir apostando",this.Consultor);

            }
            else if (numAleatorio==1)
            {
                exitoApostar = false;
                Console.WriteLine("El experto {0} aconseja no seguir apostando", this.Consultor);
            }
            return exitoApostar;

        }


    }
}

