﻿//BreoBeceiro:24/03/2020
//PLEXUS | Tema3

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ej3
{
    public static class DAO
    {
        private const string nombreBBDD = "torneoCartas";
        private const string usuarioBBDD = "admin";
        private const string servidor = "localhost";


        public static void abreConexion()
        {
            try
            {
                //Se prueba la conexión...
            }
            catch(Exception e)
            {
                //Se tratan las excepciones que se puedan producir...
            }
            finally
            {
                //Se devuelve la conexión...
            }
        }

        public static void cierraConexion()
        {
            //Cierra la conexion...
        }

        public static bool registraPuntuacíon()
        {
            DAO.abreConexion();

            //Guarda la puntuación de una partida en la tabla que corresponda de la BBDD...

            DAO.cierraConexion();
            return true;
        }

        public static bool registraJugador(string user, string password)
        {
            DAO.abreConexion();

            //Guarda los datos esenciales del nuevo Jugador en la tabla que corresponda de la BBDD...

            DAO.cierraConexion();
            return true;
        }
    }
}
