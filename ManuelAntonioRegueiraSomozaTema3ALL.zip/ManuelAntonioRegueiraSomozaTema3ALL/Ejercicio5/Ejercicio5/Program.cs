﻿using InterfaceCasino;
using Pjugador;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TCasino1;
using TCasino2;
using TCasino3;

namespace Ejercicio5
{
    class Program
    {
        static void Main(string[] args)
        {

            Casino1 j1 = new Casino1("Tragaperras");
            Casino2 j2 = new Casino2("Blackjack");
            Casino3 j3 = new Casino3("Poker");
            Jugador player = new Jugador("Juan", j1, j2, j3);
            player.JugandoSecuencia();
            Console.ReadLine();
        }
    }
}
