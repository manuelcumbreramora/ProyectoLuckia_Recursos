﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaDatos;


namespace CapaNegocio
{
    

    public class Usuario
    {
        private string nombre;
        private string pass;
        private string mail;

        public string Nombre { get => nombre; set => nombre = value; }
        public string Pass { get => pass; set => pass = value; }
        public string Mail { get => mail; set => mail = value; }

        //Mando los parametros a Datos
        public String Registrar_Usuario() {

            List<cParametros> listaP = new List<cParametros>();

            try {
                listaP.Add(new cParametros(Nombre, Pass, Mail));            

            } catch (Exception ex) {

                throw ex;
            }

            return "Registro exitoso";

        }
       
    }

    


}
