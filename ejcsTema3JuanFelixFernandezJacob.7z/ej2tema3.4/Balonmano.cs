﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ej2tema3._4
{
    class Balonmano : Juego
    {
        Random Rand = new Random();

        protected override string Nombre()
        {
            return "Balonmano";
        }

        protected override Boolean DetectarTrampa1()
        {
            if (Rand.Next(5) < 2) // la lógica que sea para detectar una trampa 1.
            {
                Console.WriteLine("Detectada trampa 1");
                return true;
            }
            return false;
        }

        protected override Boolean DetectarTrampa2()
        {
            if (Rand.Next(5) < 2) // la lógica que sea para detectar una trampa 2.
            {
                Console.WriteLine("Detectada trampa 2");
                return true;
            }
            return false;
        }

        protected override Boolean DetectarTrampa3()
        {
            if (Rand.Next(5) < 2) // la lógica que sea para detectar una trampa 3.
            {
                Console.WriteLine("Detectada trampa 3");
                return true;
            }
            return false;
        }
    }
}
