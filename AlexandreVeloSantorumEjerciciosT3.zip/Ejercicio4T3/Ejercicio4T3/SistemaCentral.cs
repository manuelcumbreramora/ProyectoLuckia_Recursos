﻿using System;
using System.Collections.Generic;
using System.Text;
using AtletismoClase;
using CarrerasClase;
using FutbolClase;

namespace SistemaCentralClase
{
    public static class SistemaCentral
    {
        public static int generarImporte()
        {
            Atletismo atletismo = new Atletismo();
            Carreras carreras = new Carreras();
            Futbol futbol = new Futbol();
            return (atletismo.generarPuntos() + carreras.generarPuntos() + futbol.generarPuntos()) * 15;
        }
    }
}
