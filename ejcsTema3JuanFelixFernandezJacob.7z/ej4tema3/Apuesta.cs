﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ej4tema3
{
    abstract class Apuesta
    {

        protected IEvento Evento;
        protected int Importe;

        public Jugador Jugador{ get; }

        protected Apuesta(int importe, IEvento evento, Jugador jugador)
        {
            this.Importe = importe;
            this.Evento = evento;
            this.Jugador = jugador;
        }

        public abstract int CalcularPuntosGanados();
    }
}
