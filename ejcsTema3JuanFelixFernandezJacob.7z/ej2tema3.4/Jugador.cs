﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ej2tema3._4
{
    class Jugador: Persona
    {

        private UInt16 Puntos = 20000;

        public void MostrarPuntos()
        {
            Console.WriteLine("Puntos del jugador "+this.Nombre+": "+Puntos);
        }

        public Jugador(String nombre, UInt16 edad) : base(nombre, edad)
        {
            Console.WriteLine("Jugador "+nombre+" creado.");
            MostrarPuntos();
        }

        internal void CambiarPuntos(Int16 v)
        {
            Console.WriteLine("El jugador cambia de puntos en "+v);
            if (Puntos + v> 0){
                Puntos =(UInt16)(Puntos+v);
            } else
            {
                Puntos = 0;
            }
            MostrarPuntos();
        }
    }
}
