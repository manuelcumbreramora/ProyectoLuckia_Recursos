﻿/*Crear una clase Persona que tenga como propiedades el nombre y la edad y un método realizarsuscripcion
Plantear una segunda clase Jugador que herede de la clase Persona.
Añadir a esta segunda clase una propiedad bonus, una propiedad juegos y un método apostar que, incrementará el contador juegos.
y por otro lado actualizará la propiedad bonus con un numero aleatorio de puntos.

-Se pide implementar el registro de una persona como jugador y ejecutar el método apostar de la clase Jugador.*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio1
{
    class Program
    {
        static void Main(string[] args)
        {
            Jugador jug = new Jugador();
            jug.realizarsuscripcion();
            jug.apostar();
            
        }
    }
    
    
}
