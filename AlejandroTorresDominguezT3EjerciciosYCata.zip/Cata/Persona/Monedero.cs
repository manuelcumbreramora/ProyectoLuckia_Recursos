﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cata
{
    public class Monedero
    {
        private int saldo { get; set; }

        public Monedero()
        {
            this.saldo = 0;
        }
        public void llenarMonedero(int importe)
        {
            if (importe > 0)
            {
                this.saldo += importe;
            }
            else
            {
                Console.WriteLine("No has metido dinero");
            }
        }

        public int comprobarCash()
        {
            return this.saldo;
        }
    }
}
