﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ejercicio_5.Juego;

namespace Ejercicio_5.Casinos
{
    public class CasinoApuestas : IJugar
    {
        public void Jugar()
        {
            Console.WriteLine("Apuestas 500 a Suertudo en el Derby de Kentucky");
            Random r = new Random();
            if (r.Next(1, 5) == 3)
            {
                Console.WriteLine("Has ganado 1000 ");
            }
            else
            {
                Console.WriteLine("Lo siento, ha perdido");
            }
        }
    }
}
