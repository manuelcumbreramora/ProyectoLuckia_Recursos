﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PointsCalculator
{
    public class FootballPointsCalculator : AbstractPointsCalculator
    {
        public FootballPointsCalculator() : base("football") { }

        // The input array is a two element array.
        // The first element is 'true' or 'false' and corresponds to the pool.
        // The second element is 'true' or 'false' and corresponds to the result.
        public override float calculatePoints(params string[] args)
        {
            bool pool, result;

            if (! bool.TryParse(args[0], out pool))
            {
                return float.MinValue;
            }

            if (!bool.TryParse(args[1], out result))
            {
                return float.MinValue;
            }

            if ((result) && (! pool))
            {
                string msg = "Error, illegal pool and result values set.";
                throw (new ArgumentException(msg));
            }

            float points;
            if (pool)
            {
                if (result)
                {
                    points = 300f;
                } 
                else
                {
                    points = 200f;
                }
            } else
            {
                points = 0f;
            }
            
            return points;
        }
    }
}
