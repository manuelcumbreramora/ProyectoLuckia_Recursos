﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ejercicio3
{
    class Propietario : IPropietario
    {
        public String nombre { get; set; }

        public String apellidos { get; set; }

     
        public Propietario(string nombre, string apellidos)
        {
            this.nombre = nombre;
            this.apellidos = apellidos;
        }

        public Propietario()
        {
           
        }

        public void crearPropietario()
        {

            Console.WriteLine("Introduzca su nombre");
            nombre = Console.ReadLine();
            Console.WriteLine("Introduzca sus apellidos");
            apellidos = Console.ReadLine();

        }
        public void crearFactura(String nombre, String apellidos, int costeReparacion)
        {
            Console.WriteLine("Nombre y apellidos: " + nombre + " " + apellidos);
            Console.WriteLine("Coste de la reparacion: " + costeReparacion + " euros");

        }
    }
}
