﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BetEvents
{
    public class BetEventAthletics : AbstractBetEvent
    {
        public BetEventAthletics(int id, DateTime date, Bettor.Bettor bettor) : base(id, date, "athletics", bettor) { }

        public BetEventAthletics(int id, Bettor.Bettor bettor) : base(id, new DateTime(), "athletics", bettor) { }

        // Fake, random calculation.
        public override string[] reportResult()
        {
            Random rnd = new Random(Guid.NewGuid().GetHashCode());
            int points = (rnd.NextDouble() < 0.5) ? 0 : rnd.Next(100, 1000);
            return new string[] { (points + "") };
        }

        public override string resultHumanReadable(string[] result)
        {
            return (result[0] + " points");
        }
    }
}
