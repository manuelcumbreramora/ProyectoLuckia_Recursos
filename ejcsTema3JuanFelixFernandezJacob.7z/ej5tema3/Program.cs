﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ej5tema3
{
    class Program
    {
        static void Main(string[] args)
        {
            Jugador jugador = new Jugador();
            jugador.Nombre = "Jose";
            jugador.Jugar();
        }
    }
}
