﻿/*Implementa y diseña, una solución inventada, aplicando cada uno de los siguientes conceptos:
-Interfaces
-Clase estática
-Herencia

-Encapsulamiento
-Polimorfismo: tanto polimorfismo por herencia como polimorfismo por interfaz*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Profesor prof = new Profesor();
            prof.verNotas();
            prof.verNotas(1);
            prof.cargarNotasBBDD();
            prof.ponerNotaFinal();
            Funcionalidades.calculoNota(8, "examen");
        }
    }
}
