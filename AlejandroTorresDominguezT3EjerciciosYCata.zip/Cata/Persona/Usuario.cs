﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cata
{
    public abstract class Usuario 
    {
        private string Nombre { get; set; }
        private string Contra { get; set; }

        public Usuario()
        {
            this.Nombre = "Hola";
            this.Contra = "Mundo";
        }

        public virtual bool validar(string nombre, string contra)
        {
            if (this.Nombre.Equals(Nombre) && this.Contra.Equals(contra))
            {
                return true;
            }
            Console.WriteLine("El usuario y/o contraseña no son correctos");
            return false;
        }

    }
}
