﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EspacioDatos;

namespace Negocio
{

    public class MiClase
    {
        String user { get; set; }
        String email { get; set; }
        String nombre { get; set; }
        public MiClase()
        {
            this.user = "unknown";
            this.email = "unknown";
            this.nombre = "unknown";
        }

        public void getConsoleContent(String user, String email, String nombre)
        {
            this.user = user;
            this.email = email;
            this.nombre = nombre;
        }

        public void sendContentToDatos()
        {
            DatosClase datos = new DatosClase();
            datos.getContentFromNegocio(this.user, this.email, this.nombre);
        }
    }
}
