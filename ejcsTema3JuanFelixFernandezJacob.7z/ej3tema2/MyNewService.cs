﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace ej3tema2
{
    public partial class MyNewService : ServiceBase
    {
        public MyNewService()
        {
            InitializeComponent();
            eventLog1 = new System.Diagnostics.EventLog();
            if (!System.Diagnostics.EventLog.SourceExists("MySource"))
            {
                System.Diagnostics.EventLog.CreateEventSource(
                    "MySource", "MyNewLog");
            }
            eventLog1.Source = "MySource";
            eventLog1.Log = "MyNewLog";
        }

        internal void TestStartupAndStop(string[] p)
        {
            this.OnStart(p);
            Console.ReadKey();
            this.OnStop();
        }

        private void Copy(string sourceDir, string targetDir)
        {
            Directory.CreateDirectory(targetDir);

            foreach (var file in Directory.GetFiles(sourceDir))
                File.Copy(file, Path.Combine(targetDir, Path.GetFileName(file)));

            foreach (var directory in Directory.GetDirectories(sourceDir))
                Copy(directory, Path.Combine(targetDir, Path.GetFileName(directory)));
        }

        protected override void OnStart(string[] args)
        {

            eventLog1.WriteEntry("Copia ficheros OnStart.");


            // Set up a timer that triggers every minute.
            /*timer = new Timer();
            timer.Interval = 60000; // 60 seconds
            timer.Elapsed += new ElapsedEventHandler(this.OnTimer);
            timer.Start();*/

            Copy("C:\\origen", "C:\\destino");
            this.Stop();
        }
        //Timer timer;

        public void OnTimer(object sender, ElapsedEventArgs args)
        {
            // TODO: Insert monitoring activities here.
            eventLog1.WriteEntry("Iniciando copia", EventLogEntryType.Information, eventId++);

            Copy("C:\\origen", "C:\\destino");
        }

        private int eventId = 1;

        protected override void OnStop()
        {
            eventLog1.WriteEntry("Copia ficheros OnStop.");
            //timer.Stop();
        }
    }
}
