﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ejercicio4
{
    class SistemaCentral
    {
        
        int puntosProv, puntosTotales, ganancia = 0;
        int[] apuestas = { 1, 2, 3, 1, 2 }; //1: Apuesta al fútbol; 2: Apuesta a Carreras; 3: Apuessta a atletismo

        public SistemaCentral()
        {
        }

        public void generarPuntosTotales()
        {
            
            for (int i = 0; i < apuestas.Length; i++)
            {
                switch(apuestas[i]){

                    case 1:
                        Pfutbol fut = new Pfutbol();
                        puntosProv = fut.calcularPuntos();
                        break;
                    case 2:
                        Pcarreras carr = new Pcarreras();
                        puntosProv = carr.calcularPuntos();
                        break;
                    case 3:
                        Patletismo atl = new Patletismo();
                        puntosProv = atl.calcularPuntos();
                        break;
                    default:
                        Console.WriteLine("Error en el procesado");
                        break;

                }

                puntosTotales = puntosTotales + puntosProv;
            }

            Console.WriteLine("Ha obtenido un total de " + puntosTotales + " puntos");
        }


    public int generarSaldo()
        {
            generarPuntosTotales();

            ganancia = puntosTotales * 15;
            return ganancia;
                
        }


    }
}
