﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Users
{
    public abstract class AbstractUser : IUser
    {
        public int Id;

        public string Name;
        
        public UserType Type;

        public enum UserType { Employee = 0, Contractor = 10, Bettor = 20};

        public AbstractUser(int id, UserType type, string name)
        {
            this.Id = id;
            this.Type = type;
            this.Name = name;
        }

        int IUser.GetId()
        {
            return this.Id;
        }

        string IUser.GetName()
        {
            return this.Name;
        }

        UserType IUser.GetType()
        {
            return this.Type;
        }
    }
}
