﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EjercicioMVC1.Controllers
{
    public class NewController : Controller
    {
        // GET: New
        public ActionResult Saludo()
        {
            return View();
        }
    }
}