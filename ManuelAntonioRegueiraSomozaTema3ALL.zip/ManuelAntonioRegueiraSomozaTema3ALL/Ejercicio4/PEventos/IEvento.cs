﻿using InterfaceSistemaCentral;
using PJugador;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceEventos
{
    public interface IEvento
    {


        void JugarEvento();
        void MostrarEvento();
        int GetResultado();



    }
}
