﻿using System;
using System.Collections.Generic;

namespace Base
{
    public class User
    {

        public string usuario { get; set; }
        public string password { get; set; }

        public bool IniciarSesion(String usuario, String password, List<User> usuarios)
        {
            bool cumple = false;
            foreach (User user in usuarios)
            {
                if (user.usuario.Equals(usuario) && user.password.Equals(password))
                {
                    cumple = true;
                }
            }
            return cumple;
        }
    }
}
