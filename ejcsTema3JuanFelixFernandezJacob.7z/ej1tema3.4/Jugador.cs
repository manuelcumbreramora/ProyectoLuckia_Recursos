﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ej1tema3._4
{
    class Jugador:Persona
    {
        private UInt16 Bonus;

        private UInt16 Juegos;

        private readonly Random Rand = new Random();

        public Jugador(String nombre, UInt16 edad):base(nombre, edad)
        {

        }

        public void Apostar()
        {
            Juegos++;

            Bonus = (UInt16)Rand.Next(0, 20000);

            Console.WriteLine("Bonus: " + Bonus+"; Juegos: "+Juegos) ;
        }

    }
}
