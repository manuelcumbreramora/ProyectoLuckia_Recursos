﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_4
{
    public class Futbol : IEvento
    {
        public int generaPuntos()
        {
            Random ran = new Random();
            switch (ran.Next(1, 4))
            {
                case 1:
                    return 0;
                case 2:
                    return 200;
                case 3:
                    return 300;
            }
            return -1;
        }

    }
}
