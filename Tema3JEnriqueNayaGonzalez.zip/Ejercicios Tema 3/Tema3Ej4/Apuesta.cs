﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3Ej4
{
    class Apuesta
    {
        public Apuesta()
        {
        }

        public Apuesta(string jugador, int evento, int importe)
        {
            this.jugador = jugador;
            this.evento = evento;
            this.importe = importe;
        }

        public string jugador { get; set; }
        public int evento { get; set; }
        public int importe { get; set; }
   
    }
}
