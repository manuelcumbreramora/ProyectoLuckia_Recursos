﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio2
{
    public class Juego
    {
        private string nombreEvento { get; set; }
        public Juego()
        {

        }
        public Juego(string _nombre)
        {
            this.nombreEvento = _nombre;
        }
    }
}
