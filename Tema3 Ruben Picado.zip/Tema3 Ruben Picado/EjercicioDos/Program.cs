﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioDos
{
    class Program
    {
        static void Main(string[] args)
        {
            int opcion = 0;
            int resta;
            int monedero;

            Jugador jugador = new Jugador();
            jugador.registro();
            monedero = jugador.monederoActual();
            Deporte deporte = new Deporte();
            deporte.escogerDeporte();
            
            switch(opcion)
            {
               case 1:
                Deportes fut = new Deportes();
                fut.DeporteFutbol();
                break;

                case 2:
                    Deportes balon = new Deportes();
                    balon.DeporteBalonMano();
                    break;

                case 3:
                    Deportes voley = new Deportes();
                    voley.DeporteVoleybol();
                    break;
            }
            Penalizador pena = new Penalizador();
            resta = pena.penalizador();
             Console.WriteLine("Le queda " + monedero);
             Console.ReadLine();
           
            
        }
    }

    
}
