﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ejercicio2
{
    class Juego
    {
        int eleccion;


        //Generamos una fecha y horario para el evento deportivo
        //No se usa en el programa pero sería una buena idea para el futuro, si no hay conexión con BBDD

        public void generarFecha()
        {
            var date1 = new DateTime(2020, 3, 23, 20, 30, 00);
            Console.WriteLine(date1);
            Console.ReadLine();
        }

        public int elegirJuego()
        {
            Console.WriteLine("Elija a qué quiere apostar");
            Console.WriteLine("1: Futbol");
            Console.WriteLine("2: Baloncesto");
            Console.WriteLine("3: Voleibol");
            eleccion = Int32.Parse(Console.ReadLine());
            return eleccion;
        }

        



    }
}
