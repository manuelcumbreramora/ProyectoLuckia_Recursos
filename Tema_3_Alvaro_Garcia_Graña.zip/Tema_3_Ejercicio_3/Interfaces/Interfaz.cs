﻿using System;
using System.Collections.Generic;

namespace Interfaces
{
    public interface Interfaz
    {
        void generarDesastreNatural(int numeroAleatorio);
    }
}
