﻿using DataLayer;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;

namespace BussinessLayer
{
    public class Bussiness
    {
        private UserManager userManager;

        public Bussiness()
        {
            this.userManager = UserManager.get();
        }

        public void showAllUsers()
        {
            List<User> allUsers = this.userManager.getAllUsers();
            if (allUsers.Count == 0)
            {
                Console.WriteLine("User database currently empty.");
            } else
            {
                foreach (User item in allUsers) {
                    Console.Write(item.getUsername());
                    Console.Write(" ** ");
                    Console.Write(item.getEmail() + "\n");
                }
            }
        }

        public void addUser(string username, string email)
        {
            this.userManager.addUser(new User(username, email));
        }
    }
}
