﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BibliotecaClases
{
    public class Juego
    {
        public string Tipo { get; set; }

        public void elegirJuego(string juego)
        {
            Tipo = juego;
        }
    }
}
