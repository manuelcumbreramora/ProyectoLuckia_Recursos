﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kata3Eloy
{
    public static class HistoricoApuestas
    {
        public static List<String> seleccion = new List<String>();
    }
}
