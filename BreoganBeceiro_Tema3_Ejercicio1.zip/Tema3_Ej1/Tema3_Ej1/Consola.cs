﻿//BreoBeceiro:23/03/2020
//PLEXUS | Tema3

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Modelo;

namespace Vista
{
    class Consola
    {
        static void Main()
        {
            string nombre;
            string edad;
            string apellido;
            bool suscripcion;

            suscripcion = false;

            Console.WriteLine("Introduce tu nombre: ");
            nombre = Console.ReadLine();

            Console.WriteLine("Introduce tu apellido: ");
            apellido = Console.ReadLine();

            Console.WriteLine("Introduce tu edad: ");
            edad = Console.ReadLine();

            //Se comprueba que los datos cumplen con el formato adecuado (nombre y apellido sin caracteres numéricos, edad sin
            //  caracteres alfabéticos, etc)...

            Jugador jugador = new Jugador(Convert.ToInt32(edad), nombre, apellido);

            if (jugador.realizarSuscripcion())
            {
                Console.WriteLine("Te has suscrito!");
                suscripcion = true;
            }
            else
            {
                Console.WriteLine("ERROR: Suscripción fallida.");
            }

            if (suscripcion)
            {
                jugador.apostar();
            }

            Console.WriteLine("Contador JUEGOS: " + jugador.juegos + ", propiedad BONUS: " + jugador.bonus);


            Console.ReadKey();
        }
    }
}
