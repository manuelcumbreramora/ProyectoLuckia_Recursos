﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_Pago
{
    public class SistemaCentral : CalculoDineroFinal 
    {
        public double puntosTotal { get; set; }
        public int divisor { get; set; }
        public SistemaCentral() { }
        public SistemaCentral(int div, double pointsTotal)
        {
            this.multiplicador = 15;
            this.divisor = div;
            this.puntosTotal = pointsTotal;
        }
        public override double calculo(int puntos, int div)
        {
            double resultadoModalidad = 0;
            resultadoModalidad = puntos / div;
            Console.WriteLine("Total de puntos obtenidos en la modalidad: " + resultadoModalidad);
            return resultadoModalidad;
        }
        public override void sumaPuntos(double pointsFut, double pointsRace, double pointsAtle)
        {
            this.puntosTotal = pointsFut + pointsRace + pointsAtle;
        }
        public override void dineroGanado()
        {
            this.dineroFinal = this.puntosTotal * this.multiplicador;
        }
    }
}
