﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Base
{
    class Casino3 : Juego
    {
        public void jugar()
        {
            Console.WriteLine("Estas jugando en Casino Royal.");
        }
    }
}
