﻿using Newtonsoft.Json;
using PRepositorioTareaViewModel;
using PTarea;
using PTareaViewModel;
using PUsuario;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Consola   
{
    public class ProcesadorTareas
    {
        private async Task Procesar()
        {
            try{
                Console.WriteLine("Inicio de procesamiento");
                //conexión
                var client = new HttpClient();
               /* var urlTareas = "https://jsonplaceholder.typicode.com/todos";
                //conexión
                var respuestaTareas = await client.GetAsync(urlTareas);// abre hilo
                respuestaTareas.EnsureSuccessStatusCode();
                var cuerpoRespuestaTareas = await respuestaTareas.Content.ReadAsStringAsync();// cierra hilo tras recibir respues
                Console.WriteLine(cuerpoRespuestaTareas);

                var tareas = JsonConvert.DeserializeObject<Tarea[]>(cuerpoRespuestaTareas);
                var tareasNoRealizadas = tareas.Where(x => !x.Completed).ToList();*/
                Tarea tarea = new Tarea();
                var tareasNoRealizadas = await tarea.ProcesarTrabajoTarea(client);

                /*     var urlUsuarios = "https://jsonplaceholder.typicode.com/users";
                     var respuestaUsuarios = await client.GetAsync(urlUsuarios);//abre hilo
                     respuestaUsuarios.EnsureSuccessStatusCode();
                     var cuerpoRespuestaUsuarios = await respuestaUsuarios.Content.ReadAsStringAsync();//respuesta hilo
                     Console.WriteLine(cuerpoRespuestaUsuarios);*/

                Usuario usuario = new Usuario();
                var usuarios = await usuario.ProcesarTrabajoUsuario(client); 

                Console.WriteLine("Inicio transformación ViewModels");
                //generar lista tareas
                //var tareasViewModel = new List<TareaViewModel>(); // muestra Usuario y tareas,Debemos diferenciar tareas
                RepositorioTareaViewModel repoTareas=new RepositorioTareaViewModel();//generamos un respositorio de TareaViewModel
                foreach (var tarea1 in tareasNoRealizadas)
                {

                        repoTareas.InsertaTareaViewModel(tarea1.Id, usuarios.Where(x => x.Id == tarea1.UserId).First().Nombre.Trim(), tarea1.Title.Trim());
                 
                    /*  var tareaViewModel = new TareaViewModel()
                    {
                        Id = tarea.Id,
                        Title = tarea.Title.Trim(),
                        NombreUsuario = usuarios.Where(x => x.Id == tarea.UserId).First().Nombre.Trim()
                    };
                    tareasViewModel.Add(tareaViewModel);*/
                }
                
                Console.WriteLine("Inicio escritura de tareas en archivo");
                using (StreamWriter writetext = new StreamWriter($@"{Directory.GetCurrentDirectory()}\tareas pendientes.txt"));

            }catch (IOException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    }

   

}
