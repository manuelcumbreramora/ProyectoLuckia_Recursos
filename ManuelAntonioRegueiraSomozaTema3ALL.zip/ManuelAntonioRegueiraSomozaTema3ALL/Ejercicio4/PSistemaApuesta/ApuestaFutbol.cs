﻿using EventoFutbol;
using InterfaceEventos;
using InterfaceSistemaCentral;
using PJugador;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PSistemaApuestaFutbol
{
    public class ApuestaFutbol : ISistemaCentral
    {
        public Jugador Player;
        public EFutbol Evento;
        private int ResultadoApuesta;
        private Boolean Quiniela;
        private DateTime FechaApuesta;

        public ApuestaFutbol(Jugador player, EFutbol evento, int resultado)
        {
            Player = player;
            Evento = evento;
            ResultadoApuesta = resultado;
            Quiniela = false;
            FechaApuesta = DateTime.Now;
        }
        public void JugarApuesta()
        {
            this.Evento.JugarEvento();
            int puntosTotal = this.CalculoPuntos();
            int importe=this.calculoImporte(puntosTotal);
            this.abonarApuesta(importe);

        }

        public int CalculoPuntos()
        {
            int sApuesta = this.ResultadoApuesta;
            int resultadoPartido = this.Evento.GetResultado();
           
            int puntosTotal=0;

            if ((sApuesta == resultadoPartido))
            {
                puntosTotal = 300;
                Console.WriteLine("Jugador Gano Apuesta");
            }
            else if ((sApuesta != resultadoPartido) && (this.Quiniela))
            {
                puntosTotal = 200;
                Console.WriteLine("Jugador Gano Quiniela");
            }
            else if((sApuesta != resultadoPartido) && (this.Quiniela == false))
            {
                puntosTotal = 0;
                Console.WriteLine("Jugador no gano nada");
            }
            return puntosTotal;
        }
        
        public int calculoImporte( int puntos)
        {
            return (puntos * 15);
        }
        public void abonarApuesta( int importe)
        {
            this.Player.ModificarMonedero(importe);
        }

        public void mostrarApuesta()
        {
            Console.WriteLine("Apuesta para Evento ");
            Console.WriteLine(".......................");
            this.Evento.MostrarEvento();
            Console.WriteLine("Apostado por el jugador de nombre: {0} ", this.Player.ConsultarNombre());
            Console.WriteLine("En Fecha {0} ", this.FechaApuesta);
            
        }
    }
    
}
