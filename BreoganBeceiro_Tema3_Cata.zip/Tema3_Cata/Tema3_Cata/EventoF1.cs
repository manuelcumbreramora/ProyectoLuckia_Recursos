﻿//BreoBeceiro:25/03/2020
//PLEXUS | Tema3

//El método resultadoEvento() está bien sobrecargado? No está declarado como 'virtual' en la clase madre ni se utiliza 'override'
//  en esta clase (si se hace, sale un error 'no se encontró ningún miembro adecuado que invalidar' en el método de este script).

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Cata
{
    class EventoF1 : Evento
    {
        public string nombreGP { get; set; }


        public string resultadoEvento(string dateTime, string GP)
        {
            //Se consulta a la BBDD para obtener el resultado...
            return "HAM, RAI, ALO";
        }
    }
}
