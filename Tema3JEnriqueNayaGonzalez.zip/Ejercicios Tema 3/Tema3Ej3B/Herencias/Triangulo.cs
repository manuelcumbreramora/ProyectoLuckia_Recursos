﻿using Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tema3Ej3B;

namespace Herencias
{
    public class Triangulo : FiguraGeometrica, IPoligono
    {
        public int Altura { get; set; }
        public Triangulo( int longitudLado) : base(3, longitudLado)
        {
        }

        public double ObtenerArea()
        {
            return this.LongitudLado * Altura;
        }

        public int ObtenerLongitud()
        {
            return this.NumLados * this.LongitudLado;
        }
    }
}
