﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_4
{
    public class Monedero
    {
        private double saldo { get; set; }
        public void cargaMonedero(double cant)
        {
            saldo += cant;
        }
        public double compruebaSaldo()
        {
            return this.saldo;
        }
    }
}
