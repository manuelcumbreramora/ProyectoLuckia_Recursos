﻿//BreoBeceiro:25/03/2020
//PLEXUS | Tema3

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo
{
    public class Jugador : Persona
    {
        public int bonus { get; set; }
        public int juegos { get; set; }

        //OJO: Al utilizar :base(), se deben pasar los argumentos del constructor de la clase madre en el constructor de la clase
        //   hija, y luego añadirlos en :base(), por ejemplo:
        //
        //     public Animal(string nombreCientifico, string especie):base(especie)
        //
        //Así, el constructor de la clase madre solo recibe como parámetro nombreCientifico, sin embargo, en la hija se le añade
        //  especie, y se indica así en la llamada a :base().
        public Jugador(int age, string _nombre, string _apellido):base(_nombre, _apellido)
        {
            this.edad = age;
            this.nombre = _nombre;
            this.apellido = _apellido;
            this.juegos = 10;
            this.bonus = 15;
        }

        /// <summary>
        /// Incrementa el contador 'juegos' y actualiza 'bonus' con un número aleatorio (entre 0 y 10) de puntos.
        /// </summary>
        public void apostar()
        {
            Random aleatorio = new Random(0);
            int num = aleatorio.Next(5, 15);

            this.bonus = num;
            this.juegos++;
        }
    }
}
