﻿using JuegoJuego;
using JuegoPersona;
using PenalizacionJuego;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PenalizacionVoleibol
{
    public class PVoleibol :Penalizador

    {
        public override void PenalizarPersonaJuego(Persona persona, Juego juego)
        {
            throw new NotImplementedException();
        }
    }
}
