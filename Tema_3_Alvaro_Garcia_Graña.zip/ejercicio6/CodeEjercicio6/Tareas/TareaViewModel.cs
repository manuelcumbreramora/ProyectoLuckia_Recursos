﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Usuarios;

namespace Tareas
{
    public class TareaViewModel
    {
        public int Id { get; set; }
        public string NombreUsuario { get; set; }
        public string Title { get; set; }

        public void almacenar(List<TareaViewModel> tareasViewModel, Tarea tarea, Usuario[] usuarios)
        {
            var tareaViewModel = new TareaViewModel()
            {
                Id = tarea.Id,
                Title = tarea.Title.Trim(),
                NombreUsuario = usuarios.Where(x => x.Id == tarea.UserId).First().Nombre.Trim()
            };
            tareasViewModel.Add(tareaViewModel);
        }
    }
}
