﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceCasino

{
    public interface ICasino
    {
        void Jugar();
    }
}
