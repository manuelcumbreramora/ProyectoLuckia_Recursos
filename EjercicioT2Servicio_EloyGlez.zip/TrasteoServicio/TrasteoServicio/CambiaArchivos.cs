﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.IO;

namespace TrasteoServicio
{
    partial class CambiaArchivos : ServiceBase
    {
        bool blBandera = false;

        public CambiaArchivos()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            timer1.Start();
        }

        protected override void OnStop()
        {
            timer1.Stop();
        }

        private void timer1_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            if (blBandera) return;


            try {

                blBandera = true;

                EventLog.WriteEntry("Se inicio el proceso de copiado", EventLogEntryType.Information);

                //En appConfig indico las rutas de origen y destino

                string stRutaOrigen = ConfigurationSettings.AppSettings["stRutaOrigen"].ToString();
                string stRutaDestino = ConfigurationSettings.AppSettings["stRutaDestino"].ToString();


                DirectoryInfo di = new DirectoryInfo(stRutaOrigen);

                //Recorro todos los archivos del directorio

                foreach (var archivo in di.GetFiles("*",SearchOption.AllDirectories)) 
                {

                    //Si el archivo existe, lo borro y normalizo sus atributos

                    if (File.Exists(stRutaDestino + archivo.Name)) 
                    {
                        File.SetAttributes(stRutaDestino + archivo.Name, FileAttributes.Normal);
                        File.Delete(stRutaDestino + archivo.Name);
                    }
                        //Copio el archivo en la ruta de destino y lo normalizo

                    File.Copy(stRutaOrigen + archivo.Name, stRutaDestino+ archivo.Name);
                    File.SetAttributes(stRutaDestino + archivo.Name, FileAttributes.Normal);

                    //Muestro en servicios si tuvo exito

                    if(File.Exists(stRutaDestino + archivo.Name))
                        EventLog.WriteEntry("Se ha copiado el archivo", EventLogEntryType.Information);
                    else
                        EventLog.WriteEntry("No se ha copiado el archivo", EventLogEntryType.Information);
                }


                EventLog.WriteEntry("Finalizado proceso de copiado", EventLogEntryType.Information);
            } 
            
            catch (Exception ex) 
                    //Si no tuvo exito muestro el error
            {
                EventLog.WriteEntry(ex.Message, EventLogEntryType.Error);
            }

            blBandera = false;
        }
    }
}
