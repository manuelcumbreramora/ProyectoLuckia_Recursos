﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Taxes;

namespace TaxCalculator
{
    public class FootballTaxCalculator : AbstractTaxCalculator
    {
        public FootballTaxCalculator() : base("football") { }

        // The total taxes cannot be greater than the 25% of the input amount.
        public override float calculateTotalTaxes(List<ITax> taxes, float amount)
        {
            float _amount = amount;

            float t, totalTaxes = 0f;
            foreach (AbstractTax item in taxes)
            {
                t = item.calculateTax(_amount);
                totalTaxes = totalTaxes + t;
                _amount = _amount - t;
            }

            float maxAllowed = amount * 0.25f;
            totalTaxes = Math.Min(totalTaxes, maxAllowed);

            return totalTaxes;
        }
    }
}
