﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace kata3Eloy.Formularios
{
    public partial class SeleccionJuego : Form
    {
        public SeleccionJuego()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pbFutbol_Click(object sender, EventArgs e)
        {
            this.Hide();


            rfmFutbol rf = new rfmFutbol();

            rf.ShowDialog();
        }

        private void pbHome_Click(object sender, EventArgs e)
        {
            this.Hide();


            MenuPrincipal menup = new MenuPrincipal();

            menup.ShowDialog();
        }

        private void pbBasket_Click(object sender, EventArgs e)
        {
            this.Hide();


            frmBasket bas = new frmBasket();

            bas.ShowDialog();
        }

        private void pbF1_Click(object sender, EventArgs e)
        {
            this.Hide();


            frmFormula1 frm1 = new frmFormula1();

            frm1.ShowDialog();
        }
    }
}
