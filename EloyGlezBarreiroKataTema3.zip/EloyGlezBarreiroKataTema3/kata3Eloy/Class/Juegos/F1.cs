﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kata3Eloy
{
    class F1 : Juego
    {

        double tasa = 0.89;

        public double Tasa { get => tasa; set => tasa = value; }

        public void calculaCuota(double importeGanado)
        {
            importeGanado = importeGanado * tasa;
        }

        public int resolverEvento()
        {
            Random rnd = new Random();

            return rnd.Next(0, 1000);
        }
    }
}
