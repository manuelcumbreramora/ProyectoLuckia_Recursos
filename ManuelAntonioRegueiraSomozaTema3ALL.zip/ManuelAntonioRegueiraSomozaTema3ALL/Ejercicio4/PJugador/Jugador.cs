﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PJugador
{
    public class Jugador
    {
        private string Nombre { get; set; }
        private int Monedero { get; set; }

        public Jugador(string nombre, int monedero)
        {
            Nombre = nombre;
            Monedero = monedero;
         }

       public int ConsultarMonedero()
        {
            return this.Monedero;
        }
public string ConsultarNombre()
        {
            return this.Nombre;
        }
public void MostrarJugador()
        {
                Console.WriteLine("Nombre {0} ", this.Nombre);
                Console.WriteLine("Monedero {0} ", this.Monedero);
            
        }
        public void ModificarMonedero(int mod)
        {
            this.Monedero = this.Monedero + mod;
        }

    }
   
}
