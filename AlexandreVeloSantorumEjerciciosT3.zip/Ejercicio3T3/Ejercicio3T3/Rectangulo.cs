﻿using System;
using IFiguraSpace;
using CuadradoSpace;

namespace RectanguloSpace
{
    public class Rectangulo : Cuadrado
    {
        private int Lado1 { get; set; }
        private int Lado2 { get; set; }
        public Rectangulo(int lado1, int lado2) : base(lado1)
        {
            Lado1 = lado1;
            Lado2 = lado2;
        }

        public override int Area()
        {
            return (Lado1 * Lado2);
        }

        public override int Perimetro()
        {
            return (Lado1 * 2) + (Lado2 * 2);
        }
    }
}
