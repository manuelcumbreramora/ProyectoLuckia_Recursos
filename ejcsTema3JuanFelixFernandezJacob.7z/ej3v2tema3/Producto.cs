﻿using System;
using System.Text;

namespace ej3v2tema3
{
    abstract internal class Producto
    {
        private double PrecioUnitario;
        DateTime FechaPublicacion;
        String Titulo;

        protected Producto(double precioUnitario, DateTime fechaPublicacion, string titulo)
        {
            PrecioUnitario = precioUnitario;
            FechaPublicacion = fechaPublicacion;
            Titulo = titulo;
        }

        public abstract string EscribirInformacion(StringBuilder salida, ISerializador serializador);

        protected void EscribirTitulo(StringBuilder salida, ISerializador serializador)
        {
            
            
            salida.Append(serializador.Atributo("Titulo", Titulo));

        }

        protected void EscribirFechaPublicacion(StringBuilder salida, ISerializador serializador)
        {
            salida.Append(serializador.Atributo("FechaPublicacion", Titulo));
        }

        protected void EscribirPrecioUnitario(StringBuilder salida, ISerializador serializador)
        {
            salida.Append(serializador.Atributo("Precio", PrecioUnitario));
        }
    }
}