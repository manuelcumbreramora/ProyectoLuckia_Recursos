﻿using System;
using System.Collections.Generic;
using System.Text;
using InterfaceEvento;

namespace AtletismoClase
{
    class Atletismo : IEvento
    {
        public int generarPuntos()
        {
            string apuestaCorrecta = generarApuestaCorrecta();
            string apuestaUsuario = generarApuestaUsuario();

            if (apuestaUsuario == apuestaCorrecta)
            {
                Random rn = new Random();
                return rn.Next(300) / 2;
            } else
            {
                return 0;
            }
            
        }

        public string generarApuestaCorrecta()
        {
            return "Alfonso";
        }

        public string generarApuestaUsuario()
        {
            string[] apuestas = new string[] { "", "Alfonso", "Manuel", "Juan" };
            int opcion = 0;
            while (opcion != 1 && opcion !=2 && opcion != 3)
            {
                Console.WriteLine("Apuesta Atletismo:");
                Console.WriteLine("1. Alfonso");
                Console.WriteLine("2. Manuel");
                Console.WriteLine("3. Juan");
                Console.WriteLine("Elige una opción:");
                opcion = Int32.Parse(Console.ReadLine());
            }
            return apuestas[opcion];

        }
    }
}
