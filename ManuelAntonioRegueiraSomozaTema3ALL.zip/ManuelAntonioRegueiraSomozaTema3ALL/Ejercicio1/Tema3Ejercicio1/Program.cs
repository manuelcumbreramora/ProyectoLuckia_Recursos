﻿using Juego.Jugador;
using JuegoPersona;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3Ejercicio1
{
    class Program
    {
        static void Main(string[] args)
        {
            Persona person1 = new Persona(18, "Juan");
            Console.WriteLine("Crear suscripcion de persona");
            person1.realizarsuscripcion();
            Jugador jugadorNuevo = Jugador.RegistrarComoJugador(person1);
            Console.WriteLine("Crear suscripcion de jugador");
            jugadorNuevo.realizarsuscripcion();
            Console.WriteLine("Apostamos 1 vez");
            jugadorNuevo.Apostar();
            Console.WriteLine("Nombre: {0}",jugadorNuevo.Nombre);
            Console.WriteLine("Edad: {0}", jugadorNuevo.Edad);
            Console.WriteLine("Juegos: {0}", jugadorNuevo.Juegos);
            Console.WriteLine("Bonus: {0}", jugadorNuevo.Bonus);
            Console.ReadLine();
            Console.WriteLine("Apostamos 2 vez");
            jugadorNuevo.Apostar();
              
            Console.WriteLine("Nombre: {0}", jugadorNuevo.Nombre);
            Console.WriteLine("Edad: {0}", jugadorNuevo.Edad);
            Console.WriteLine("Juegos: {0}", jugadorNuevo.Juegos);
            Console.WriteLine("Bonus: {0}", jugadorNuevo.Bonus);
            Console.ReadLine();
           
        }
    }
}
