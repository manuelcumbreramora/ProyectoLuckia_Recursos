﻿namespace ej5tema3
{
    internal class CasinoGreat : Casino
    {
        public void Jugar(Jugador jugador)
        {
            System.Console.WriteLine("El jugador "+jugador.Nombre+" juega en un CasinoGreat");
        }
    }
}