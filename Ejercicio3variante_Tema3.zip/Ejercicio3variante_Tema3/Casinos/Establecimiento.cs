﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hosteleria
{
    public abstract class Establecimiento
    {
        public string nombre { get; set; }
        public string cif { get; set; }
        public Establecimiento()
        {

        }
        public Establecimiento(string nom, string cif, string desig, string direccion)
        {
            this.nombre = nom;
            this.cif = cif;
        }
        public abstract void registro();
    }
}
