﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Base
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Jugador jugador = new Jugador();
            Apuestas apuestas = new Apuestas();
            foreach (ListItem li in eventos.Items)
            {
                if (li.Selected == true)
                {
                    jugador.evento += int.Parse(li.Value);
                }
            }
            string abonado = saldo.Text;
            string apostado = importeApuesta.Text;
            apuestas.iniciarApuesta(jugador, int.Parse(abonado), int.Parse(apostado));
            Response.Redirect("Resultado.aspx");

        }
    }
}