﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_4
{
    public class Carreras: IEvento
    {
        public int generaPuntos()
        {
            Random ran = new Random();
            return (ran.Next(10, 100))/10;
        }

    }
}
