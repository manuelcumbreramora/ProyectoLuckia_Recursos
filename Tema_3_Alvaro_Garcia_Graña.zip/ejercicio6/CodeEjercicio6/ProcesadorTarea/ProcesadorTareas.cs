﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Tareas;
using Usuarios;

namespace Consola   
{
    public class ProcesadorTareas
    {
        public void escribirEnArchivo()
        {
            Console.WriteLine("Inicio escritura de tareas en archivo");
            using (StreamWriter writetext = new StreamWriter($@"{Directory.GetCurrentDirectory()}\tareas pendientes.txt")) ;
        }
        private async Task Procesar()
        {
            try{
                Console.WriteLine("Inicio de procesamiento");

                var client = new HttpClient();
                Tarea tarea = new Tarea();
                TareaViewModel tareaViewModel = new TareaViewModel();
                Usuario usuario = new Usuario();
                var tareasNoRealizadas = await tarea.ProcesarTarea(client);
                var usuarios = await usuario.ProcesarUsuario(client);

                Console.WriteLine("Inicio transformación ViewModels");

                var tareasViewModel = new List<TareaViewModel>();

                foreach (var tarea3 in tareasNoRealizadas)
                    {
                    tareaViewModel.almacenar(tareasViewModel, tarea3, usuarios);
                    }

                escribirEnArchivo();

            }catch (IOException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    }

}
