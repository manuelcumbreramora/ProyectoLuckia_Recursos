﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimuladorCarreras
{
    class Program
    {
        static void Main(string[] args)
        {

            Corredor pepito = new Corredor("Pepito", 21, Corredor.TNacionalidad.ES);
            pepito.VelocidadMedia = 1;
            pepito.DesviacionTipica = 0.08;

            Corredor jose = new Corredor("José", 20, Corredor.TNacionalidad.CO);
            jose.VelocidadMedia = 0.9;
            jose.DesviacionTipica = 0.1;

            Competicion carrera = new CarreraSencilla(300);

            carrera.ApuntarParticipante(pepito);
            carrera.ApuntarParticipante(jose);

            carrera.SimularCompeticion();

            Console.WriteLine("Resultados de la carrera:");
            carrera.MostrarResultado();
        }
    }
}
