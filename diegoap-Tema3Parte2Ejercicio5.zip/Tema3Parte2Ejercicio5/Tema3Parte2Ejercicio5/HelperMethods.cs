﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3Parte2Ejercicio5
{
    static class HelperMethods
    {
        public static void shuffleList<T>(this IList<T> list)
        {
            Random rnd = new Random(Guid.NewGuid().GetHashCode());

            int n = list.Count;
            while (n > 1)
            {
                n--;
                int k = rnd.Next(n + 1);
                T value = list[k];
                list[k] = list[n];
                list[n] = value;
            }
        }

    }
}
