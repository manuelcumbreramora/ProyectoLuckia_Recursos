﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Consola
{
    public class Operador
    {

        public async Task obtenerCuerpoRespuesta(HttpClient client)
        {
            
        }
    }
}
