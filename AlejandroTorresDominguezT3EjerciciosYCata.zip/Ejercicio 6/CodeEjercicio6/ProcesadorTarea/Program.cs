﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;

namespace Consola
{
    class Program
    {
        public static void Main(String[] args)
        {
            Llamadas();
        }
        static async void Llamadas()
        {
            var client = new HttpClient();
            ProcesadorTareas procesadorTareas = new ProcesadorTareas();
            var tareasNoRealizadas= await procesadorTareas.Procesar(client);
            ProcesarUsuario procesarUsuario = new ProcesarUsuario();
            var usuarios = await procesarUsuario.RecuperarUsuarios(client);
            ProcesarTareaViewModel procesarTareaViewModel = new ProcesarTareaViewModel();
            var tareasViewModel = procesarTareaViewModel.Procesar(tareasNoRealizadas, usuarios);
            IODatos iODatos = new IODatos();
            iODatos.EscribirDatos(tareasViewModel);
        }
    }
}
