﻿using System;

namespace IFiguraSpace
{
    interface IFigura
    {
        int Area();
        int Perimetro();
    }
}