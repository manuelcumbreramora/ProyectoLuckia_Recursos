﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ej3v2tema3
{
    class SerializadorJson : ISerializador
    {
        public string AbrirLista()
        {
            return "\n[";
        }

        public string Atributo(String nombre, string valor)
        {
            return "\n\"" + nombre + "\": \"" + valor + "\"";
        }

        public string Atributo(String nombre, int valor)
        {
            return "\n\"" + nombre + "\": " + valor;
        }

        public string Atributo(String nombre, double valor)
        {
            return "\n\"" + nombre + "\": " + valor;
        }

        public string CerrarLista()
        {
            return "\n]";
        }

        public string FinEntidad()
        {
            return "\n}";
        }

        public string InicioEntidad(String nombre)
        {
            return "{\n\"tipo\": \"" + nombre + "\"";
        }

        public String SeparadorLista()
        {
            return ",";
        }
    }
}
