﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PEventos
{
    public class EventoF1 : IEventos
    {
        private String Nombre;
        private int TotalParticipantes;
        private DateTime Fecha;
        private int ResultadoFinal;// 0 sin jugar y tras jugar de 1 a totalParticipantes

        public EventoF1(String nombre, int maxParticipantes)
        {
            Nombre = nombre;
            TotalParticipantes = maxParticipantes;
            Fecha = DateTime.Now;
            ResultadoFinal = 0;
        }
        public int DevolverResultadoFinal()
        {
            return this.ResultadoFinal;
        }

        public void MostrarEvento()
        {
            Console.WriteLine("Tipo de evento: {0}", this.GetType());
            Console.WriteLine("Nombre: {0} ", this.Nombre);
            Console.WriteLine("Fecha: {0} ", this.Fecha);
            Console.WriteLine("Numero de Participantes: {0} ", this.TotalParticipantes);

            if (this.ResultadoFinal == 0)
            {
                
                Console.WriteLine("Carrera aun no resuelta");
            }
            else 
            {

                Console.WriteLine("Resultado Actual : Ganador {0} ", this.ResultadoFinal);

            }
         
        }

        public void ResolverEvento()
        {
            Random random = new Random();
            int numAleatorio = random.Next(1, this.TotalParticipantes);


            this.ResultadoFinal = numAleatorio;
            Console.WriteLine("Gano  {0} ", this.ResultadoFinal);

        }
        public string GetNombre()
        {
            return this.Nombre;
        }
    }
}
