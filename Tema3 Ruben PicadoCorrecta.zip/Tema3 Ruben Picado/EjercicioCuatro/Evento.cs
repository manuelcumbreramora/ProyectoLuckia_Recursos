﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioCuatro
{
    class Evento
    {
        public Evento( string evento)
        {
           
            this.evento = evento;
        }

       
        public string evento { get; set; }


        public void eventosList()
        {
            List<string> listaDeEventos = new List<string>();
            listaDeEventos.Add("Partido 1");
            listaDeEventos.Add("Partido 2");
            listaDeEventos.Add("Carrera 1");
            listaDeEventos.Add("Carrera 2");
            listaDeEventos.Add("Salto 1");
            listaDeEventos.Add("Salto 2");

            int[] apuesta = { 1, 2, 3, 2, 1, 3};
            int count = 0;
            foreach ( string num in listaDeEventos)
            {
                count++; 
                Console.WriteLine(count);
            }
            Console.ReadLine();

        }
    }

}
