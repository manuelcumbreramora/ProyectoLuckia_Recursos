﻿//BreoBeceiro:23/03/2020
//PLEXUS | Tema3

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ej2
{
    public static class Registros
    {
        /// <summary>
        /// Guarda una entrada en un fichero con la última penalización de un jugador.
        /// </summary>
        /// <param name="code">El código del jugador que cometió la penalización.</param>
        /// <returns>TRUE si el registro se escribe con éxit, FALSE si falla.</returns>
        public static bool nuevaPenalizacion(string code)
        {
            return true;
        }

        /// <summary>
        /// Envía un fichero de log a un servidor remoto.
        /// </summary>
        /// <param name="route">La ruta del fichero a enviar en el servidor.</param>
        /// <returns>TRUE si se envía con éxito o FALSE si el envío falla.</returns>
        public static bool enviaFichero(string route)
        {
            return true;
        }
    }
}
