﻿using System;

namespace EjercicioDos
{
    public  class Deporte
        
    {
        int opcion;

        public Deporte()
        {

        }
        public int escogerDeporte()
        {
            Console.WriteLine("Pulse 1 para futbol");
            Console.WriteLine("Pulse 2 para Balonmano");
            Console.WriteLine("Pulse 3 para Voleybol");
            int.Parse(Console.ReadLine());
            return opcion;
        }
       

    }
}
