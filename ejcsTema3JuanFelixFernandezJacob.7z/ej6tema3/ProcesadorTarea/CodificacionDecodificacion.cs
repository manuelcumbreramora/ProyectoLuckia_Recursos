﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Consola;

namespace ConsoleApp3
{
    public class CodificacionDecodificacion
    {
        public Tarea[] DescodificarTareas(String tareasCodificado)
        {
            var tareas = JsonConvert.DeserializeObject<Tarea[]>(tareasCodificado);

            return tareas;
        }

        public Usuario[] DescodificarUsuarios(String usuariosCodificado)
        {
            return JsonConvert.DeserializeObject<Usuario[]>(usuariosCodificado);
        }

        public String CodificarTareasViewModel(List<TareaViewModel> tareasViewModel)
        {
            // Esto no tiene implementación porque el código original está incompleto.
            return "";
        }
    }
}
