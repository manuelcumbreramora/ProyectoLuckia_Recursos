﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cata
{
    public class RepositorioEventos
    {
        private List<IEvento> eventosDisponibles { get; set; }

        public RepositorioEventos()
        {
            eventosDisponibles = new List<IEvento>();
        }

        public void listarEventos(int cash)
        {
            if (cash > 0)
            {
                foreach(var ev in eventosDisponibles)
                {
                    Console.WriteLine(ev.devolverNombreEvento());
                }
            }
        }

        public void insertarEvento(IEvento evento)
        {
            this.eventosDisponibles.Add(evento);
        }
    }
}
