﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Usuarios;

namespace Tareas
{
    public class TareaViewModel
    {
        public int Id { get; set; }
        public string NombreUsuario { get; set; }
        public string Title { get; set; }

        public void EscribirTareas(List<Tarea> tareasNoRealizadas, Usuario[] usuarios)
        {
            var tareasViewModel = new List<TareaViewModel>();
            foreach (var tarea in tareasNoRealizadas)
            {
                var tareaViewModel = new TareaViewModel()
                {
                    Id = tarea.Id,
                    Title = tarea.Title.Trim(),
                    NombreUsuario = usuarios.Where(x => x.Id == tarea.UserId).First().Nombre.Trim()
                };
                tareasViewModel.Add(tareaViewModel);
            }
        }
    }
}
