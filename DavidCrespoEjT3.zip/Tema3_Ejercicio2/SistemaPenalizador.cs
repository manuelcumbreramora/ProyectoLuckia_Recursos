﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ejercicio2
{
    public class SistemaPenalizador: Penalizador
    {
        int pena;
        int randNum;
        public override int generarPenalizacion()
        {
            var rand = new Random();
            randNum = rand.Next(1, 4);


            switch (randNum)
            {
                case 1:
                    Console.WriteLine("Ha cometido una penalizacion leve");
                    pena = 100;
                    return pena;
                case 2:
                    Console.WriteLine("Ha cometido una penalizacion grave");
                    pena = 300;
                    return pena;
                case 3:
                    Console.WriteLine("Ha cometido una penalizacion muy grave");
                    pena = 800;
                    return pena;
                default:
                    return 0;

            }

        }

    }
}
