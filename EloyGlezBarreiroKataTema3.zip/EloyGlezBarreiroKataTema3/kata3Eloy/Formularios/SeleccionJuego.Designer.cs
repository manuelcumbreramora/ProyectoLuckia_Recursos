﻿namespace kata3Eloy.Formularios
{
    partial class SeleccionJuego
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SeleccionJuego));
            this.pbF1 = new System.Windows.Forms.PictureBox();
            this.pbBasket = new System.Windows.Forms.PictureBox();
            this.pbFutbol = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pbHome = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbF1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBasket)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFutbol)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbHome)).BeginInit();
            this.SuspendLayout();
            // 
            // pbF1
            // 
            this.pbF1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbF1.Image = ((System.Drawing.Image)(resources.GetObject("pbF1.Image")));
            this.pbF1.Location = new System.Drawing.Point(52, 286);
            this.pbF1.Name = "pbF1";
            this.pbF1.Size = new System.Drawing.Size(185, 99);
            this.pbF1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbF1.TabIndex = 0;
            this.pbF1.TabStop = false;
            this.pbF1.Click += new System.EventHandler(this.pbF1_Click);
            // 
            // pbBasket
            // 
            this.pbBasket.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbBasket.Image = ((System.Drawing.Image)(resources.GetObject("pbBasket.Image")));
            this.pbBasket.Location = new System.Drawing.Point(249, 155);
            this.pbBasket.Name = "pbBasket";
            this.pbBasket.Size = new System.Drawing.Size(186, 99);
            this.pbBasket.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbBasket.TabIndex = 1;
            this.pbBasket.TabStop = false;
            this.pbBasket.Click += new System.EventHandler(this.pbBasket_Click);
            // 
            // pbFutbol
            // 
            this.pbFutbol.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbFutbol.Image = ((System.Drawing.Image)(resources.GetObject("pbFutbol.Image")));
            this.pbFutbol.Location = new System.Drawing.Point(52, 27);
            this.pbFutbol.Name = "pbFutbol";
            this.pbFutbol.Size = new System.Drawing.Size(179, 86);
            this.pbFutbol.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbFutbol.TabIndex = 2;
            this.pbFutbol.TabStop = false;
            this.pbFutbol.Click += new System.EventHandler(this.pbFutbol_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Impact", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(97, 116);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 35);
            this.label1.TabIndex = 3;
            this.label1.Text = "Fútbol";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Impact", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(298, 257);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 35);
            this.label2.TabIndex = 4;
            this.label2.Text = "Basket";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Impact", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(111, 388);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 35);
            this.label3.TabIndex = 5;
            this.label3.Text = "F1";
            // 
            // pbHome
            // 
            this.pbHome.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbHome.Image = ((System.Drawing.Image)(resources.GetObject("pbHome.Image")));
            this.pbHome.Location = new System.Drawing.Point(385, 388);
            this.pbHome.Name = "pbHome";
            this.pbHome.Size = new System.Drawing.Size(50, 43);
            this.pbHome.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbHome.TabIndex = 6;
            this.pbHome.TabStop = false;
            this.pbHome.Click += new System.EventHandler(this.pbHome_Click);
            // 
            // SeleccionJuego
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(474, 450);
            this.Controls.Add(this.pbHome);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pbFutbol);
            this.Controls.Add(this.pbBasket);
            this.Controls.Add(this.pbF1);
            this.MaximumSize = new System.Drawing.Size(492, 497);
            this.MinimumSize = new System.Drawing.Size(492, 497);
            this.Name = "SeleccionJuego";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Apuestas Luckia Eloy";
            ((System.ComponentModel.ISupportInitialize)(this.pbF1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBasket)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFutbol)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbHome)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbF1;
        private System.Windows.Forms.PictureBox pbBasket;
        private System.Windows.Forms.PictureBox pbFutbol;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pbHome;
    }
}