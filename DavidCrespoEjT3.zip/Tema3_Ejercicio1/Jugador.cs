﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ejercicio1
{
    class Jugador : Persona
    {
        public int bonus;
        public int juegos = 0;

        public void apostar() 
        {
            juegos = juegos + 1;
            var rand = new Random();
            bonus = rand.Next(50, 100);
            Console.WriteLine("Apuesta número " +  juegos + " realizada");
            Console.WriteLine("Ha obtenido un bonus de " + bonus + " puntos");
            Console.ReadLine();

        }




    }
}
