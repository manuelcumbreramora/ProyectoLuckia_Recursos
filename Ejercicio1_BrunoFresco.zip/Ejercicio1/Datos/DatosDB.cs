﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public class DatosDB
    {
       private string nom, mail, contra;
       public DatosDB()
       {

       }
       public DatosDB(string nombre, string email, string contrasinal)
       {
            this.nom = nombre;
            this.mail = email;
            this.contra = contrasinal;
       }
       public void setNombre(string nombre)
       {
            this.nom = nombre;
       }
       public void setEmail(string email)
       {
           this.mail = email;
       }
       public void setContra(string contrasinal)
       {
           this.contra = contrasinal;
       }
       public string getNombre()
       {
            return this.nom;
       }
       public string getEmail()
       {
            return this.mail;
       }
       public string getContra()
       {
           return this.contra;
       }
    }
}
