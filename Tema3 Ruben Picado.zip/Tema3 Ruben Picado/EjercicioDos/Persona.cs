﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioDos
{
    class Persona
    {
        public string nombre { get; set; }
        public int edad { get; set; }

        public Persona(string nombre, int edad)
        {
            this.nombre = nombre;
            this.edad = edad;
        }
        public Persona()
        {

        }


        public void registro()
        {
            Console.WriteLine("Indica un nombre");
            string nombre = Console.ReadLine();
            Console.WriteLine("Indica tu edad");
            int.Parse(Console.ReadLine());

        }
    }
}
