﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Interfaces;
using Herencias;

namespace Tema3Ej3B
{
    class Program
    {
        private IPoligono poligono;

        public Program(IPoligono poligono)
        {
            this.poligono = poligono;
        }
        void Calculos()
        {
            Console.WriteLine(poligono.ObtenerLongitud());
            Console.WriteLine(poligono.ObtenerArea());
        }

        static void Main(string[] args)
        {
            Cuadrado cuadrado = new Cuadrado(10);
            Triangulo triangulo = new Triangulo(10);
            triangulo.Altura = 5;
            Program program = new Program(cuadrado);
            program.Calculos();
            Program program2 = new Program(triangulo);
            program2.Calculos();
            Console.ReadKey();
        }
    }
}
