﻿using InterfazTipoJuego;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMaquinaFisica
{
    public class MaquinaFisica : IJuego
    {
        public string NombreMaquina;

        public MaquinaFisica(String nombre)
        {
            NombreMaquina = nombre;

        }
        public void jugar()
        {
            Console.WriteLine("Jugamos en MAQUINA FISICA ");
        }
    }
}
