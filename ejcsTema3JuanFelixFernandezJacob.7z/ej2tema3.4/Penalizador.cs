﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ej2tema3._4
{
    abstract class Penalizador
    {

        internal enum TipoPenalizacion { Tipo1, Tipo2, Tipo3 };

        internal virtual void Penalizar(Jugador jugador, Juego juego, TipoPenalizacion tipo)
        {
            // Penalización por omisión.
            jugador.CambiarPuntos(-5000);
        }
    }
}
