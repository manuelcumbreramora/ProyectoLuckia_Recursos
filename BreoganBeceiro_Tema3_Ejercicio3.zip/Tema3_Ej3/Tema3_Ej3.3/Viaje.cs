﻿//BreoBeceiro:25/03/2020
//PLEXUS | Tema3

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ej3._3
{
    public class Viaje
    {
        public string id { get; set; }
        public string origen { get; set; }
        public string destino { get; set; }
        public DateTime salida { get; set;}
        public DateTime llegada { get; set; }


        public Viaje() { }
    }
}
