﻿using System;

namespace DatosProyecto
{
    public class Datos : Usuario
    {
        public void enviarDatos(string usuario, string password)
        {
            String puntos = ".";
            for (int i=0;i<6;i++)
            {
                Console.WriteLine(puntos);
                puntos += puntos;
            }
            guardarUsuario(usuario, password);
            Console.WriteLine("Usuario y contraseña registrado en nuestra base de datos!");
            Console.WriteLine("Un saludo y gracias.");
        }
    }
}
