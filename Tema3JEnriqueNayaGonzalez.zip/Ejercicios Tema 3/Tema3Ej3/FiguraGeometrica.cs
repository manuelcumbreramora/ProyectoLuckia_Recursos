﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3Ej3
{
    abstract class FiguraGeometrica
    {
        double area { get; set; }
        double longitud { get; set; }
        public virtual double obtenerArea(int lado)
        {
            return lado * lado;
        }
    }
}
