﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ejercicio_3._2.Datos;
using Persistencia;

namespace Ejercicio_3._2.Usuarios
{
    class Profesor: Usuario
    {
        private Array asignaturas { get; set; }
        public Profesor(String nombre, string contra, Array asignaturas) : base(nombre, contra)
        {
            this.asignaturas = asignaturas;
        }

        public Profesor()
        {
        }

        public void verNotas(int asignatura)
        {
            Console.WriteLine("Ver las notas de todos los alumnos de una asignatura");
        }
        public void verNotas()
        {
            Console.WriteLine("Ver las notas de todos los alumnos de todas las asignaturas que tenga asignado");
        }

        public void cargarNotas()
        {
            ManejoDatos datos = new ManejoDatos(new SQL());
            datos.cargaDatos(asignaturas);

        }

        public void guardarNotas()
        {
            ManejoDatos datos = new ManejoDatos(new XML());
            datos.guardaDatos(asignaturas);
        }
    }
}
