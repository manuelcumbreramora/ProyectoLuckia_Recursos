﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Base
{
    public class HistorialApuestas
    { 
        public void mostrarHistorial()
        {
            //obetenerEventos();
            obtenerSaldos();
            throw new NotImplementedException();
        }

        public List<Evento> obtenerEventos()
        {
            //Guardar en historial
            throw new NotImplementedException();
        }

        public List<Monedero> obtenerSaldos()
        {
            //Guardar eb historial
            throw new NotImplementedException();
        }

    }
}
