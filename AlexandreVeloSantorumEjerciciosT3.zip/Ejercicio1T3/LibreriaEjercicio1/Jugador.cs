﻿using System;
using System.Collections.Generic;
using System.Text;
using PersonaClase;

namespace JugadorClase
{
    public class Jugador : Persona
    {
        public int Bonus { get; set; }
        public int Juegos { get; set; }

        public Jugador(Persona p)
        {
            Nombre = p.Nombre;
            Edad = p.Edad;
            Suscripcion = p.Suscripcion;
            Bonus = 0;
            Juegos = 0;
        }

        public void apostar(string cantidad)
        {
            if (Suscripcion)
            {
                int juegos = Int32.Parse(cantidad);
                Random rn = new Random();
                Juegos += juegos;
                Bonus = rn.Next(100);
                Console.WriteLine("Has jugado " + Juegos + " y tienes un bonus de " + Bonus);
            }
            else
            {
                Console.WriteLine("Tienes que activar tú cuenta para apostar");
            }

        }
    }
}
