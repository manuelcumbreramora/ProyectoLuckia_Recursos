﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaNegocio;

namespace CapaConsola
{
    class Program
    {
        //Recojo los datos y los mando a negocio.
        
        static void Main(string[] args)
        {
            Usuario usuarito = new Usuario();
            string nombre;
            string pass;
            string mail;

            Console.WriteLine("Inserte nombre de usuario.");
            nombre = Console.ReadLine();
            Console.WriteLine("Inserte contraseña.");
            pass = Console.ReadLine();
            Console.WriteLine("Inserte el mail.");
            mail = Console.ReadLine();

            usuarito.Nombre = nombre;
            usuarito.Pass = pass;
            usuarito.Mail = mail;
            Console.WriteLine("Usuario añadido, gracias.");

        }
    }
}
