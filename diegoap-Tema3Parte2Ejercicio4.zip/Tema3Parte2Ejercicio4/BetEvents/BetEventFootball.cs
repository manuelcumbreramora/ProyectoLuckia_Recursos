﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BetEvents
{
    public class BetEventFootball : AbstractBetEvent
    {
        public BetEventFootball(int id, DateTime date, Bettor.Bettor bettor) : base(id, date, "football", bettor) { }

        public BetEventFootball(int id, Bettor.Bettor bettor) : base(id, new DateTime(), "football", bettor) { }

        // Fake, random calculation.
        // The first element is 'true' or 'false' and corresponds to the pool.
        // The second element is 'true' or 'false' and corresponds to the result.
        public override string[] reportResult()
        {
            Random rnd = new Random(Guid.NewGuid().GetHashCode());

            bool pool, result;
            do
            {
                pool = (rnd.NextDouble() < 0.33) ? true : false;
                result = (rnd.NextDouble() < 0.25) ? true : false;
            } while ((result) && (!pool));

            return (new string[] { pool.ToString(), result.ToString() });
        }

        public override string resultHumanReadable(string[] result)
        {
            return ("pool " + result[0].ToLower() + ", result " + result[1].ToLower());
        }
    }
}
