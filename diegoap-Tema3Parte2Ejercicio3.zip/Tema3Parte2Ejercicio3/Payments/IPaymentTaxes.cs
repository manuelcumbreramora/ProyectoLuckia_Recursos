﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Taxes;

namespace Payments
{
    interface IPaymentTaxes
    {
        // The amount the taxes are applied to.
        float getAmount();

        // Get all the taxes.
        List<ITax> getAllTaxes();

        // Calculate the total taxes for a given amount.
        float calculateTotalTaxes();
    }
}
