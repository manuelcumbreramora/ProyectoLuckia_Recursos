﻿/*Se pide implementar un sistema capaz de calcular el importe a abonar a un jugador.
Para el cálculo de dicho importe, nos basaremos en los puntos obtenidos en las apuestas de realizadas 
por el jugador en tres diferentes modalidades: Atletismo, Fútbol, Carreras. 

Para cada modalidad, los puntos se calculan de diferente manera: 
* En la modalidad Atletismo, los puntos obtenidos en la apuesta se dividen por 2. 
* En Futbol, se obtiene 0, 200 ó 300 puntos en función de si el jugador: 
--ha fallado el resultado y fallado la quiniela, 
--ha fallado el resultado pero ha acertado la quiniela, 
--ha acertado resultado. 
* En Carreras, los puntos obtenidos se dividen por 10.

El sistema central, calculará el importe a abonar al jugador, multiplicando los puntos obtenidos por 15.
 
-Punto 1 .- Definir las entidades (Jugador,Evento,SistemaCentral) usando abstracción.
-Punto 2 .- Definir el proceso de calculo de puntos aplicando el pincipio de encapsulamiento.
-Punto 3 .- Aplicar polimorfismo a los métodos responsables de calcular el importe de cada evento.

Condiciones:

Para el calculo, se partirá de un array de apuestas inicial, a partir del cual se hará el proceso.
Se implementará un sistema aleatorio de generación de puntos para cada tipo de evento.
*/



using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ejercicio4
{
    class Program
    {
        static void Main(string[] args)
        {
            int ganancia = 0;
            Jugador jug = new Jugador();
            jug.saldo= 0;
            SistemaCentral sist = new SistemaCentral();

            Console.WriteLine("Actualmente tiene " + jug.saldo + " euros");
            Console.WriteLine("Vamos a procesar sus apuestas");

            ganancia = sist.generarSaldo();
            Console.WriteLine("Ha ganado un total del " + ganancia/100 + " euros");
            Console.ReadLine();

        }
    }
}
