﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurantes
{
    public abstract class Restaurante : Visitar
    {
        public Restaurante(string nom, string tipo)
        {
        }
        public Restaurante() { }

        public abstract void visita();
    }
}
