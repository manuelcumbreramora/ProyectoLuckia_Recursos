﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bettor
{
    public class Bettor
    {
        public int id { get; }

        public string name { get; }
        
        public Bettor(int id, string name)
        {
            this.id = id;
            this.name = name;
        }
    }
}
