﻿using PApuesta;
using PEventos;
using PMonedero;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PJugador
{
    public class Jugador
    {
        private int IdUltimoApuesta = 0;

        private String Login;
        private String Password;
        public Monedero MonederoJugador;
        public List<Apuesta> ApuestasJugador;

        public Jugador(String login, String pass, int saldo)
        {
            Login = login;
            Password = pass;
            MonederoJugador = new Monedero(saldo);
            ApuestasJugador = new List<Apuesta>();
        }
        public bool ComprobarPass(string pass)
        {
            Boolean exitoComprobar=false;
            if (this.Password == pass)
            {
                exitoComprobar = true;
            }
            return exitoComprobar;
        }
        public string getLogin()
        {
            return this.Login;
        }
        public void CrearApuesta(int importe, IEventos evento, int resultado)
        {
            this.IdUltimoApuesta = this.IdUltimoApuesta + 1;
            if (importe < this.MonederoJugador.GetCash()) {
                this.MonederoJugador.RetirarSaldo(importe);
                Apuesta nuevaApuesta = new Apuesta(this.IdUltimoApuesta, importe, evento, resultado);
                this.ApuestasJugador.Add(nuevaApuesta);
                Console.WriteLine("Apuestra creada con exito");
                nuevaApuesta.MostrarApuesta();
            }
            else
            {
                Console.WriteLine("El jugador no tiene suficiente saldo");
            }
        }
        public void ResolverApuestas()
        {
            foreach (Apuesta apuestaSinResolver in this.ApuestasJugador)
            {
                apuestaSinResolver.ResolverApuesta();
                if (apuestaSinResolver.GetResultadoFinal() == 1)
                {
                    this.MonederoJugador.SumarSaldo(apuestaSinResolver.GetImporteApuesta() * 2);
                    Console.WriteLine("Ingresamos {0} en monedero de jugador", apuestaSinResolver.GetImporteApuesta());
                    
                }else if(apuestaSinResolver.GetResultadoFinal() == 2)
                {
                    Console.WriteLine("El jugador a perdido, no se hara ningun ingreso.");
                }else if(apuestaSinResolver.GetResultadoFinal() == 0)
                {
                    Console.WriteLine("El evento aun no se ha resuelto, intentelo más tarde.");
                }

            }
        }
        public void MostrarHistorialApuestas()
        {
            foreach (Apuesta apuestaMostrar in this.ApuestasJugador)
            {
                apuestaMostrar.MostrarApuesta();
            }
        }
        public void MostrarJugador()
        {
            Console.WriteLine("Login: {0}", this.Login);
            Console.WriteLine("Saldo: {0} {1}", this.MonederoJugador.GetCash(), this.MonederoJugador.getTipoMoneda());
        }
     
    }
}
