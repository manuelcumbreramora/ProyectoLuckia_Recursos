﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JuegoPersona
{
    public class Persona
    {
      private String Nombre { get; set; }

        private int Edad { get; set; }

        public int Monedero { get; set; }
        public Persona()
        {

        }
        public Persona(int edad, string nombre,int monedero)
        {

            Nombre = nombre;
            Edad = edad;
            Monedero = monedero;

        }
        public void mostrarPersona()
        {
            Console.WriteLine("Jugador {0}", this.Nombre);
            Console.WriteLine("Edad {0}", this.Edad);
            Console.WriteLine("Monedero {0}", this.Monedero);
        }
        public string getNombre()
        {
            return this.Nombre;
        }
    }

}
