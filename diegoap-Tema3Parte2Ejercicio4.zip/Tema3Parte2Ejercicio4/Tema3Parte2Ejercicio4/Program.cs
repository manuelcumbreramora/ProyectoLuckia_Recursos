﻿using BetEvents;
using PointsCalculator;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3Parte2Ejercicio4
{
    class Program
    {
        static List<Bettor.Bettor> bettors;
        static List<AbstractBetEvent> betEvents;

        static void Main(string[] args)
        {
            initBettors();
            initBets();

            CentralSystem.CentralSystem.showBetResults(betEvents);

            Console.Write("\n>>> Press any key to exit ... ");
            Console.ReadKey();
        }

        static void initBettors()
        {
            bettors = new List<Bettor.Bettor>();
            bettors.Add(new Bettor.Bettor(2369, "Daniel Torres"));
            bettors.Add(new Bettor.Bettor(4094, "James Paul Halsey"));
            bettors.Add(new Bettor.Bettor(6706, "Jean-Baptiste Erdaux"));
            bettors.Add(new Bettor.Bettor(5251, "Paolo Manzoni"));
            bettors.Add(new Bettor.Bettor(5251, "Johann Döblin"));
            bettors.Add(new Bettor.Bettor(1359, "Andréi Turguénev"));
            bettors.Add(new Bettor.Bettor(4229, "Mika Oksanen"));
            bettors.Add(new Bettor.Bettor(9657, "Frank Enquist"));
            bettors.Add(new Bettor.Bettor(6841, "Willem Haafner"));
        }

        static void initBets()
        {
            int numBets = 25;
            betEvents = new List<AbstractBetEvent>();

            Random rnd = new Random(Guid.NewGuid().GetHashCode());
            for (int i = 0; i < numBets; i++)
            {
                AbstractBetEvent betEvent;
                double d = rnd.NextDouble();

                int index = rnd.Next(0, bettors.Count);
                Bettor.Bettor bettor = bettors.ElementAt(index);

                if (d <= 0.33)
                {
                    betEvent = new BetEventAthletics(i, bettor);
                }
                else if ((d > 0.33) && (d <= 0.66))
                {
                    betEvent = new BetEventFootball(i, bettor);
                } 
                else
                {
                    betEvent = new BetEventRacing(i, bettor);
                }

                betEvents.Add(betEvent);
            }

        }
    }
}
