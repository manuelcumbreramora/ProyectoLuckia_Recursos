﻿using JuegoJuego;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JuegoBoleibol
{
    public class JVoleibol : Juego
    {

        public JVoleibol(string nombre, string equipo1, string equipo2)
        {
            Nombre = nombre;
            Equipo1 = equipo1;
            Equipo2 = equipo2;
            Penalizacion = 3;
            Ganador = "Sin jugar";
        }
    }
}

