﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ejercicio2
{
    class Jugador:Persona
    {

        public int Monedero { get; set ; }


        public int setMonedero()
        {
            
            var rand = new Random();
            Monedero = rand.Next(1000, 10000);
            Console.WriteLine("Actualmente su saldo es de  " + Monedero + " euros");
            Console.ReadLine();
            return Monedero;
        }

    }
}
