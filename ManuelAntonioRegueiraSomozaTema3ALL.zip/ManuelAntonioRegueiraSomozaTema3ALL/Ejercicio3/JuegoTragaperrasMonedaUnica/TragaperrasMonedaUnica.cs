﻿using JuegoTragaperras;
using OperacionesGeneracionAleatorias;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JuegoTragaperrasMonedaUnica
{
    public class TragaperrasMonedaUnica:Tragaperras
    {
        private int MonedaMinima;


        public TragaperrasMonedaUnica(int numeroLineas, string nombreJuego, int monedaMinima)
        {
            NombreJuego = nombreJuego;
            NumeroLineas = numeroLineas;
            MonedaMinima = monedaMinima;

        }
        
        public void MostrarDetallesDatosJuego()
        {
            this.MostrarDatosJuego();
            Console.WriteLine("Numero Moneda Minima {0}", this.MonedaMinima);
        }
    }
}
