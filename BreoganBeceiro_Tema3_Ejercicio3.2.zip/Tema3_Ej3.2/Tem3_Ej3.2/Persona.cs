﻿//BreoBeceiro:24/03/2020
//PLEXUS | Tema3

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ej3
{
    public abstract class Persona
    {
        private int id { get; set; }
        public string usuario { get; set; }
        public string contrasena { get; set; }


        public virtual bool solicitaHistorial(string id)
        {
            return true;
        }
    }
}
