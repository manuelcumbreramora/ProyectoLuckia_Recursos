﻿using JuegoMesa;
using OperacionesGeneracionAleatorias;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JuegoRuletaAmericana
{
    public class MesaRuletaAmericana :Mesa
    {

        private int IdRuleta;
    
        public MesaRuletaAmericana(int numMesa, int idRuleta,string nombreJuego)
        {
            NombreJuego = nombreJuego;
            NumeroMesa = numMesa;
            IdRuleta = idRuleta;
        }
        public void MostrarDetallesDatosJuego()
        {
            this.MostrarDatosJuego();
            Console.WriteLine("Numero de Ruleta {0}", this.IdRuleta);
        }
    }
}
