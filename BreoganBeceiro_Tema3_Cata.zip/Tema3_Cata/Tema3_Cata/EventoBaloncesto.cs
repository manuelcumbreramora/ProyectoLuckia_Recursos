﻿//BreoBeceiro:26/3/2020
//PLEXUS | Tema3

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Cata
{
    public class EventoBaloncesto : Evento
    {
        public string local { get; set; }
        public string visitante { get; set; }
        public string competicion { get; set; }


        public string resultadoEvento(string datetime, string tournament, string local, string visitor)
        {
            //Se consulta a la BBDD para obtener el resultado...
            return "0-2";
        }
    }
}
