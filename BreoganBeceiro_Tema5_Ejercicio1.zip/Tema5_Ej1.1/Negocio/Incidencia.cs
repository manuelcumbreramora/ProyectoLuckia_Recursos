﻿//BreoBeceiro:30/03/2020
//PLEXUS | Tema5.1

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Persistencia;

namespace Negocio
{
    public class Incidencia
    {
        public string titulo { get; set; }
        public string descripcion { get; set; }
        public string numero { get; set; }


        public Incidencia() { }

        public Incidencia(string _titulo, string _descripcion)
        {
            titulo = _titulo;
            descripcion = _descripcion;
        }

        /// <summary>
        /// Envía una incidencia y la registra en BBDD.
        /// </summary>
        public void nuevaIncidencia()
        {
            DAO.registraIncidencia(this.titulo, this.descripcion);
        }
    }
}
