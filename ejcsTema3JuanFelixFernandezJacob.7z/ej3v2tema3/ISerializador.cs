﻿using System;

namespace ej3v2tema3
{
    public interface ISerializador
    {
        String InicioEntidad(String nombre);
        String Atributo(String nombre, string valor);
        String Atributo(String nombre, int valor);
        String FinEntidad();
        String Atributo(String nombre, double precioUnitario);
        String AbrirLista();
        String CerrarLista();
        String SeparadorLista();
    }
}