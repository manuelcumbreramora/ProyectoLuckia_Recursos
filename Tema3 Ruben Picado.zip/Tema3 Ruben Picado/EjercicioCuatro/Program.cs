﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioCuatro
{
    public class Program
    {

        static void Main(string[] args)
        {
            SistemaCentral sys = new SistemaCentral();
            Jugador jugador = new Jugador();
            jugador.monedero = 0;
            Atletismo atletismo = new Atletismo();
            Futbol futbol = new Futbol();
            Carreras carreras = new Carreras();
            foreach (Apuesta apuesta in jugador.GenerarApuestas())
            {
                if (apuesta.evento == 1)
                {
                    jugador.monedero = jugador.monedero + atletismo.CalculoPuntos(jugador, apuesta.importeApostado);
                }
                if (apuesta.evento == 2)
                {
                    jugador.monedero = jugador.monedero + futbol.CalculoPuntos(jugador, apuesta.importeApostado);
                }
                else if (apuesta.evento == 3)
                {
                    jugador.monedero = jugador.monedero + carreras.CalculoPuntos(jugador, apuesta.importeApostado);
                }

            }
            sys.mostrarTotalImporte(jugador);
            Console.ReadKey();
            

        }
    }
}
     