﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Games;
using Penalizations;
using Users;

namespace BettorPenalties
{
    public abstract class AbstractPenalty : IPenalty
    {
        public enum PenaltySeverity { Low = 0, Medium = 10, High = 20 };

        public int Id { get; }

        public AbstractGame Game { get; }

        public IBettor Bettor { get; }

        public PenaltySeverity Severity { get; }

        public AbstractPenalty(int id, AbstractGame game, IBettor bettor, PenaltySeverity severity)
        {
            this.Id = id;
            this.Game = game;
            this.Bettor = bettor;
            this.Severity = severity;
        }

        public int GetId()
        {
            return this.Id;
        }

        public virtual void ExecutePenalty()
        {
            float _wallet = this.Bettor.GetWallet() - this.GetPenaltyAmount();
            _wallet = (_wallet < 0f) ? 0f : _wallet;

            this.Bettor.SetWallet(_wallet);
        }

        public IBettor GetBettor()
        {
            return this.Bettor;
        }

        public AbstractGame GetGame()
        {
            return this.Game;
        }

        public abstract float GetPenaltyBaseAmount();

        public abstract float GetPenaltyAmount();

        public PenaltySeverity GetSeverity()
        {
            return this.Severity;
        }
    }
}
