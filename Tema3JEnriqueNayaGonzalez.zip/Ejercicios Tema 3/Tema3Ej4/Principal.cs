﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3Ej4
{
    class Principal
    {
        static void Main(string[] args)
        {
            List<Apuesta> apuestas = new List<Apuesta>();
            generarApuestas(apuestas);
            foreach (var item in apuestas)
            {
                SistemaCentral.RealizarApuesta(item);
            }
            Console.ReadKey();
        }
        public static void generarApuestas(List<Apuesta> apuestas)
        {            
            Apuesta apuesta = new Apuesta("Sobera",1,1000);
            apuestas.Add(apuesta);
            Apuesta apuesta2 = new Apuesta("Carlos", 2, 500);
            apuestas.Add(apuesta2);
            Apuesta apuesta3 = new Apuesta("Javivi", 2, 50);
            apuestas.Add(apuesta3);
            Apuesta apuesta4 = new Apuesta("Lolo", 3, 20);
            apuestas.Add(apuesta4);
            Apuesta apuesta5 = new Apuesta("Pelocho", 1, 11888);
            apuestas.Add(apuesta5);

        }
    }
}
