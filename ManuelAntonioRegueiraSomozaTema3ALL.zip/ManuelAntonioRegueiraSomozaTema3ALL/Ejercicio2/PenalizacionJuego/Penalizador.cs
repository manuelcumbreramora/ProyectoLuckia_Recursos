﻿using JuegoJuego;
using JuegoPersona;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PenalizacionJuego
{
    public abstract class Penalizador
    {
        protected Persona JugadorPenalizado { get; set; }
        protected DateTime Fecha { get; set; }
        protected int Penalizacion { get; set; }
        public Penalizador()
        {

        }

        public virtual void PenalizarPersonaJuego(Persona persona, Juego juego)
        {
            this.JugadorPenalizado = persona;
            this.Fecha = DateTime.Now;
            this.Penalizacion = juego.Penalizacion;
            persona.Monedero = persona.Monedero - juego.Penalizacion;
        }
            
    }
}
