﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Negocio;

namespace Consola
{
    class ConsolaAc
    {
        
        static void Main(string[] args)
        {   
            NegocioAc n1 = new NegocioAc();
            Console.WriteLine("Introduzca sus datos.");
            Console.WriteLine("Nombre de usuario:");
            string nombre = Console.ReadLine();
            n1.Nombre(nombre);
            Console.WriteLine("Email:");
            string email = Console.ReadLine();
            n1.Email(email);
            Console.WriteLine("Contraseña:");
            string contra = Console.ReadLine();
            n1.Contra(contra);
            Console.WriteLine("Registro finalizado.");
        }
    }
}
