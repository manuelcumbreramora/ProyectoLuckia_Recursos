﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ej3v2tema3
{
    class Almacen
    {

        public List<Producto> Productos { get; set; }
        public void EscribirInformacion(ISerializador serializador)
        {
            StringBuilder salida = new StringBuilder();

            salida.Append(serializador.AbrirLista());

            
            foreach (Producto prod in Productos)
            {
                prod.EscribirInformacion(salida, serializador);
                salida.Append(serializador.SeparadorLista());
            }

            salida.Append(serializador.CerrarLista());

            Console.WriteLine(salida.ToString());
        }
    }
}
