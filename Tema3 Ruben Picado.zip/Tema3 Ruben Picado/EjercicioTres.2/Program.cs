﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio3._2
{
    class Program
    {
        static void Main(string[] args)
        {
            var conductor = new Conductor(new tipoVehiculo1());
            conductor.Conducir();
            Console.WriteLine(" Estoy conduciendo un coche");
            Console.ReadLine();
        }
    }
}
