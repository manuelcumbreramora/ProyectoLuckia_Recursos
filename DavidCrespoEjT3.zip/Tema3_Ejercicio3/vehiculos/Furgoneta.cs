﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ejercicio3
{
    class Furgoneta:Vehiculo
    {
        public int capacidadm3 { get; set; }

        //Aquí la matrícula es la que se genera en la clase vehiculo

    }
}
