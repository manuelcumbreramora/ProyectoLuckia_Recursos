﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ejercicio5
{
    class Casino3 : ICasino
    {
        int cartaGenint, ganancia;
        String carta, cartaGen;
        public int Juego()
        {
            var rand = new Random();
            cartaGenint = rand.Next(1, 4);

            switch (cartaGenint)
            {
                case 1:
                    cartaGen = "sota";
                    break;
                case 2:
                    cartaGen = "caballo";
                    break;
                case 3:
                    cartaGen = "rey";
                    break;
            }


            Console.WriteLine("Has apostado 100 euros!!");
            Console.WriteLine("Está jugando a acierta la carta");
            Console.WriteLine("Escriba \"sota\", \"caballo\" o \"rey\"");
            carta = Console.ReadLine();
            if (carta == cartaGen)
            {
                Console.WriteLine("Ha ganado 300 euros!!");
                ganancia = 300;
                return ganancia;
            }
            else
            {
                Console.WriteLine("Has perdido...");
                ganancia = 0;
                return ganancia;
            }


        }


    }
}
