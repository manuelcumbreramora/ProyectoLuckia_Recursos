﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaxCalculator;
using Taxes;
using Users;

namespace Payments
{
    public class RacingBetPayment : AbstractPayment
    {
        public RacingBetPayment(User user, float amount, ITaxCalculator taxCalculator) : base("RacingBetPayment", user, amount, taxCalculator) { }

        public override float calculateTotalTaxes()
        {
            float _amount = this.getAmount();

            float t;
            float totalTaxes = 0f;
            foreach (AbstractTax item in this.getAllTaxes())
            {
                t = item.calculateTax(_amount);
                totalTaxes = totalTaxes + t;
                _amount = _amount - t;
            }

            return totalTaxes;
        }

        public override List<ITax> getAllTaxes()
        {
            return (new List<ITax>() { new TaxVatEs()});
        }
    }
}
