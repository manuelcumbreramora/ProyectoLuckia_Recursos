﻿using System;


namespace EjercicioUno
{
    public class Consola
    {
        public static void Main(string[] args)
        {
            String user, pass;
            Console.WriteLine("¿Escriba el nombre de usuario que desea guardar)");
            user = Console.ReadLine();
            Console.WriteLine("¿Escriba la contraseña que desea guardar)");
            pass = Console.ReadLine();
            Console.WriteLine(" El nombre de usuario que va a guardar es :" + user + pass);
            Negocio negocio = new Negocio();
            negocio.recogerDatos(user, pass);


        

        }
    }
}
