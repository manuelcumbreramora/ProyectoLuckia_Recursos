﻿using System;
using NegocioProyecto;

namespace ConsolaProyecto
{
    class Consola
    {
        static void Main(string[] args)
        {
            String usuario, password;
            usuario = " ";
            Negocio negocio = new Negocio();
            Console.WriteLine("Escribe un usuario ->");
            usuario = Console.ReadLine();
            while (usuario != " " && usuario != "")
            {
                Boolean ok = false;
                while (ok != true)
                {
                    Console.WriteLine("Escribe una contraseña ->");
                    password = Console.ReadLine();
                    negocio.obtenerDatos(usuario, password, ok);

                }
            }
            
        }
    }
}
