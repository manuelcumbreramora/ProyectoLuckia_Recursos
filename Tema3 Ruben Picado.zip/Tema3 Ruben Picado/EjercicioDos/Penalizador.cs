﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioDos
{
    public class Penalizador
    {
        public int penalizador()
        {
            int randN;
            int perdida;
            var rand = new Random();
            randN = rand.Next(1, 3);
            switch (randN)
            {
                case 1:
                    Console.WriteLine("Penalizacion mas alta");
                    perdida = 100;
                    return perdida;

                case 2:
                    Console.WriteLine("Penalizacion intermedia");
                    perdida = 60;
                    return perdida;

                case 3:
                    Console.WriteLine("Penalizacion mas baja");
                    perdida = 30;
                    return perdida;
                default:
                    return 0;

            }
        }
    }
}
