﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ej4tema3
{
    class ApuestaCarrera : Apuesta
    {
        ResultadoGanador ResultadoApuesta;

        public ApuestaCarrera(int importe, IEvento evento, ResultadoGanador resultadoApostado, Jugador jugador) : base(importe, evento, jugador)
        {
            this.ResultadoApuesta = resultadoApostado;
        }

        public override int CalcularPuntosGanados()
        {
            Resultado resultadoEvento = Evento.ObtenerResultado();

            if (!(resultadoEvento is null))
            {
                // No hay resultado todavía.
                return 0;
            }
            else
            {
                int tipoAcierto = ResultadoApuesta.Comparar(resultadoEvento);

                switch (tipoAcierto)
                {
                    case 0:
                        // Nada
                        return 0;
                    case 1:
                        // Acierta el ganador
                        return Importe / 10;
                    default:
                        throw new Exception("Valor desconocido");
                }
            }
        }
    }
}

