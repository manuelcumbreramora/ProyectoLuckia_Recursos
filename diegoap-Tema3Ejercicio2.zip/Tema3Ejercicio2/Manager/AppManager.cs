﻿using Games;
using Penalizations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Users;

namespace AppManager
{
    public static class AppManager
    {
        public static List<IPenalty> GetUserPenalties(List<IPenalty> penalties, int bettorId)
        {
            List<IPenalty> bettorPenalties = new List<IPenalty>();

            int _bettorId;
            foreach (IPenalty item in penalties)
            {
                _bettorId = item.GetBettor().GetId();
                if (_bettorId == bettorId)
                {
                    bettorPenalties.Add(item);
                }
            }

            return bettorPenalties;
        }

        public static IBettor GetUserById(List<IBettor> bettors, int bettorId)
        {
            foreach (IBettor item in bettors)
            {
                if (item.GetId() == bettorId)
                {
                    return item;
                }
            }

            return null;
        }
    }
}
