﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio1
{
    public class Jugador : Persona
    {
        public int Bonus { get; set; }
        public int Juegos { get; set; }

        public Jugador()
        {
        }

        public Jugador(string nombre, int edad) : base(nombre, edad)
        {
        }

        public Jugador(string nombre, int edad, int bonus, int juegos) : base(nombre, edad)
        {
            this.Bonus = bonus;
            this.Juegos = juegos;
        }

        

        public void apostar()
        {
            Random random = new Random();
            this.Juegos++;
            this.Bonus += random.Next(0, 100);
#if DEBUG
            Console.WriteLine("Contador juegos: " + this.Juegos);
            Console.WriteLine("Bonus: " + this.Bonus);
            Console.ReadKey();
#endif
        }

    }
}
