﻿using BettorPenalties;
using Games;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Users;

namespace Penalizations
{
    public class BasketballPenalty : AbstractPenalty
    {
        public BasketballPenalty(int id, IBettor bettor, PenaltySeverity severity) : base(id, new Basketball(), bettor, severity) { }

        public override float GetPenaltyAmount()
        {
            float _penaltyAmount = this.GetPenaltyBaseAmount();

            switch (this.Severity)
            {
                case PenaltySeverity.Low:
                    _penaltyAmount = _penaltyAmount * 0.85f;
                    break;
                case PenaltySeverity.Medium:
                    _penaltyAmount = _penaltyAmount * 1.25f;
                    break;
                case PenaltySeverity.High:
                    _penaltyAmount = _penaltyAmount * 1.50f;
                    break;
            }

            return _penaltyAmount;
        }

        public override float GetPenaltyBaseAmount()
        {
            float _penaltyBaseAmount = 0.05f * this.Bettor.GetWallet();

            _penaltyBaseAmount = (_penaltyBaseAmount == 0f) ? 25f : _penaltyBaseAmount;
            _penaltyBaseAmount = (_penaltyBaseAmount > 50f) ? 50f : _penaltyBaseAmount;

            return _penaltyBaseAmount;
        }
    }
}
