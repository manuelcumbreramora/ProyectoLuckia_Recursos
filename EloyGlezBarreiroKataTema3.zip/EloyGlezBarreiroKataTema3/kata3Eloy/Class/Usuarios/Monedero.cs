﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kata3Eloy
{
    public static class Monedero
    {
        private static double cartera = 0;

        public static double Cartera { get => cartera; set => cartera = value; }
    }
}
