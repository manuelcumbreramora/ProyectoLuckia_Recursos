﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ejercicio5
{
    class Casino2 : ICasino
    {
        
        int numJug, numGen, ganancia;
        public int Juego()
        {
            var rand = new Random();
            numGen = rand.Next(1, 2);

            Console.WriteLine("Has apostado 100 euros!!");
            Console.WriteLine("Está jugando a pares o nones");
            Console.WriteLine("Elija par (1) o impar (2)");
            numJug = Int16.Parse(Console.ReadLine());
            if (numJug == numGen)
            {
                Console.WriteLine("Ha ganado 100 euros!!");
                ganancia = 100;
                return ganancia;
            }
            else
            {
                Console.WriteLine("Has perdido...");
                ganancia = 0;
                return ganancia;
            }


        }



    }
}
