﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio2
{
    public class Jugador : Persona
    {
        private int Bonus { get; set; }
        private int Juegos { get; set; }
        public Monedero monedero { get; set; }
        public Jugador(Monedero _monedero)
        {
            this.monedero = _monedero;
        }


        public void apostar()
        {
            Random random = new Random();
            this.Juegos++;
            this.Bonus += random.Next(0, 100);
#if DEBUG
            Console.WriteLine("Contador juegos: " + this.Juegos);
            Console.WriteLine("Bonus: " + this.Bonus);
            Console.ReadKey();
#endif
        }
    }
}
