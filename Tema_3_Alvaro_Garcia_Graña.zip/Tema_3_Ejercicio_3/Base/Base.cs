﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Herencia;
using Polimorfismo;
using Encapsulamiento;


namespace Base
{
    class Base : HerenciaClass
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Bienvenido al simulador de desastres!!");
            PolimorfismoClass polimorfismo = new PolimorfismoClass();
            HerenciaClass herencia = new HerenciaClass();
            EncapsulamientoClass encapsulamiento = new EncapsulamientoClass();
            Random random = new Random();

            Console.WriteLine("Somos " + aforoMaximo + " en el recinto y debemos sobrevivir con más de 50 individuos a lo que el mundo nos depare!");


            // Herencia y referenciada a Base.
            // Dentro de herencia implementacion interfaz
            herencia.generarDesastreNatural(random.Next(0, 100));

            //Polimorfismo
            polimorfismo.meotodoPolimorfista(aforoMaximo);


            //Clase estática contenida en el método su inicialización.
            if (aforoMaximo < 50 && aforoMaximo >= 1)
            {
                herencia.pedirRefuerzos();
                if (aforoMaximo < 50)
                {
                    Console.WriteLine("No has superado el día, tienes menos de 50 individuos en el recinto.");
                }
                else
                {
                    Console.WriteLine("Has superado el día con " + aforoMaximo + " individuos!");
                }
            } else
            {
                Console.WriteLine("Has superado el día con " + aforoMaximo + " individuos!");
             }

            //Encapsulamiento
            encapsulamiento.metodoPublico(random.Next(0,100), aforoMaximo);
            Console.ReadKey();
        }
    }
}
