﻿/*Se plantea el sistema de penalización del proceso de apuestas de Luckia.
En función de las malas prácticas detectadas en cada Jugador en los deportes de Futbol, Balonmano y Boleibol, 
se sugieren 3 tipos de penalizaciones, que afectarán al Monedero actual del jugador.

Se pide: 
*Definir las clases base: Persona y Juego, del cual heredarán las clases hijas que se identifiquen.
* Definir la clase abstracta Penalizador, del cual heredará la clase core encargada de dicho proceso. Debe tener un método virtual
*Definir los atributos y métodos de cada clase, junto a sus modificadores de acceso.*/



using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ejercicio2
{
    class Program
    {
        static void Main(string[] args)
        {
            int monedero; //Cambiar y acceder al monedero del jugador, porque es public
            int restaMonedero;
            int eleccion;
            Jugador jugador = new Jugador();

            jugador.realizarSuscripcion();
            monedero = jugador.setMonedero();

            Juego juego = new Juego();
            eleccion = juego.elegirJuego();
            switch (eleccion)
            {
                case 1:
                    Futbol fut = new Futbol();
                    fut.jugandoFutbol();
                    break;
                case 2:
                    Balonmano bal = new Balonmano();
                    bal.jugandoBalonmano();
                    break;
                case 3:
                    Voleibol vol = new Voleibol();
                    vol.jugandoVoleibol();
                    break;
            }

            SistemaPenalizador sist = new SistemaPenalizador();
            restaMonedero = sist.generarPenalizacion();
            monedero = monedero - restaMonedero;
            Console.WriteLine("Su saldo actual es " + monedero);
            Console.ReadLine();


        }
    }
}
