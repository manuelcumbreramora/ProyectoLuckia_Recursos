﻿//BreoBeceiro:25/03/2020
//PLEXUS | Tema3

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ej3._3
{
    public class Turista : Persona
    {
        public ITransporte vehiculo { get; set; }


        public Turista() { }

        //La inyección de depedencias se introduce mejor a través del constructor:
        public Turista(string name, ITransporte vehicle) 
        {
            this.nombre = name;
            this.vehiculo = vehicle;
        }
        
        public string transporte()
        {
            return this.vehiculo.desplaza();
        }

        public void enviaIncidencia(string incidencia)
        {
            //Se envía el parte al servidor con el código del formulario rellenado por el/la turista...
        }
    }
}
