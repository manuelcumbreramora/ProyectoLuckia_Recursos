﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Base
{
    public class Apuestas
    {
        public void identificarApuesta(Jugador jugador)
        {
            if (jugador.evento == 1)
            {
                //Futbol
                //PoPUpavisando o un MODAL
                procesarApuesta(jugador);
            }else if (jugador.evento == 2)
            {
                //Baloncesto
                //PoPUpavisando o un MODAL
                procesarApuesta(jugador);
            }
            else if (jugador.evento == 3)
            {
                //F1
                //PoPUpavisando o un MODAL
                procesarApuesta(jugador);
            }
        }
        public void procesarApuesta(Jugador jugador)
        {
            Random random = new Random();
            jugador.monedero.calcularGananciaApuesta(jugador, random.Next(0, 100));
        }
        public bool evaluarApuesta(Jugador jugador)
        {
            Evento evento = new Evento();
            evento.generarEventos();
            if (evento.eventos.ContainsKey(jugador.evento))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void iniciarApuesta(Jugador jugador, int saldoIntroducido, int importeApuesta)
        {
            jugador.monedero.GuardarSaldo(saldoIntroducido, jugador, importeApuesta);
            if(evaluarApuesta(jugador))
            {
                identificarApuesta(jugador);
            }

        }
    }
}
