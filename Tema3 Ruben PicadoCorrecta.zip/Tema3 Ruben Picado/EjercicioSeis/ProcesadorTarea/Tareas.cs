﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
 
        public class Tarea
        {
            public int UserId { get; set; }
            public int Id { get; set; }
            public string Title { get; set; }
            public bool Completed { get; set; }

        public async Task<List<Tarea>> procesarAsync(HttpClient client)
        {
                {
                    
                    var urlTareas = "https://jsonplaceholder.typicode.com/todos";
                    var respuestaTareas = await client.GetAsync(urlTareas);
                    respuestaTareas.EnsureSuccessStatusCode();
                    var cuerpoRespuestaTareas = await respuestaTareas.Content.ReadAsStringAsync();
                    Console.WriteLine(cuerpoRespuestaTareas);
                    var tareas =JsonConvert.DeserializeObject<Tarea[]>(cuerpoRespuestaTareas);
                    return tareas.Where(x => !x.Completed).ToList();

                }
             }
        }   
}
