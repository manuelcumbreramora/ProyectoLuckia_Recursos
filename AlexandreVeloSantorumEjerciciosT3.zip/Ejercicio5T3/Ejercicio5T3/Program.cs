﻿using System;

namespace Ejercicio5T3
{
    class Program
    {
        static void Main(string[] args)
        {
            Jugador j = new Jugador();
            j.realizarApuestaCarta();
            j.realizarApuestaEntretenimiento();
            j.realizarApuestaMoneda();
        }
    }
}
