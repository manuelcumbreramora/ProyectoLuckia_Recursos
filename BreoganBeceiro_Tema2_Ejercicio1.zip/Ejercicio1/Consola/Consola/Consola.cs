﻿//BreoBeceiro:18/03/2020
//PLEXUS | Tema2

//EL GUARDADO DEL usuario NO SE HACE CON UN MÉTODO DE LA CAPA DE Negocio, SE HARÍA CON UNO DE LA CAPA DE Datos, PERO NO SE
//  ACCEDERÍA A ESE MÉTODOD DESDE AQUÍ, PUES EN ESTA CAPA, Datos NO ES VISIBLE.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NS_Negocio;

namespace NS_Consola
{
    class Consola
    {

        static void Main()
        {
            //Declaración de un objeto Usuario:
            Usuario usuario;

            //Entradas de datos:
            Console.WriteLine("Ingresa el nombre del usuario: ");
            string nombre = Console.ReadLine();

            Console.WriteLine("Ingresa el apellido: ");
            string apel = Console.ReadLine();

            Console.WriteLine("Ingresa la edad: ");
            string edad = Console.ReadLine();

            //Se instancia el Usuario:
            usuario = new Usuario(nombre, apel, Convert.ToInt32(edad));

            //Se simula el ingreso llamando a la función 'recibeUser(x)' de la clase Negocio (el método siempre devuelve TRUE):
            if (Negocio.recibeUser(usuario))
            {
                Console.WriteLine("Ingreso exitoso!");
            }
            else
            {
                Console.WriteLine("Ingreso fallido.");
            }

            Console.ReadKey();
        }
    }
}
