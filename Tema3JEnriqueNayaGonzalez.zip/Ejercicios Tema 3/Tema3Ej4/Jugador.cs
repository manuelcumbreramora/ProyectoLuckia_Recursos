﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3Ej4
{
    class Jugador
    {
        int Monedero { get; set; }
        string Nombre { get; set; }
    }
}
