﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ej3v2tema3
{
    
    class Libro : Producto
    {

        private String Autor;
        private String Genero;

        private int NumPaginas;

        public Libro(string autor, String titulo, DateTime fechaPublicacion, string genero, double precio, int numPaginas)
             : base(precio, fechaPublicacion, titulo)
        {
            this.Autor = autor;
            this.Genero = genero;
            this.NumPaginas = numPaginas;
        }
        public override string EscribirInformacion(StringBuilder salida, ISerializador serializador)
        {
            salida.Append(serializador.InicioEntidad("Libro"));

            base.EscribirTitulo(salida, serializador);

            salida.Append(serializador.Atributo("Autor", Autor));

            salida.Append(serializador.Atributo("Genero", Genero));

            base.EscribirFechaPublicacion(salida, serializador);

            base.EscribirPrecioUnitario(salida, serializador);

            salida.Append(serializador.Atributo("NumPaginas", NumPaginas));

            salida.Append(serializador.FinEntidad());

            return salida.ToString();
        }
    }
}
