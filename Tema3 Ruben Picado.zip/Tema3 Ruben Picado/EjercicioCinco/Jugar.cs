﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio5
{
    class Jugar : Casinos
    {
        public void casinoMadrid()
        {
            Console.WriteLine(" Jugando en Madrid");
        }

        public void casinoLugo()
        {
            Console.WriteLine(" Jugando en Lugo");
        }

        public void casinoSevilla()
        {
            Console.WriteLine(" Jugando en Sevilla");
        }

    }
}
