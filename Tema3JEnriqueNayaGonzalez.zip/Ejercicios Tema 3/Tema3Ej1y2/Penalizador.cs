﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3Ej1
{
    abstract class Penalizador
    {
        public virtual void penalizar(Juego juego, Jugador jugador)
        {
            switch (juego.deporte)
            {
                case "Futbol":
                    jugador.monedero = jugador.monedero - 50;
                    Console.WriteLine("Penalización aplicada: 50€");
                    break;
                case "Balonmano":
                    jugador.monedero = jugador.monedero - 30;
                    Console.WriteLine("Penalización aplicada: 30€");
                    break;
                case "Boleibol":
                    jugador.monedero = jugador.monedero - 25;
                    Console.WriteLine("Penalización aplicada: 25€");
                    break;
            }
        }
    }
}
