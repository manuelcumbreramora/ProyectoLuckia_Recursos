﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PEventos
{
    public class RepositorioEventos
    {
        private List<IEventos> EventosDisponibles;
      
        public RepositorioEventos()
        {
            EventosDisponibles = new List<IEventos>();
        }
        
        public void InsertarEvento(IEventos evento)
        {
            this.EventosDisponibles.Add(evento);

        }
        public void ListarEventos()
        {
            foreach (IEventos evento in this.EventosDisponibles)
            {
                evento.MostrarEvento();
                Console.WriteLine("");
            }

        }
        public IEventos BuscarEvento(String nombre)
        {

            IEventos eventoBuscado = this.EventosDisponibles.FirstOrDefault(evento => (evento.GetNombre() == nombre));
            Console.WriteLine("Evento Encontrado");

            return eventoBuscado;
        }

        public void ResolverEventosPendientes()
        {
            foreach (IEventos evento in this.EventosDisponibles)
            {
                evento.ResolverEvento();
                Console.WriteLine("");
            }

        }
    }
}
