﻿using BussinessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio000
{
    class Program
    {
        public const int EXIT_PROGRAM = 9;

        static void Main(string[] args)
        {
            int option;
            do
            {
                Console.WriteLine("\nChoose one of these options:\n");
                Console.WriteLine("1. List all users.");
                Console.WriteLine("2. Add new user.");
                Console.WriteLine(EXIT_PROGRAM + ". Exit.");
                Console.WriteLine("");
                Console.Write(">> ");

                String _s = Console.ReadLine();
                try
                {
                    option = int.Parse(_s[0] + "");
                } catch (System.FormatException e)
                {
                    option = int.MinValue;
                }
                if (option == 1)
                {
                    listAllUsers();
                }
                else if (option == 2)
                {
                    Console.WriteLine("");
                    Console.WriteLine("Enter user name: ");
                    String username = Console.ReadLine();
                    Console.WriteLine("Enter user e-mail: ");
                    String email = Console.ReadLine();
                    addUser(username, email);
                }
                else
                {
                    Console.WriteLine("Error, opción incorrecta.");
                }
            } while (option != EXIT_PROGRAM);
        }

        static void addUser(String username, String email)
        {
            (new Bussiness()).addUser(username, email);
        }

        static void listAllUsers()
        {
            (new Bussiness()).showAllUsers();
        }
    }
}
