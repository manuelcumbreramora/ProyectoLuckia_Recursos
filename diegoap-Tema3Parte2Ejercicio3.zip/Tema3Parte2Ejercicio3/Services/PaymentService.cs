﻿using Payments;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaxCalculator;
using Taxes;
using Users;

namespace Services
{
    public static class PaymentService
    {
        // Returns true on success, else false.
        public static Tuple<bool, AbstractPayment> doPayment(User user, float amount, string sport)
        {
            AbstractPayment payment;
            if (sport.Equals("football"))
            {
                payment = new FootballBetPayment(user, amount, new FootballTaxCalculator());
            }
            else if (sport.Equals("racing"))
            {
                payment = new RacingBetPayment(user, amount, new DefaultTaxCalculator());
            }
            else 
            {
                throw (new ArgumentException("Illegal sport value,'" + sport + "' not available"));
            }

            float finalAmount = payment.calculateFinalAmount();
            payment.doTransfer(user.checkingAccount, finalAmount);

            return new Tuple<bool, AbstractPayment>(true, payment);
        }
    }
}
