﻿//BreoBeceiro:23/03/2020
//PLEXUS | Tema3

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ej2
{
    public abstract class Penalizador
    {
        public bool descuentaPuntos()
        {
            return true;
        }

        public bool descuentaDinero()
        {
            return true;
        }

        //Este método se sobreescribe en la clase 'Infraccion.cs':
        public virtual void cuentaInfraccion()
        {
            //Si el número de infracciones del jugador llega a un número X, se le suspende la cuenta...
            //El número de infracciones depende del deporte.
        }
    }
}
