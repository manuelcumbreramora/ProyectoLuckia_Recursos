﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cata
{
    public class EvBaloncesto: IEvento
    {
        public string nombreEvento { get; set; }
        public int resultadofinal { get; set; }

        public EvBaloncesto(string _nombre)
        {
            this.nombreEvento = _nombre;
        }
        public int resolverEvento()
        {
            Random ran = new Random();
            return ran.Next(0, 3);
        }

        public void registrarResultadoFinal(int _resultado)
        {
            this.resultadofinal = _resultado;
        }

        public int devolverResultadFinal()
        {
            return this.resultadofinal;
        }

        public string devolverNombreEvento()
        {
            return this.nombreEvento;
        }
    }
}
