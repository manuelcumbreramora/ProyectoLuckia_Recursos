﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class Usuario
    {
        public int Nombre { get; set; }
        public int Id { get; set; }

        public async Task<Usuario[]> procesarAsync(HttpClient client)
        {
            var urlUsuarios = "https://jsonplaceholder.typicode.com/users";
            var respuestaUsuarios = await client.GetAsync(urlUsuarios);
            respuestaUsuarios.EnsureSuccessStatusCode();
            var cuerpoRespuestaUsuarios = await respuestaUsuarios.Content.ReadAsStringAsync();
            Console.WriteLine(cuerpoRespuestaUsuarios);

            return JsonConvert.DeserializeObject<Usuario[]>(cuerpoRespuestaUsuarios);
        }
    }
}
