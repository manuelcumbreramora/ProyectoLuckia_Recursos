﻿//BreoBeceiro:31/03/2020
//PLEXUS | Tema5.1

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Negocio;

namespace Vista
{
    class Program
    {
        static void Main()
        {
            //Declaración de variables:
            string nombreCasino;
            string CIFcasino;
            string CPcasino;
            Casino nuevoCasino;
            string admin;
            string passw;

            //Iniciación de variables:
            Console.WriteLine("Nombre del casino: ");
            nombreCasino = Console.ReadLine();

            Console.WriteLine("CIF del casino: ");
            CIFcasino = Console.ReadLine();

            Console.WriteLine("Código postal del casino; ");
            CPcasino = Console.ReadLine();

            nuevoCasino = new Casino(CIFcasino, nombreCasino, CPcasino);

            //Se guarda el casino:
            if (Casino.recibeSolicitud(nuevoCasino))
            {
                Console.WriteLine("Solicitud recibida! Nos pondremos en contacto contigo.");
            }
            else
            {
                Console.WriteLine("Solicitud denegada.");
            }

            //Autenticación de administrador:
            Console.WriteLine(" ");
            Console.WriteLine("Introduce tu usuario de administrador: ");
            admin = Console.ReadLine();

            Console.WriteLine("Contraseña: ");
            passw = Console.ReadLine();

            Sistema.compruebaCredenciales(admin, passw);



            //SI ACCEDE EL ADMIN: -------------------------------------------------------------------------------

            //Declaración de variables:
            Incidencia incidencia;
            Casino casino;
            string titulo;
            string descripcion;
            Factura factura;
            string numero;
            string concepto;
            decimal importe;
            
            //Formulario de nueva incidencia:
            Console.WriteLine("Nueva incidencia? Descríbela: ");
            descripcion = Console.ReadLine();

            Console.WriteLine("Cómo la quieres llamar? ");
            titulo = Console.ReadLine();

            //Se envía la incidencia:
            incidencia = new Incidencia(titulo, descripcion);
            incidencia.nuevaIncidencia();

            Console.WriteLine("La incidencia se ha enviado correctamente!");


            //Formulario de consulta de servicios contratados:
            Console.WriteLine(" ");
            Console.WriteLine("Quieres consultar los servicios de tu casino? Introduce su CIF: ");
            CIFcasino = Console.ReadLine();

            casino = new Casino();
            casino.cif = CIFcasino;

            //Se visualizan los servicios:
            Sistema.servicios(casino);

            Console.WriteLine("Ahora estarías viendo el historial de servicios que tiene contratado ese casino, pero como sería un dato List o Dictionary, vamos a dejarlo aquí.");


            //Facturación:
            Console.WriteLine(" ");
            Console.WriteLine("Quieres añadir una factura? Escribe el concepto de la misma: ");
            concepto = Console.ReadLine();

            Console.WriteLine("Ahora, su importe: ");
            importe = Convert.ToDecimal(Console.ReadLine());

            factura = new Factura();
            factura.concepto = concepto;
            factura.importe = importe;
            factura.fecha = DateTime.Now;

            if (Factura.nuevaFactura(factura))
            {
                Console.WriteLine("Factura creada con éxito!");
            }
            else
            {
                Console.WriteLine("ERROR: Algo ha fallado...");
            }

            Console.WriteLine(" ");
            Console.WriteLine("Quieres consultar los datos de una factura? Escribe el número de la misma: ");
            numero = Console.ReadLine();

            //Se visualizarían los datos de la factura recuperándolos de la BBDD...


            Console.ReadKey();
        }
    }
}
