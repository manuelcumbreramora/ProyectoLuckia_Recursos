﻿namespace ej5tema3
{
    interface Casino
    {
        void Jugar(Jugador jugador);
    }
}