﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Users
{
    public class Bettor : AbstractUser, IBettor
    {
        public float Wallet { get; set; }

        public int NumStrikes { get; set; }

        public Bettor(int id, string name) : base(id, UserType.Bettor, name)
        {
            this.Wallet = 0f;
            this.NumStrikes = 0;
        }

        public Bettor(int id, string name, float wallet, int numStrikes) : base(id, UserType.Bettor, name)
        {
            this.Wallet = wallet;
            this.NumStrikes = numStrikes;
        }

        public float GetWallet()
        {
            return this.Wallet;
        }

        public void SetWallet(float wallet)
        {
            this.Wallet = wallet;
        }

        public int GetNumStrikes()
        {
            return this.NumStrikes;
        }
    }
}
