﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimuladorCarreras
{
    class CarreraSencilla : Competicion
    {

        private double Longitud;

        public CarreraSencilla(double longitud)
        {
            this.Longitud = longitud;
        }

        public SortedDictionary<double, IParticipante> PartcptsOrdenadosPorResultado
                = new SortedDictionary<double, IParticipante>();

        public override void MostrarResultado()
        {
            foreach(double tiempo in PartcptsOrdenadosPorResultado.Keys)
            {
                PartcptsOrdenadosPorResultado.TryGetValue(tiempo, out IParticipante p);

                Console.WriteLine(General.MostrarTiempoComodo(tiempo)+"    "+p.ObtenerInformacion());
            }
        }

        public override  void SimularCompeticion()
        {
            PartcptsOrdenadosPorResultado
                =new SortedDictionary<double, IParticipante>();

            foreach (IParticipante p in Participantes)
            {
                PartcptsOrdenadosPorResultado.Add(p.ObtenerTiempo(this.Longitud), p);
            }
        }
    }
}
