﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PJugador
{
    public class RepositorioJugadores
    {
        private List<Jugador> JugadoresDB;

        public RepositorioJugadores()
        {
            JugadoresDB = new List<Jugador>();
        }

        public bool InsertarJugador(String login,String pass, int saldoInicial)
        {
            bool exitoInsercion = false;
            if (ComprobarExisteLogin(login) == false)
            {
                Jugador jugadorInsertar = new Jugador(login, pass, saldoInicial);
                this.JugadoresDB.Add(jugadorInsertar);
                exitoInsercion = true;
            }
            
           
            return exitoInsercion;
        }

        public Jugador BuscarJugador(String login)
        {

                Jugador j1 = this.JugadoresDB.FirstOrDefault(jugador => (jugador.getLogin() == login));
                Console.WriteLine("Jugador Encontrado");
            
            return j1;
        }

        public bool ComprobarExisteLogin(String login)
        {
            bool exitoComprobar= false;
           if(( this.JugadoresDB.Exists(x => (x.getLogin() == login))) == true)
            {
                exitoComprobar = true;
                Console.WriteLine("Login ya existe");
                
            }
            return exitoComprobar;
        }
        public bool VerificarJugador(String login, String pass)
        {
            Boolean exitoVerificar = false;
            if (ComprobarExisteLogin(login)==true)
            {
                Jugador jugadorVer = BuscarJugador(login);
                if (jugadorVer.ComprobarPass(pass) == true)
                {
                    exitoVerificar = true;
                    Console.WriteLine("Contraseña Correcta");
                }
                else
                {
                    Console.WriteLine("Pass Incorrecta");
                }

            }
            else
            {

                Console.WriteLine("Login no exite, registre jugador");
            }
            return exitoVerificar;
        }
    }
}
