﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hosteleria

{
    public class Precio : FormaPagar
    {
        public void pagar(Restaurante restaurante)
        {
            Console.WriteLine("Forma de pagar el precio.");
        }
    }
}
