﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Users
{
    public class User
    {
        public string name { get; set; }
        public int age { get; set; }

        public string checkingAccount { get; set; }

        public User(string name, int age, string checkingAccount)
        {
            this.name = name;
            this.age = age;
            this.checkingAccount = checkingAccount;
        }
    }
}
