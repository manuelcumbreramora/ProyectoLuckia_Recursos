﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JuegoJuego
{
    public class Juego
    {
        protected string Nombre { get; set; }
        protected string Equipo1 { get; set; }
        protected string Equipo2 { get; set; }
        public int Penalizacion { get; set; }
        public string Ganador { get; set; }
    
    public Juego()
    {

    }
    public Juego(string nombre, string equipo1, string equipo2)
    {
            Nombre = nombre;
            Equipo1 = equipo1;
            Equipo2 = equipo2;
            Penalizacion = 0;
            Ganador = "";
    }

    public void Jugar(int sGanador)
        {
            switch (sGanador)
            {
                case 1:
                    this.Ganador = this.Equipo1;
                    break;
                case 2:
                    this.Ganador = this.Equipo2;
                    break;
                default:
                    this.Ganador = "Empate";
                    break;
            }
        }

        public void mostrarJuego()
        {
            Console.WriteLine("Nombre de Juego {0}", this.Nombre);
            Console.WriteLine("Equipo1 {0}", this.Equipo1);
            Console.WriteLine("Equipo2 {0}", this.Equipo2);
            Console.WriteLine("Ganador {0}", this.Ganador);
        }

    }
}
