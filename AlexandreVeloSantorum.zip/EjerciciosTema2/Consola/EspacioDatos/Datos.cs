﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EspacioDatos
{
    public class DatosClase
    {
        String user { get; set; }
        String email { get; set; }
        String nombre { get; set; }

        public DatosClase()
        {
            this.user = "unknown";
            this.email = "unknown";
            this.nombre = "unknown";
        }

        public void getContentFromNegocio(String user, String email, String nombre)
        {
            this.user = user;
            this.email = email;
            this.nombre = nombre;
            if (this.user != "unknown" && this.email != "unknown" && this.nombre != "unknown")
            {
                Console.WriteLine("Datos recibidos");
            }
            else
            {
                Console.WriteLine("Datos no recibidos correctamente");
            }
        }
    }
}