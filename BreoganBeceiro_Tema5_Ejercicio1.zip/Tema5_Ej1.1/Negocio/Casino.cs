﻿//BreoBeceiro:30/03/2020
//PLEXUS | Tema5.1

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Persistencia;

namespace Negocio
{
    public class Casino
    {
        public string cif { get; set; }
        public string nombre { get; set; }
        public string codPostal { get; set; }


        public Casino() { }

        public Casino(string _cif, string _nombre, string _cp)
        {

            this.cif = _cif;
            this.nombre = _nombre;
            this.codPostal = _cp;
        }

        /// <summary>
        /// Envía (y registra en BBDD) una incidencia al servicio técnico remoto.
        /// </summary>
        /// <param name="_incidencia">La descripción de la incidencia.</param>
        /// <returns>TRUE si el envío y el registro tuvieron éxito, FALSE.</returns>
        public bool comunicaIncidencia(Incidencia _incidencia)
        {
            DAO.registraIncidencia(_incidencia.titulo, _incidencia.descripcion);
            return true;
        }

        /// <summary>
        /// Recibe la solicitud y la guarda en BBDD.
        /// </summary>
        /// <param name="_casino">Un objeto de tipo Casino que contenga los datos requeridos para la tramitación de la solicitud.</param>
        /// <returns></returns>
        public static bool recibeSolicitud(Casino _casino)
        {
            DAO.registraSolicitud(_casino.cif, _casino.nombre, _casino.codPostal);
            return true;
        }
    }
}
