﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Herencias
{
    public class Medico : InterfazMedico
    {
        public string nombre = "Alvaro";

        public void operarPaciente(Medico medico)
        {
            Console.WriteLine("Tu medico será " + nombre);
        }
    }
}
