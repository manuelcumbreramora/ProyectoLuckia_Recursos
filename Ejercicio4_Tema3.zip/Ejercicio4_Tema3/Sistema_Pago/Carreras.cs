﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_Pago
{
    public class Carreras : Deporte
    {
        public int puntos { get; set; }
        public Carreras() { }
        public Carreras(int points)
        {
            this.nombre = "Carreras";
            this.puntos = points;
        }
    }
}
