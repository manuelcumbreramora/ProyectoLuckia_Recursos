﻿using Bets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Casino
{
    public class FlamingoCasino : AbstractCasino
    {
        public FlamingoCasino() : base("Flamingo") { }

        public override float calculateWinnerBetAmount(IBet bet)
        {
            return bet.GetAmount() * (1f - 0.21f);
        }

        public override string[] GetRouletteNumberSequence()
        {
            // Double-zero wheel.
            return (new string[] { "0", "28", "9", "26", "30", "11", "7", "20", "32", "17", "5", "22", "34", "15", "3", "24", "36", "13", "1", "00", "27", "10", "25", "29", "12", "8", "19", "31", "18", "6", "21", "33", "16", "4", "23", "35", "14", "2" });
        }
    }
}
