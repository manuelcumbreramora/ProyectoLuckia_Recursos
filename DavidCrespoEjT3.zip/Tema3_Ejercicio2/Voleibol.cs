﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ejercicio2
{
    class Voleibol:Juego
    {
        public void jugandoVoleibol()
        {
            Console.WriteLine("Estas apostando al voleibol");
           
        }

    }
}
