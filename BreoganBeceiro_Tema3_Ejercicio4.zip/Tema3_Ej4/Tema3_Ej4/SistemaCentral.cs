﻿//BreoBeceiro:29/03/2020
//PLEXUS | Tema3

//OJO: Los puntos se multiplican por 15 y ése será el importe que hay que devolver al jugador.
//LA SOLUCIÓN APORTADA A LA OBTENCIÓN DE LOS PUNTOS DEL JUGADOR EN EVENTOS DE Futbol NO CUMPLE CON LA NORMA DE ABSTRACCIÓN.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ej4
{
    public class SistemaCentral
    {
        /*public void calculoDinero(Jugador jugador)
        {
            foreach (var apuesta in jugador.apuestas)
            {
                //Iterar la apuesta de cada jugador, llamando al método calculaPuntos() por medio del atributo IPuntosJugador...
            }
        }*/

        static void Main()
        {
            //Declaración de variables:
            Random index = new Random();
            int indice;
            bool resultadoPartido;
            bool resultadoQuiniela;
            float puntosAt;
            float puntosCarr;
            //List<Jugador> jugadores;

            //Instancias de objetos:
            Atletismo eventoAt = new Atletismo();
            Carreras eventoCarr = new Carreras();
            Futbol eventoFut = new Futbol();
            Apuesta apuestas = new Apuesta();

            //Inicialización de variables:
            indice =index.Next(0, 3);
            resultadoPartido = eventoFut.comprobarResultado();
            resultadoQuiniela = eventoFut.comprobarQuiniela();

            puntosAt = eventoAt.calculaPuntos(apuestas.cantidades[indice]) * Apuesta.ProductoImporte;
            puntosCarr = eventoCarr.calculaPuntos(apuestas.cantidades[indice]) * Apuesta.ProductoImporte;

            //Salidas por pantalla:
            Console.WriteLine("Los puntos obtenidos en la apuesta son " + apuestas.cantidades[indice] + ".");
            Console.WriteLine("El resultado del partido es " + resultadoPartido + ".");
            Console.WriteLine("El resultado en la quiniela es " + resultadoQuiniela + ".");

            Console.WriteLine("Si estos puntos se obtuvieran en un evento de " + Evento.modalidad.Atletismo + ", el importe a recibir por el jugador, sería " + puntosAt + ".");

            Console.WriteLine("Si estos puntos se obtuvieran en un evento de " + Evento.modalidad.Carreras + ", el importe a recibir por el jugador, sería " + puntosCarr + ".");

            Console.WriteLine("En un evento de " + Evento.modalidad.Futbol + ", el importe a recibir por el jugador, sería " + eventoFut.obtienePuntos(resultadoPartido, resultadoQuiniela) + ".");


            Console.ReadKey();
        }
    }
}
