﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioCuatro
{
    class Carreras : IPuntuacion
    {
        public int puntos { get; set; }
        public int puntosC { get; set; }

        public override int CalculoPuntos(Jugador jugador, int importeApostado)
        {
            Console.WriteLine("Apostando a la formula uno");
            Random random = new Random();
            if (random.Next(0, 80) < 40)
            {
                puntos = importeApostado / 10;
            }
            return puntosC * 15;
        }


       
    }

    
}
