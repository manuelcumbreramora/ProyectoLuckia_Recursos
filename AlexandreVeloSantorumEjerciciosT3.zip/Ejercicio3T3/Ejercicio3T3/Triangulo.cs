﻿using System;
using IFiguraSpace;

namespace TrianguloSpace
{
    public class Triangulo : IFigura
    {
        private int Lado1 { get; set; }
        private int Altura { get; set; }
        public Triangulo(int lado1)
        {
            Lado1 = lado1;
            Altura = Convert.ToInt32((Math.Sqrt(3) * lado1) / 2);
        }

        public int Area()
        {
            return (Lado1 * Altura);
        }

        public int Perimetro()
        {
            return (Lado1 *3);
        }
    }
}
