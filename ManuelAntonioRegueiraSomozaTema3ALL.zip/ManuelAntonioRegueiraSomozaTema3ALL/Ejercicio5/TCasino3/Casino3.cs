﻿using InterfaceCasino;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCasino3
{
    public class Casino3 : ICasino
    {
        private String Nombre;
        public Casino3(String nombre)
        {
            Nombre = nombre;

        }
        public void Jugar()
        {
            Console.WriteLine("Jugando a juego casinoTipo3 {0}", this.Nombre);
        }
    }
}
