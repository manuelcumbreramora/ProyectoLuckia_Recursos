﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PEventos
{
    public interface IEventos
    {
        void ResolverEvento();
        int DevolverResultadoFinal();
        void MostrarEvento();
        String GetNombre();

    }
}
