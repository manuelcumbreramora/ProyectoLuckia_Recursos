﻿using System;

namespace ej4tema3
{
    internal class ResultadoFutbol: Resultado
    {
        public UInt16 GolesLocal { get; set; }
        public UInt16 GolesVisitante{ get; set; }

        public ValorCasilla[] RellenoQuiniela { get; set; } = new ValorCasilla[15];

        public enum ValorCasilla
        {
            Uno, Equis, Dos
        }
        public ResultadoFutbol()
        {

        }

        //
        // 0: sin aciertos 1: acierto resultado 2: acierta quiniela, 3: acierta quiniela y resultado
        public int Comparar(Resultado otroResultado)
        {
            if (otroResultado is ResultadoFutbol otroResultadoFutbol)
            {
                if (this.GolesLocal==otroResultadoFutbol.GolesLocal && this.GolesVisitante == otroResultadoFutbol.GolesVisitante)
                {
                    // Resultado coincide.
                    if (CoincideQuiniela(this.RellenoQuiniela, otroResultadoFutbol.RellenoQuiniela)) {
                        return 3;
                    } else {
                        return 1;
                    }
                }
                else
                {
                    if (CoincideQuiniela(this.RellenoQuiniela, otroResultadoFutbol.RellenoQuiniela))
                    {
                        return 2;
                    }
                    else
                    {
                        return 0;
                    }
                }
            } else
            {
                // Se está comparando con un resultado de otra cosa.
                throw new Exception("Tipo de resultado no reconocido.");
            }
        }

        private bool CoincideQuiniela(ValorCasilla[] rellenoQuiniela1, ValorCasilla[] rellenoQuiniela2)
        {
            for(int i=0; i<15; i++)
            {
                if (rellenoQuiniela1[i] != rellenoQuiniela2[i])
                {
                    return false;
                }
            }
            return true;
        }
    }
}