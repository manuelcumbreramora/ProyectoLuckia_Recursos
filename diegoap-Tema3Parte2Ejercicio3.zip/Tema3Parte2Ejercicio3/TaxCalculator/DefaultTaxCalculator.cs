﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Taxes;

namespace TaxCalculator
{
    public class DefaultTaxCalculator : AbstractTaxCalculator
    {
        public DefaultTaxCalculator() : base("") { }

        public override float calculateTotalTaxes(List<ITax> taxes, float amount)
        {
            float _amount = amount;

            float t, totalTaxes = 0f;
            foreach (AbstractTax item in taxes)
            {
                t = item.calculateTax(_amount);
                totalTaxes = totalTaxes + t;
                _amount = _amount - t;
            }

            return totalTaxes;
        }
    }
}
