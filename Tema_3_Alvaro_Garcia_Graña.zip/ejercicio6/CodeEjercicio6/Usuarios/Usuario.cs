﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace Usuarios
{
    public class Usuario
    {
        public int Id { get; set; }
        public string Nombre { get; set; }

        public async Task<Usuario[]> ProcesarUsuario(HttpClient client)
        {
            var urlUsuarios = "https://jsonplaceholder.typicode.com/users";
            var respuestaUsuarios = await client.GetAsync(urlUsuarios);
            respuestaUsuarios.EnsureSuccessStatusCode();
            var cuerpoRespuestaUsuarios = await respuestaUsuarios.Content.ReadAsStringAsync();
            Console.WriteLine(cuerpoRespuestaUsuarios);
            return JsonConvert.DeserializeObject<Usuario[]>(cuerpoRespuestaUsuarios);
        }
    }
}
