﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_Pago
{
    class Program
    {
        static void Main(string[] args)
        {
            int puntosFut = 0;
            int puntosRace = 0;
            int puntosAtle = 0;
            double calFut = 0;
            double calRace = 0;
            double calAtle = 0;
            Futbol fut = new Futbol();
            Atletismo atle = new Atletismo();
            Random rnd = new Random();
            Jugador jug = new Jugador(20);
            Carreras race = new Carreras();
            SistemaCentral sis = new SistemaCentral();
            Console.WriteLine("Calculo de los puntos obtenidos en las apuestas.");
            fut.resultados();
            puntosFut = fut.puntos;
            puntosRace = rnd.Next(100);
            puntosAtle = rnd.Next(200);
            race.puntos = puntosRace;
            atle.puntos = puntosAtle;
            calFut = sis.calculo(puntosFut, 1);
            calRace = sis.calculo(puntosRace, 10);
            calAtle = sis.calculo(puntosAtle, 2);
            sis.sumaPuntos(calFut, calRace, calAtle);
            sis.dineroGanado();
            Console.WriteLine("Ha ganado usted un total de " + sis.dineroFinal + "euros.");
            Console.WriteLine("Fin de programa.");
            Console.ReadKey();
        }
    }
}
