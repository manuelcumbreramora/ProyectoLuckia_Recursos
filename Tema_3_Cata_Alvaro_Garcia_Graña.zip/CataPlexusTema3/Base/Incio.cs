﻿using Base;
using System;
using System.Collections.Generic;

namespace Login
{
    public class Incio
    {

            internal List<User> generarUsuarios()
            {
                List<User> usuarios = new List<User>();
                User usuario1 = new User();
                User usuario2 = new User();
                User usuario3 = new User();
                User usuario4 = new User();
                User usuario5 = new User();
                User usuario6 = new User();
                usuario1.usuario = "alvaro";
                usuario1.password = "123";
                
                usuario2.usuario = "juan";
                usuario2.password = "345";
                
                usuario3.usuario = "pedro";
                usuario3.password = "678";
                
                usuario4.usuario = "manuel";
                usuario4.password = "901";
                
                usuario5.usuario = "rober";
                usuario5.password = "234";
                
                usuario6.usuario = "carlos";
                usuario6.password = "567";

            usuarios.Add(usuario1);
            usuarios.Add(usuario2);
            usuarios.Add(usuario3);
            usuarios.Add(usuario4);
            usuarios.Add(usuario5);
            usuarios.Add(usuario6);
                return usuarios;
            }

            public void comenzarPrograma(String usuario, String password)
            {
                User usuarioSesion = new User();
                if (!usuarioSesion.IniciarSesion(usuario, password, generarUsuarios()))
                {
                    throw new ExcepcionCustom(new { message = "Usuario incorrecto." });
                }
            }
        
    }
}