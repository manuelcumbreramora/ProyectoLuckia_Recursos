﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace ServicioCopy
{
    partial class Copy : ServiceBase
    {
        bool flag = false;
        public Copy()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            sTimer.Start();
        }

        protected override void OnStop()
        {
            sTimer.Stop();
        }

        private void sTimer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            if (flag) return;

            try
            {
                flag = true;

                EventLog.WriteEntry("Proceso de copia iniciado", EventLogEntryType.Information);

                string origin = ConfigurationSettings.AppSettings["origin"].ToString();
                string dest = ConfigurationSettings.AppSettings["dest"].ToString();
                DirectoryInfo dir = new DirectoryInfo(origin);

                foreach (var file in dir.GetFiles("*", SearchOption.AllDirectories))
                {
                    if(File.Exists(dest + file.Name))
                    {
                        File.SetAttributes(dest + file.Name, FileAttributes.Normal);
                        File.Delete(dest + file.Name);
                    }
                    File.Copy(origin + file.Name, dest + file.Name);
                    File.SetAttributes(dest + file.Name, FileAttributes.Normal);

                    if(File.Exists(dest + file.Name))
                    {
                        EventLog.WriteEntry("Se copio archivo con exito", EventLogEntryType.Information);
                    }
                    else
                    {
                        EventLog.WriteEntry("No se copio el archivo con exito", EventLogEntryType.Information);
                    }
                }
                EventLog.WriteEntry("Se finalizo proceso de copiado", EventLogEntryType.Information);
            }catch(Exception ex)
            {
                EventLog.WriteEntry(ex.Message, EventLogEntryType.Error);
            }

            flag = false;
        }
    }
}
