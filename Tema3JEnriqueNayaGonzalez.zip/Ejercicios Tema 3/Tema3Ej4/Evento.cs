﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3Ej4
{
    class Evento
    {
        String Modalidad { get; set; }
        internal Dictionary<int, string> Eventos = new Dictionary<int, string>();
        public void GenerarEventos()
        {
            Eventos.Add(1, "Atletismo");
            Eventos.Add(2, "Fútbol");
            Eventos.Add(3, "Carreras");
        }
    }
}
