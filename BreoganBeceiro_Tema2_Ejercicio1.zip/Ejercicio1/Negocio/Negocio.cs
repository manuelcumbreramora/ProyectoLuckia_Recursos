﻿//BreoBeceiro:18/03/2020
//PLEXUS | Tema2

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NS_Negocio
{
    public static class Negocio
    {
        //Recibe el objeto Usuario instanciado en la capa de Consola y lo envía a la capa de Datos (dado que se 
        //  simula, devuelve siempre TRUE):
        public static bool recibeUser(Usuario user)
        { 
            return true;
        }
    }

}
