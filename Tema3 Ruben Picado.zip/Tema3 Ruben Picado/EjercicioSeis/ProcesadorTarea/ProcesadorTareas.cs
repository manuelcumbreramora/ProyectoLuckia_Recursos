﻿using ConsoleApp3;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Consola   
{
    public class ProcesadorTareas
    {
        public class TareaViewModel
        {
            public int Id { get; set; }
            public string Title { get; set; }

            public string NombreUsuario { get; set; }
        }
        public void EmpezarTareas(List<Tarea> tareasNoRealizadas, Usuario[] usuarios)
        {
            var tareasViewModel = new List<TareaViewModel>();
            foreach (var tarea in tareasNoRealizadas)
            {
                var tareaViewModel = new TareaViewModel()
                {
                    Id = tarea.Id,
                    Title = tarea.Title.Trim(),
                    NombreUsuario = usuarios.Where(x => x.Id == tarea.UserId).First().Nombre.Trim()
                };
                tareasViewModel.Add(tareaViewModel);
            }
        }

        internal async Task Procesar()
        {
            

            try
            {
                Console.WriteLine("Inicio de procesamiento");
                var client = new HttpClient();
                var tareasNoRealizadas = await tarea.procesarAsync(client);
                Usuario usuario = new Usuario();
                var usuarios = await usuario.procesarAsync(client);
                TareaViewModel tareaViewModel = new TareaViewModel();
                tareaViewModel.EmpezarTareas(tareasNoRealizadas, usuarios());

                Console.WriteLine("Inicio transformación ViewModels");
                using (StreamWriter writetext = new StreamWriter($@"{Directory.GetCurrentDirectory()}\tareas pendientes.txt")) ;
                Console.ReadKey();

            }
            catch (IOException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    }

    





}
