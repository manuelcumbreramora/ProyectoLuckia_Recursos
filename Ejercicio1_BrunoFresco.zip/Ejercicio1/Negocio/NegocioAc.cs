﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Datos;

namespace Negocio
{
    public class NegocioAc
    {
        private DatosDB datos = new DatosDB();
        public NegocioAc() {}
        public void Nombre(string nom)
        {
            datos.setNombre(nom);
            Console.WriteLine("El usuario introducido es " + datos.getNombre());
        }
        public void Email(string mail)
        {
            datos.setEmail(mail);
            Console.WriteLine("El mail introducido es " + datos.getEmail());
        }
        public void Contra(string contra)
        {
            datos.setContra(contra);
        }
    }
}
