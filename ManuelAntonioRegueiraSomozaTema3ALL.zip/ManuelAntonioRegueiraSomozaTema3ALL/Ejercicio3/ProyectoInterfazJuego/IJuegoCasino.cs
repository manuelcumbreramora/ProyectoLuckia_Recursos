﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoInterfazJuego
{
    public interface IJuegoCasino
    {
        void Jugar();
        void Apostar(int valorApuesta);
        void MostrarDatosJuego();
        
    }
}
