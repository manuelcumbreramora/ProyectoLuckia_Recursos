﻿
using PJugador;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceSistemaCentral
{
    public interface ISistemaCentral
    {
       void JugarApuesta();
       int CalculoPuntos();
        int calculoImporte(int puntos);

        void abonarApuesta(int importe);
         void mostrarApuesta();





    }
}
