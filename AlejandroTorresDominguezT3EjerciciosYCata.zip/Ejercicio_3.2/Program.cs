﻿/*Implementa y diseña, una solución inventada, aplicando cada uno de los siguientes conceptos:
-Interfaces
-Herencia
-Polimorfismo por interfaz

Aplicar la dependencia de abstracciones*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ejercicio_3._2.Usuarios;

namespace Ejercicio_3._2
{
    class Program
    {
        static void Main(string[] args)
        {
            Profesor prof = new Profesor();
            prof.cargarNotas();
            prof.guardarNotas();
            Console.ReadKey();
        }
    }
}
