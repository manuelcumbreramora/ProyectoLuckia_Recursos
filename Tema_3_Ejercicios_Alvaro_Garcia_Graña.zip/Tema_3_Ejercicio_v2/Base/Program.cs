﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Polimorfismos;

namespace Base
{
    class Program : Polimorfismo
    {
        static void Main(string[] args)
        {
            Polimorfismo poli = new Polimorfismo();
            Console.WriteLine("Introduza 1 si se encuentra bien y 2 si se encuentra muy mal:");
            int valor = int.Parse(Console.ReadLine());
            switch (valor)
            {
                case 1:
                    poli.comprobar(valor);
                    break;
                case 2:
                    poli.comprobar(valor);
                    break;
                default:
                    break;
            }
            Console.ReadKey();
        }
    }
}
