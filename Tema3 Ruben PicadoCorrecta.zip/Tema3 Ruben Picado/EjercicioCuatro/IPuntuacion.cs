﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioCuatro
{
    public abstract class IPuntuacion
    {
        public abstract int CalculoPuntos(Jugador jugador, int importeApostado);

    }
}
