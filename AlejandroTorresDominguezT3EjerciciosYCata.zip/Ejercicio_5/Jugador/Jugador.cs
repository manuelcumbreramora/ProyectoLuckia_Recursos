﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ejercicio_5.Juego;
using Ejercicio_5.Casinos;

namespace Ejercicio_5
{
    public class Jugador
    {
        public void JugarEnLosCasinos()
        {
            Jugar juego = new Jugar(new CasinoApuestas());
            juego.juegaCasino();
            Jugar juego2 = new Jugar(new CasinoCartas());
            juego2.juegaCasino();
            Jugar juego3 = new Jugar(new CasinoTragaperras());
            juego3.juegaCasino();
        }
    }
}
