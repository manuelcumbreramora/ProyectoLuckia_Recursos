﻿namespace kata3Eloy.Formularios
{
    partial class LigaFutbol
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LigaFutbol));
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.IDPartido = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Equipo1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Equipo2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tbId = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.rbEquipo1 = new System.Windows.Forms.RadioButton();
            this.rbEquipo2 = new System.Windows.Forms.RadioButton();
            this.pbvuelta = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbvuelta)).BeginInit();
            this.SuspendLayout();
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Location = new System.Drawing.Point(45, 27);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 22);
            this.dateTimePicker1.TabIndex = 0;
            this.dateTimePicker1.Value = new System.DateTime(2020, 3, 26, 0, 0, 0, 0);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IDPartido,
            this.Equipo1,
            this.Equipo2});
            this.dataGridView1.Location = new System.Drawing.Point(45, 77);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(429, 206);
            this.dataGridView1.TabIndex = 1;
            // 
            // IDPartido
            // 
            this.IDPartido.HeaderText = "Id Partido";
            this.IDPartido.MinimumWidth = 6;
            this.IDPartido.Name = "IDPartido";
            this.IDPartido.Width = 125;
            // 
            // Equipo1
            // 
            this.Equipo1.HeaderText = "Equipo 1";
            this.Equipo1.MinimumWidth = 6;
            this.Equipo1.Name = "Equipo1";
            this.Equipo1.Width = 125;
            // 
            // Equipo2
            // 
            this.Equipo2.HeaderText = "Equipo 2";
            this.Equipo2.MinimumWidth = 6;
            this.Equipo2.Name = "Equipo2";
            this.Equipo2.Width = 125;
            // 
            // tbId
            // 
            this.tbId.Location = new System.Drawing.Point(58, 39);
            this.tbId.Name = "tbId";
            this.tbId.Size = new System.Drawing.Size(90, 22);
            this.tbId.TabIndex = 2;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.rbEquipo2);
            this.panel1.Controls.Add(this.rbEquipo1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.tbId);
            this.panel1.Location = new System.Drawing.Point(507, 77);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(210, 165);
            this.panel1.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(507, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(205, 20);
            this.label1.TabIndex = 4;
            this.label1.Text = "Seleccione su apuesta:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(54, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "ID Partido";
            // 
            // rbEquipo1
            // 
            this.rbEquipo1.AutoSize = true;
            this.rbEquipo1.Location = new System.Drawing.Point(18, 77);
            this.rbEquipo1.Name = "rbEquipo1";
            this.rbEquipo1.Size = new System.Drawing.Size(85, 21);
            this.rbEquipo1.TabIndex = 6;
            this.rbEquipo1.TabStop = true;
            this.rbEquipo1.Text = "Equipo 1";
            this.rbEquipo1.UseVisualStyleBackColor = true;
            // 
            // rbEquipo2
            // 
            this.rbEquipo2.AutoSize = true;
            this.rbEquipo2.Location = new System.Drawing.Point(109, 77);
            this.rbEquipo2.Name = "rbEquipo2";
            this.rbEquipo2.Size = new System.Drawing.Size(85, 21);
            this.rbEquipo2.TabIndex = 7;
            this.rbEquipo2.TabStop = true;
            this.rbEquipo2.Text = "Equipo 2";
            this.rbEquipo2.UseVisualStyleBackColor = true;
            // 
            // pbvuelta
            // 
            this.pbvuelta.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbvuelta.Image = ((System.Drawing.Image)(resources.GetObject("pbvuelta.Image")));
            this.pbvuelta.Location = new System.Drawing.Point(738, 269);
            this.pbvuelta.Name = "pbvuelta";
            this.pbvuelta.Size = new System.Drawing.Size(50, 43);
            this.pbvuelta.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbvuelta.TabIndex = 12;
            this.pbvuelta.TabStop = false;
            this.pbvuelta.Click += new System.EventHandler(this.pbvuelta_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Lime;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(58, 114);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(99, 38);
            this.button1.TabIndex = 8;
            this.button1.Text = "Apostar";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // LigaFutbol
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(800, 324);
            this.Controls.Add(this.pbvuelta);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.dateTimePicker1);
            this.MaximumSize = new System.Drawing.Size(818, 371);
            this.MinimumSize = new System.Drawing.Size(818, 371);
            this.Name = "LigaFutbol";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LigaFutbol";
            this.Load += new System.EventHandler(this.LigaFutbol_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbvuelta)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDPartido;
        private System.Windows.Forms.DataGridViewTextBoxColumn Equipo1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Equipo2;
        private System.Windows.Forms.TextBox tbId;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton rbEquipo2;
        private System.Windows.Forms.RadioButton rbEquipo1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pbvuelta;
    }
}