﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hosteleria
{
    public class Restaurante : Establecimiento
    {
        public string designacion { get; set; }
        public string direccion { get; set; }
        public Restaurante()
        {

        }
        public Restaurante(string desig, string direc)
        {
            this.designacion = desig;
            this.direccion = direc;
        }

        public override void registro()
        {
            this.nombre = "Caldero de fuego";
            this.cif = "12345";
            this.designacion = "Restaurante";
            this.direccion = "Calle Alcala Nº 4";
        }
    }
}
