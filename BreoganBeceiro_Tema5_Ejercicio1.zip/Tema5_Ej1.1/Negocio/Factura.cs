﻿//BreoBeceiro:31/03/2020
//PLEXUS | Tema5.1

//Para importes monetarios, el mejor tipo de dato es DECIMAL.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Persistencia;

namespace Negocio
{
    public class Factura
    {
        private string numero { get; set; }
        public decimal importe { get; set; }
        public string concepto { get; set; }
        public DateTime fecha { get; set; }


        public Factura() { }

        public Factura(string _num, decimal _cant, DateTime _fecha)
        {
            numero = _num;
            importe = _cant;
            fecha = _fecha;
        }


        public static bool nuevaFactura(Factura _factura)
        {
            DAO.guardaFactura(_factura.concepto, _factura.importe, _factura.fecha);
            return true;
        }
    }
}
