﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ej2tema3._4
{
    class Persona
    {
        public String Nombre { get; }

        private UInt16 Edad { get; }

        public Persona(String nombre, UInt16 edad)
        {
            this.Nombre = nombre;
            this.Edad = edad;
        }

        public Jugador RegistrarJugador()
        {
            return new Jugador(Nombre, Edad);
        }
    }
}
