﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ej4tema3
{
    class EventoAtletismo:IEvento
    {
        List<String> Participantes { get; set; }

        private String Ganador = null;

        private readonly Random Rand = new Random();
        public Resultado ObtenerResultado()
        {
            return new ResultadoGanador(Ganador);
        }

        public void SimularResultado()
        {
            Ganador = Participantes.ElementAt(Rand.Next(Participantes.Count));
        }
    }
}
