﻿using System;
using IFiguraSpace;
using TrianguloSpace;
using RectanguloSpace;
using CuadradoSpace;

namespace GeneradorSpace
{
    public static class Generador
    {
        public static Triangulo GenerarTriangulo()
        {
            Random ran = new Random();
            return new Triangulo(ran.Next(1,10));
        }

        public static Rectangulo GenerarRectangulo()
        {
            Random ran = new Random();
            return new Rectangulo(ran.Next(1, 10), ran.Next(1, 10));
        }

        public static Cuadrado GenerarCuadrado()
        {
            Random ran = new Random();
            return new Cuadrado(ran.Next(1, 10));
        }
    }
}
