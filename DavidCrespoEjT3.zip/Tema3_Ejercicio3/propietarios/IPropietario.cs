﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ejercicio3
{
    interface IPropietario
    {
        void crearFactura(String nombre, String apellidos, int costeReparacion);

    }
}
