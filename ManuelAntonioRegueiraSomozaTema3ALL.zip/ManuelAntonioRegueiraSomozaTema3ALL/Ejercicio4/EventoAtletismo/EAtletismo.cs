﻿using InterfaceEventos;
using InterfaceSistemaCentral;
using PUtilidadesAleatorias;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventoAtletismo
{
    public class EAtletismo : IEvento
    {
        private DateTime Fecha;
        private String Nombre;
        private int Resultado;

        public EAtletismo(String nombreE)
        {
            Fecha = DateTime.Now;
            Nombre = nombreE;
            Resultado = 0;
        }

        public int GetResultado()
        {
            return this.Resultado;
        }

        public void JugarEvento()
        {
            
            this.Resultado = FuncionesAleatorias.generarAleatorio();
        }

        public void MostrarEvento()
        {
            Console.WriteLine("Nombre: {0} ", this.Nombre);
            Console.WriteLine("Fecha: {0} ", this.Fecha);
            Console.WriteLine("Resultado Actual(en puntos): {0} ", this.Resultado);
        }
    }
}
