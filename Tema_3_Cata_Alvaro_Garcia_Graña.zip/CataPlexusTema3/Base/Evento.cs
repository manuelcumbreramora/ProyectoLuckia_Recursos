﻿using System;
using System.Collections.Generic;

namespace Base
{
    public class Evento
    {
        public Dictionary<int, string> eventos = new Dictionary<int, string>();

        public string nombreEventoSeleccionado { get; set; }

        public int eventoSeleccionado { get; set; }

        public Dictionary<int, string> generarEventos()
        {
            eventos.Add(1, "Futbol");
            eventos.Add(2, "Baloncesto");
            eventos.Add(3, "Fórmula 1");
            return eventos;
        }
    }
}
