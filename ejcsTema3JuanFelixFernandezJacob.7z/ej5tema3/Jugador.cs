﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ej5tema3
{
    class Jugador
    {
        public String Nombre { get; set; }
        public void Jugar()
        {
            Casino casinoGrand = new CasinoGrand();
            Casino casinoRoyale = new CasinoRoyale();
            Casino casinoGreat = new CasinoGreat();

            casinoGrand.Jugar(this);
            casinoRoyale.Jugar(this);
            casinoGreat.Jugar(this);
        }
    }
}
