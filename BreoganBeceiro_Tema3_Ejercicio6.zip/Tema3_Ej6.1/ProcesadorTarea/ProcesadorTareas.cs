﻿//BreoBeceiro:25/03/2020
//PLEXUS | Tema3

//En 'ComunicacionServicio.cs' se describen los métodos derivados de este script.
//Código inicial en C:\Users\breogan.beceirocasti\Desktop\Formación Plexus\Tema3\Prácticas\3.5 Fundamentos POO 2\CodeEjercicio6

using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Consola
{
    public class ProcesadorTareas
    {
        private async Task Procesar()
        {
            try
            {
                Console.WriteLine("Inicio de procesamiento");


                #region "List|Array conectaServicioAsinc(URL)"
                var client = new HttpClient();
                var urlTareas = "https://jsonplaceholder.typicode.com/todos";
                var respuestaTareas = await client.GetAsync(urlTareas);
                respuestaTareas.EnsureSuccessStatusCode();
                var cuerpoRespuestaTareas = await respuestaTareas.Content.ReadAsStringAsync();
                Console.WriteLine(cuerpoRespuestaTareas);
                #endregion


                #region "bool creaListaTareasParaHacer(TAREAS)"
                var tareas = JsonConvert.DeserializeObject<Tarea[]>(cuerpoRespuestaTareas);
                var tareasNoRealizadas = tareas.Where(x => !x.Completed).ToList();

                var urlUsuarios = "https://jsonplaceholder.typicode.com/users";
                var respuestaUsuarios = await client.GetAsync(urlUsuarios);
                respuestaUsuarios.EnsureSuccessStatusCode();
                var cuerpoRespuestaUsuarios = await respuestaUsuarios.Content.ReadAsStringAsync();
                Console.WriteLine(cuerpoRespuestaUsuarios);

                var usuarios = JsonConvert.DeserializeObject<Usuario[]>(cuerpoRespuestaUsuarios);

                //Console.WriteLine("Inicio transformación ViewModels");

                var tareasViewModel = new List<TareaViewModel>();
                foreach (var tarea in tareasNoRealizadas)
                {
                    var tareaViewModel = new TareaViewModel()
                    {
                        Id = tarea.Id,
                        Title = tarea.Title.Trim(),
                        NombreUsuario = usuarios.Where(x => x.Id == tarea.UserId).First().Nombre.Trim()
                    };
                    tareasViewModel.Add(tareaViewModel);
                }
                #endregion


                Console.WriteLine("Inicio escritura de tareas en archivo");


                #region "bool escribeTareas()"
                using (StreamWriter writetext = new StreamWriter($@"{Directory.GetCurrentDirectory()}\tareas pendientes.txt")) ;
                #endregion

            }
            catch (IOException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    }
}