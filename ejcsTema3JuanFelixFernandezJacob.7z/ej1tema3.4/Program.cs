﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ej1tema3._4
{
    class Program
    {
        static void Main(string[] args)
        {
            Persona felix = new Persona("Félix", 36);

            Persona manuel = new Persona("Manuel", 30);

            Jugador manuelJugador=manuel.RealizarSubscripcion();

            manuelJugador.Apostar();
            manuelJugador.Apostar();
            manuelJugador.Apostar();

            Console.WriteLine("Terminar:");
            Console.ReadLine();
        }
    }
}
