﻿using BettorPenalties;
using Games;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Users;

namespace Penalizations
{
    public class RacingPenalty : AbstractPenalty
    {
        public RacingPenalty(int id, IBettor bettor, PenaltySeverity severity) : base(id, new Racing(), bettor, severity) { }

        public override float GetPenaltyAmount()
        {
            float _penaltyAmount = this.GetPenaltyBaseAmount();

            switch (this.Severity)
            {
                case PenaltySeverity.Low:
                    _penaltyAmount = _penaltyAmount * 1f;
                    break;
                case PenaltySeverity.Medium:
                    _penaltyAmount = _penaltyAmount * 1.10f;
                    break;
                case PenaltySeverity.High:
                    _penaltyAmount = _penaltyAmount * 1.20f;
                    break;
            }

            int numStrikes = this.Bettor.GetNumStrikes();
            float mul = 0.85f;
            if (numStrikes > 10)
            {
                mul = Math.Min(100f, (numStrikes - 10)) / 100f;
                mul = 1f + mul;
            }

            _penaltyAmount = _penaltyAmount * mul;
            return _penaltyAmount;
        }

        public override float GetPenaltyBaseAmount()
        {
            float _penaltyBaseAmount = 0.025f * this.Bettor.GetWallet();
            _penaltyBaseAmount = (_penaltyBaseAmount == 0f) ? 5f : _penaltyBaseAmount;

            return _penaltyBaseAmount;
        }
    }
}
