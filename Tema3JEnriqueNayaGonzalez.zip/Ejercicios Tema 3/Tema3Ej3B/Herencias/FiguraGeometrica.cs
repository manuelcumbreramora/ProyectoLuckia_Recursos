﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3Ej3B
{
    public class FiguraGeometrica
    {
        public FiguraGeometrica(int numLados, int longitudLado)
        {
            NumLados = numLados;
            LongitudLado = longitudLado;
        }

        public int NumLados { get; set; }
        public int LongitudLado { get; set; }

    }
}
