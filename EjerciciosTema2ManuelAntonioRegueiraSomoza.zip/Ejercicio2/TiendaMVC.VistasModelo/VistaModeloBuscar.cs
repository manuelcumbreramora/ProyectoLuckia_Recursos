﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TiendaMVC.VistasModelo
{
    public class VistaModeloBuscar
    {
        public string Nombre { get; set; }
    }
}
