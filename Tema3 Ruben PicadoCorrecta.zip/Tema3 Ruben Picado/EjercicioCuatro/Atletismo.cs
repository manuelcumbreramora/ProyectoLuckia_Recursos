﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioCuatro
{
    class Atletismo : IPuntuacion
    {
        public int puntos { get; set; }
        


        public override int CalculoPuntos(Jugador jugador, int importeApostado)
        {
            Console.WriteLine("Apostando al atletismo");
            Random random = new Random();
            if(random.Next(0, 30) < 20)
            {
                puntos = importeApostado / 2;
            }
            return importeApostado * 15;
        }
    }
   

}
