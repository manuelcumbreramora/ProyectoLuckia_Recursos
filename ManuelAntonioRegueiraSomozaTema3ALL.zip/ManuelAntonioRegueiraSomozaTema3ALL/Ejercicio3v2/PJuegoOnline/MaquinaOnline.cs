﻿using InterfazTipoJuego;
using InterfazTipoJugador;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMaquinaOnline
{
    public class MaquinaOnline : IJuego
    {
        public string NombreMaquina;

        public MaquinaOnline(String nombre)
        {
            NombreMaquina = nombre;

        }
        public void jugar()
        {
            Console.WriteLine("Jugamos en MAQUINA ONLINE ");
        }
    }
}
