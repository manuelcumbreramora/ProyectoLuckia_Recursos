﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hosteleria
{
    public class Comida : Tipo
    {
        public void elegir(Restaurante restaurante) 
        {
            Console.WriteLine("Elegir tipo de comida.");
        }
    }
}
