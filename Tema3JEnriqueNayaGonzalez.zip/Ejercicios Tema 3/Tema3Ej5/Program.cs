﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3Ej5
{
    class Program
    {
        static void Main(string[] args)
        {
            Casino1 casino1 = new Casino1();
            Casino2 casino2 = new Casino2();
            Casino3 casino3 = new Casino3();
            casino1.RealizarJuego();
            casino2.RealizarJuego();
            casino3.RealizarJuego();
            Console.ReadKey();
        }
    }
}
