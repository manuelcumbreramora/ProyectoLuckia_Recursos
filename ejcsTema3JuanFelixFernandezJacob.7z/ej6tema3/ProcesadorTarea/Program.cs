﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApp3;

namespace Consola
{
    class Program
    {
        static async Task Main(string[] args)
        {
            await new ProcesadorTareas().Procesar(new EntradaSalida(), new CodificacionDecodificacion());
            //Console.WriteLine("Hola Mundo");

        }
    }
}
