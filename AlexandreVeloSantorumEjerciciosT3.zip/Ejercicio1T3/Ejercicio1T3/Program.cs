﻿using System;
using PersonaClase;
using JugadorClase;

namespace Ejercicio1T3
{
    class Program
    {
        static void Main(string[] args)
        {
            Persona p = new Persona();
            string nombre;
            int edad;
            string cantidad;
            Console.WriteLine("Introduce el nombre");
            nombre = Console.ReadLine();
            Console.WriteLine("Introduce la edad");
            edad = Int32.Parse(Console.ReadLine());
            p.realizarSuscripcion(nombre, edad);
            Jugador j = new Jugador(p);
            do
            {
                Console.WriteLine("Escribe la cantidad que quieres apostar (10,20,100) o * para salir:");
                cantidad = Console.ReadLine();
                if(cantidad != "*")
                {
                    j.apostar(cantidad);
                }
            } while (cantidad != "*");
            Console.WriteLine("Gracias por jugar con nosotros");
        }
}
}
