﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ej5tema3
{
    class CasinoRoyale:Casino



    {
        public void Jugar(Jugador jugador)
        {
            System.Console.WriteLine("El jugador " + jugador.Nombre + " juega en un CasinoRoyale");
        }
    }
}
