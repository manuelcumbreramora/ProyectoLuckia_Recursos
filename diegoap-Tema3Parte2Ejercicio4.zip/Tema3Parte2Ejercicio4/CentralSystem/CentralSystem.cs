﻿using BetEvents;
using PointsCalculator;
using System;
using System.Collections.Generic;

namespace CentralSystem
{
    public static class CentralSystem
    {
        public static void showBetResults(List<AbstractBetEvent> betEvents)
        {
            AbstractPointsCalculator pointsCalculator;

            Console.WriteLine("id ;; bettor ;; sport ;; result ;; points ;; amount");
            foreach (AbstractBetEvent item in betEvents)
            {
                switch (item.sport.ToLower())
                {
                    case "athletics":
                        pointsCalculator = new AthleticsPointsCalculator();
                        break;
                    case "football":
                        pointsCalculator = new FootballPointsCalculator();
                        break;
                    case "racing":
                        pointsCalculator = new RacingPointsCalculator();
                        break;
                    default:
                        pointsCalculator = null;
                        break;
                }

                if (pointsCalculator != null)
                {
                    string[] betResults = item.reportResult();
                    float points = pointsCalculator.calculatePoints(betResults);
                    float amount = AbstractPointsCalculator.calculateAmount(points);

                    Console.Write(item.id + " ;; " + item.bettor.name + " ;; " + item.sport + " ;; ");
                    Console.Write(item.resultHumanReadable(betResults) + " ;; ");

                    Console.WriteLine(points + " ;; " + amount);
                }
                else
                {
                    Console.WriteLine("Unrecoverable error! - Exit application.");
                    Environment.Exit(-1);
                }
            }

        }
    }
}
