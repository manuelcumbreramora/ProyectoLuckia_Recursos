﻿using PApuesta;
/*Diseñamos un una aplicacion que permita jugar diferentes tipos de apuestas (apuesta y apuesta premium, que hereda de apuesta
 y permite consultar con un experto si seguir apostando.
 Tambien tenemos varios tipos de Jugador(JugadorBasico, JugadorPremium) donde aplicamos la abstraccion.
 Tambien tenemos varios tipos de Juego(maquinaFisica,maquinaOnline) donde aplicamos abstraccion.
     */



using PJugadorBasico;
using PJugadorPremium;
using PMaquinaFisica;
using PMaquinaOnline;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio3v2
{
    class Program
    {
        static void Main(string[] args)
        {
            JugadorPremium jugadorA = new JugadorPremium("RobertoPremium", 43, true);
            JugadorBasico jugadorB = new JugadorBasico("JuanBasico", 22, true);
            JugadorPremium jugadorC = new JugadorPremium("XoanPremium", 12, true);
            JugadorBasico jugadorD = new JugadorBasico("AlbertoBasico", 11, true);

            MaquinaFisica tragaperrasA = new MaquinaFisica("TragaperrasBar");
            MaquinaOnline tragaperrasB = new MaquinaOnline("TragaperrasOnline");
     
            Apuesta apuestaBasica = new Apuesta(tragaperrasA, jugadorA);
            Apuesta apuestaOnline= new Apuesta(tragaperrasB, jugadorB);
            ApuestaPremium apuestaP1 = new ApuestaPremium(tragaperrasB, jugadorA,"Juan Tamariz");
            apuestaBasica.Apostar();
            Console.ReadLine();
            apuestaOnline.Apostar();
            Console.ReadLine();
            apuestaP1.ConsultarApuestaConsultor();
            Console.ReadLine();
            apuestaP1.Apostar();
            Console.ReadLine();


        }
    }
}
