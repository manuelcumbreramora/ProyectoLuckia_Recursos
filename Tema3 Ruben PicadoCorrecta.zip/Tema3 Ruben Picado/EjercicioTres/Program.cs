﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioDosU
{
    class Program 
    {
        static void Main(string[] args)
        {

            int num = 8;
            Hereda hereda = new Hereda();
            Poli pol = new Poli();
            Console.WriteLine("Bienvenido");
            Console.WriteLine("Introduzca un numero");
            
            num = int.Parse(Console.ReadLine());
            hereda.PosicionCampo(num);
            pol.PosicionCampo(num);

            Console.ReadKey();
            
            
            

        }
    }
}
