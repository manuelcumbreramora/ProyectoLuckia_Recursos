﻿using System;
using DatosProyecto;

namespace NegocioProyecto
{
    public class Negocio
    {
        public void obtenerDatos(String usuario, String password, Boolean ok)
        {
            Datos datos = new Datos();
            if (usuario != "" && password != "" && password.Length >= 6)
            {
                Console.WriteLine("Tu usario y contraseña ha sido enviado a Negocio");
                ok = true;
                datos.enviarDatos(usuario, password);
            }
            else
            {
                Console.WriteLine("El valor de la contraseña ha de tener al menos 6 caractéres");
            }
        }
    }
}