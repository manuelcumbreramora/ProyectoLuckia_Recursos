﻿/*Un jugador online, dispone de 3 tipos de casinos online para jugar.
El jugador, realizará juegos en los tres, de forma secuencial.
Implementar este caso, aplicando Interfaces
*/


/*Lógicamente en el programa se podrían meter cosas tipo control edad, lo que pasa cuando se escribe un valor fuera
del rango de la apuesta, etc. etc. cosas que no he metido por falta de tiempo*/



using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ejercicio5
{
    class Program
    {
        static void Main(string[] args)
        {
            int eleccion = 0;
            int ganancia;
            int apuesta = 100; //en el futuro poder elegir cuánto apostar
            Jugador j = new Jugador();
            j.realizarSuscripcion();

            while (eleccion != 5)
            {
                j.menu();
                eleccion = Int16.Parse(Console.ReadLine());
                switch (eleccion)
                {
                    case 1:
                        Casino1 c = new Casino1();
                        ganancia = c.Juego();
                        j.monedero = j.monedero + ganancia - apuesta;
                        Console.WriteLine("Su saldo actual es de " + j.monedero + " euros");
                        break;
                    case 2:
                        Casino2 c2 = new Casino2();
                        ganancia = c2.Juego();
                        j.monedero = j.monedero + ganancia - apuesta;
                        Console.WriteLine("Su saldo actual es de " + j.monedero + " euros");
                        break;
                    case 3:
                        Casino3 c3 = new Casino3();
                        ganancia = c3.Juego();
                        j.monedero = j.monedero + ganancia - apuesta;
                        Console.WriteLine("Su saldo actual es de " + j.monedero + " euros");
                        break;
                    case 4:
                        j.cargaMonedero();
                        break;
                    case 5:
                        break;
                    default:
                        Console.WriteLine("Valor no válido, ingrese un nuevo valor");
                            break;

                }


            }

            Console.WriteLine("Esperamos volver a verle pronto");
            Console.ReadLine();




            //While juego !=4
            //Al jugar se resta 100 del monedero

        }
    }
}
