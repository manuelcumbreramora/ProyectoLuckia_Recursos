﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Herencias
{
    public class Cirujano : InterfazCirujano
    {
        public string nombre = "Alba";

        public void operarPaciente(Cirujano cirujano)
        {
            Console.WriteLine("Tu cirujana será " + nombre);
        }
    }
}
