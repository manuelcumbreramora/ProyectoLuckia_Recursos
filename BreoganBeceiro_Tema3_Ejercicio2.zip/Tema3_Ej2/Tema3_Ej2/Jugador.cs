﻿//BreoBeceiro:23/03/2020
//PLEXUS | Tema3

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ej2
{
    public class Jugador : Persona
    {
        private string codigo { get; set; }
        private int monedero { get; set; }
        
        public Jugador(string code, int wallet)
        {
            this.codigo = code;
            this.monedero = wallet;
        }

        //Este método iría en realidad en una clase DAO:
        public float consultaCreditos(string code)
        {
            //SELECT creditos FROM jugadores WHERE codigo=:code;
            return monedero;
        }

        public bool renovarSuscripcion(string code)
        {
            return true;
        }
    }
}
