﻿//BreoBeceiro:24/03/2020
//PLEXUS | Tema3

//ESTA CLASE ESTÁ PENDIENTE DE EVALUAR. PODRÍA DESAPARECER.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ej4
{
    public class Evento
    {
        public enum modalidad
        {
            Atletismo, Futbol, Carreras
        }
    }
}
