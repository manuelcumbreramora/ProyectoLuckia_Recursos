﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurantes
{
    class Program
    {
        static void Main(string[] args)
        {
            int opt;
            int precio;
            RestauranteCHI r_Chi = new RestauranteCHI();
            RestauranteITA r_Ita = new RestauranteITA();
            Console.WriteLine("Decida el restaurante en el que va a comer:");
            Console.WriteLine("1. Restaurante Chino.");
            Console.WriteLine("2. Restaurante Italiano.");
            opt = Int32.Parse(Console.ReadLine());
            switch (opt)
            {
                case 1:
                    r_Chi.visita();
                    precio = cobrar();
                    Console.WriteLine("Gracias! Es un total de " + precio + " euros.");
                    break;
                case 2:
                    r_Ita.visita();
                    precio = cobrar();
                    Console.WriteLine("Gracias! Es un total de " + precio + " euros.");
                    break;
                default:
                    Console.WriteLine("Escoja una opcion valida.");
                    break;
            }
            Console.WriteLine("Fin de programa.");
            Console.ReadKey();
        }
        private static int cobrar()
        {
            Random rnd = new Random();
            int precio;
            precio = rnd.Next(10, 20);
            return precio;
        }
    }
}
