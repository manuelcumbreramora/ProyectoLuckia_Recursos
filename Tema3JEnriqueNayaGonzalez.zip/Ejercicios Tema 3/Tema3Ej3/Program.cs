﻿using System;

namespace Tema3Ej3
{
    class Program
    {
        static void Main(string[] args)
        {
            Cuadrado cuadrado = new Cuadrado(4, 10);
            Console.WriteLine("La longitud del cuadrado es: "+Utilidades.Longitud(cuadrado.NumeroLados(),cuadrado.LargoLados()));
            Console.WriteLine("El área del cuadrado es: "+cuadrado.obtenerArea(cuadrado.LargoLados()));
            Circulo circulo = new Circulo(5);
            Console.WriteLine("El area del círculo es: "+circulo.obtenerArea(circulo.radio));
            Console.ReadKey();
        }
    }
}
