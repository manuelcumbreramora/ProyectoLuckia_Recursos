﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Persistencia
{
    public class XML : IPersistencia
    {
        public void cargaDatos(Array array)
        {
            Console.WriteLine("Carga datos desde un archivo XML");
        }

        public void guardaDatos(Array array)
        {
            Console.WriteLine("Guarda datos en un archivo XML");
        }
    }
}
