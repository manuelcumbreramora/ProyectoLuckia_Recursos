﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ej2tema3._4
{
    class Program
    {

        static void Main(string[] args)
        {
            Persona felix = new Persona("Félix", 36);

            Jugador jugadorFelix = felix.RegistrarJugador();

            Juego voleibol = new Voleibol();
            Juego balonmano = new Balonmano();
            Juego futbol = new Futbol();

            voleibol.Jugar(jugadorFelix);
            voleibol.Jugar(jugadorFelix);
            futbol.Jugar(jugadorFelix);

            
        }
    }
}
