﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ejercicio3
{
    class Vehiculo
    {
        public Vehiculo()
        {
            
        }

        public Vehiculo(string costeVehiculo, string color, int anio)
        {
            this.costeVehiculo = costeVehiculo;
            this.color = color;
            this.anio = anio;
        }

        public String costeVehiculo { get; set; }
        public String color { get; set; }
        public int anio { get; set; }

        public int matricula;

        public virtual int generarMatricula()
        {
            var rand = new Random();
            matricula = rand.Next(100000, 999999);
            return matricula;

        }




    }
}
