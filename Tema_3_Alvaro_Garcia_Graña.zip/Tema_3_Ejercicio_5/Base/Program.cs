﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Base
{
    class Program
    {
        static void Main(string[] args)
        {
            Casino1 casino1 = new Casino1();
            Casino2 casino2 = new Casino2();
            Casino3 casino3 = new Casino3();

            //Mismo metodo diferente salida
            casino1.jugar();
            casino2.jugar();
            casino3.jugar();
            Console.ReadKey();
        }
    }
}
