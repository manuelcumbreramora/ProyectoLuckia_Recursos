﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bets
{
    public class RouletteBet : AbstractBet
    {
        public RouletteBet(string[] bet, float amount) : base(AbstractBet.BetGame.Roulette, bet, amount) { }
    }
}
