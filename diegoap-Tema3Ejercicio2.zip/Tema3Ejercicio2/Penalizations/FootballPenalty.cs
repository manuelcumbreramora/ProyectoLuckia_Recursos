﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Games;
using Users;


namespace BettorPenalties
{   
    public class FootballPenalty : AbstractPenalty
    {
        public const float PENALTY_BASE_AMOUNT = 100f;

        public FootballPenalty(int id, IBettor bettor, PenaltySeverity severity) : base(id, new Football(), bettor, severity) { }

        public override float GetPenaltyBaseAmount()
        {
            return PENALTY_BASE_AMOUNT;
        }

        public override float GetPenaltyAmount()
        {
            float _penaltyAmount = this.GetPenaltyBaseAmount();

            int numStrikes = this.Bettor.GetNumStrikes();
            if (numStrikes <= 5)
            {
                _penaltyAmount = _penaltyAmount / 20f; 
            } 
            else if ((numStrikes > 5) && (numStrikes <= 20))
            {
                _penaltyAmount = _penaltyAmount / 10f;
            } 
            else if ((numStrikes > 20) && (numStrikes <= 50))
            {
                _penaltyAmount = _penaltyAmount / 5f;
            } 
            else
            {
                _penaltyAmount = _penaltyAmount / 1f;
            }

            switch (this.Severity)
            {
                case PenaltySeverity.Low:
                    _penaltyAmount = _penaltyAmount * 1f;
                    break;
                case PenaltySeverity.Medium:
                    _penaltyAmount = _penaltyAmount * 1.15f;
                    break;
                case PenaltySeverity.High:
                    _penaltyAmount = _penaltyAmount * 1.30f;
                    break;
            }

            return _penaltyAmount;
        }
    }
}
