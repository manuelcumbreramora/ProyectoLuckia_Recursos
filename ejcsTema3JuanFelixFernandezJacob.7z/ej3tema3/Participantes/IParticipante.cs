﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimuladorCarreras
{
    interface IParticipante
    {
        /*
         * Devuelve el tiempo en segundos, pese a usar double.
         * */
        double ObtenerTiempo(double longitud);

        
        String ObtenerInformacion();
    }
}
