﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_5.Juego
{
    public class Jugar
    {
        public Jugar(IJugar ijugar)
        {
            this.ijugar = ijugar;
        }

        IJugar ijugar { get; set;}
        public void juegaCasino()
        {
            ijugar.Jugar();
        }

    }
}
