﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurantes
{
    public class RestauranteCHI : Restaurante
    {
        public string nombre { get; set; }
        public string tipo { get; set; }
        public RestauranteCHI()
        {
            this.nombre = "Sho Win Ha";
            this.tipo = "Chino";
        }
        public override void visita()
        {
            Console.WriteLine("Usted ha visitado el restaurante " + this.nombre);
        }
    }
}
