﻿using JuegoMesa;
using OperacionesGeneracionAleatorias;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JuegoRuletaEuropea
{
    public class MesaRuletaEuropea: Mesa
    {
        private int EnPrision;


        public MesaRuletaEuropea(int numMesa, int prision, string nombreJuego)
        {
            NumeroMesa = numMesa;
            EnPrision = prision;
            NombreJuego = nombreJuego;

        }


        public void MostrarDetallesDatosJuego()
        {
            this.MostrarDatosJuego();
            Console.WriteLine("Juego en Prisión {0}", this.EnPrision);
        }
    }
}
