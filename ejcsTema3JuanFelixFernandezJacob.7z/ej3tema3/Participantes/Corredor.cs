﻿namespace SimuladorCarreras
{
    internal class Corredor : IParticipante
    {

        private string Nombre;

        private int Edad;

        public double VelocidadMedia { get; set; }
        public double DesviacionTipica { get; set; }

        public enum TNacionalidad
        {
            ES, FR, PT, UK, IT, US,
            CO
        }

        private TNacionalidad Nacionalidad;

        public Corredor(string nombre, int edad, TNacionalidad nacionalidad)
        {
            this.Nombre = nombre;
            this.Edad = edad;
            this.Nacionalidad = nacionalidad;
        }

        public string ObtenerInformacion()
        {
            return "Nombre: " + Nombre + "; Edad: " + Edad;
        }

        /*
         * El tiempo para corredores se calcula de una forma ligeramente diferente.
         */
        public double ObtenerTiempo(double longitud)
        {
            double velocidadAhora = General.GenerarAleatorioDistNormal(VelocidadMedia, DesviacionTipica);

            double tiempo = velocidadAhora * longitud;

            double penalizacion = 1.2 * (longitud / 1000);

            return tiempo/penalizacion;
        }
    }
}