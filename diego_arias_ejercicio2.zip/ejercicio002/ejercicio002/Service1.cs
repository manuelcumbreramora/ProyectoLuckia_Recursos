﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio002
{
    public partial class Service1 : ServiceBase
    {
        public const string SOURCE_DIR = "ejercicio002SrcDir";
        public const string DEST_DIR = "ejercicio002DestDir";

        public Service1()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            //string userDir = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            string userDir = "C:\\Users\\diego.ariasprado";

            string sourceDir = userDir + Path.DirectorySeparatorChar + SOURCE_DIR;
            string destDir = userDir + Path.DirectorySeparatorChar + DEST_DIR; ;

            string destFile;

            // NOTE: This array stores the full paths of all the files contained in the directory SOURCE_DIR.
            string[] filePaths = Directory.GetFiles(sourceDir);

            foreach (var sourceFile in filePaths)
            {
                destFile = destDir + Path.DirectorySeparatorChar + Path.GetFileName(sourceFile);

                // If the destination file exists, it will overwritten without any warning.
                File.Copy(sourceFile, destFile);
            }
        }

        protected override void OnStop()
        {
        }
    }
}
