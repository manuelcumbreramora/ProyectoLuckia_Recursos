﻿//BreoBeceiro:24/03/2020
//PLEXUS | Tema3

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ej2
{
    class Balonmano : Juego
    {
        public string local { get; set; }
        public string visitante { get; set; }
        public string torneo { get; set; }

        public Balonmano(string local, string visitor, string tournament, string date)
        {
            this.local = local;
            this.visitante = visitor;
            this.torneo = tournament;
            this.torneo = date;
        }
    }
}