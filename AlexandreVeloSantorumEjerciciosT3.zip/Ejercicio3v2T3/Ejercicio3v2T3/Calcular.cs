﻿using System;
using System.Collections.Generic;
using System.Text;
using IFiguraSpace;

namespace CalcularClase
{
    class Calcular
    {
        private IFigura figura;
        public Calcular(IFigura _figura)
        {
            this.figura = _figura;
        }

        public int calcArea()
        {
            return figura.Area();
        }

        public int calcPerimetro()
        {
            return figura.Perimetro();
        }
    }
}
