﻿using System;
using Herencias;

namespace Polimorfismos
{
    public class Polimorfismo
    {
        public void comprobar(int tipo)
        {
            Medico medico = new Medico();
            Cirujano cirujano = new Cirujano();
            Hospital hospital = new Hospital(medico, cirujano);
            Console.WriteLine(hospital.devolverCamasDisponibles(tipo));
            if (tipo == 1)
            {
                hospital.asignarMedico(medico);
            } else if (tipo == 2)
            {
                hospital.asignarCirujano(cirujano);
            }
            
        }

    }
}
