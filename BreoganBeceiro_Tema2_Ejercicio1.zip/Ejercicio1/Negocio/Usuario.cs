﻿//BreoBeceiro:18/03/2020
//PLEXUS | Tema2

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NS_Negocio
{
    public class Usuario
    {
        public string nombre;
        public string apellido;
        public int edad;

        public Usuario(string name, string lastname, int age)
        {
            this.nombre = name;
            this.apellido = lastname;
            this.edad = age;
        }

        public bool compra()
        {
            bool resultado;

            Console.WriteLine("Estoy comprando...");
            resultado = true;

            return resultado;
        }
    }
}
