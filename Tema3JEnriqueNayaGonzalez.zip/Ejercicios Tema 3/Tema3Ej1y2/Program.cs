﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3Ej1
{
    class Program
    {
        static void Main(string[] args)
        {
            Jugador player = new Jugador();
            Console.WriteLine("Bienvenido a Luckia, escriba su nombre de usuario:");
            String nombre=Console.ReadLine();
            Console.WriteLine("Introduzca su edad:");
            int edad = int.Parse(Console.ReadLine());
            if (edad < 18)
            {
                Console.WriteLine("Lo lamento, no tiene usted la edad suficiente para registrarse. Adios");
            }
            else
            {
                player.RealizarSuscripcion(player, nombre, edad);
                player.monedero = 100;
                player.apostar();
            }
            Console.ReadKey();
        }
    }
}
