﻿using System;

namespace Abstraccion
{
    public abstract class Plazas
    {
        public int camasParaSanos = 20;

        public int camasParaGraves = 50;

        public abstract string devolverCamasDisponibles(int tipo);
    }
}
