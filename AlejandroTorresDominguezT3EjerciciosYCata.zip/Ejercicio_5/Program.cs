﻿/*Un jugador online, dispone de 3 tipos de casinos online para jugar.
El jugador, realizará juegos en los tres, de forma secuencial.
Implementar este caso, aplicando Interfaces*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ejercicio_5.Juego;
using Ejercicio_5.Casinos;

namespace Ejercicio_5
{
    class Program
    {
        static void Main(string[] args)
        {
            Jugador jugador = new Jugador();
            jugador.JugarEnLosCasinos();

            Console.ReadKey();
        }
    }
}
