﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3Ej1
{
    class Persona:Penalizador
    {
        public String nombre { get; set; }
        public int edad { get; set; }

        public void RealizarSuscripcion(Jugador jugador,string nombre, int edad)
        {
            jugador.nombre = nombre;
            jugador.edad = edad;
            Console.WriteLine("El jugador "+nombre+" se ha registrado correctamente");
        }
    }
}
