﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OperacionesGeneracionAleatorias
{
    public static class AleatorioBasico
    {
        public static int generarAleatorioBasico()
        {
            Random random = new Random();
            int numAleatorio = random.Next(0, 100);
            Console.WriteLine("Generando aleatorioBasico");   
            Console.ReadLine();
            return numAleatorio;
        }
        public static int generarAleatorioRuleta()
        {
            return 0;
        }
        public static int generarAleatorioTragaperras()
        {
            return 0;
        }
        public static int generarAleatorioMesa()
        {
            return 0;
        }


    }
}
