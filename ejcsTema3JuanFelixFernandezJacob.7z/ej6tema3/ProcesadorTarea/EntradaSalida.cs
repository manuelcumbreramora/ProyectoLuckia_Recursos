﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    public class EntradaSalida
    {

        private readonly HttpClient client = new HttpClient();
        public async Task<String> LeerCadenaClientesAsync()
        {
            var urlTareas = "https://jsonplaceholder.typicode.com/todos";
            var respuestaTareas = await client.GetAsync(urlTareas);
            respuestaTareas.EnsureSuccessStatusCode();
            var cuerpoRespuestaTareas = await respuestaTareas.Content.ReadAsStringAsync();

            return cuerpoRespuestaTareas;
        }

        public async Task<String> LeerCadenaUsuariosAsync()
        {
            var urlUsuarios = "https://jsonplaceholder.typicode.com/users";
            var respuestaUsuarios = await client.GetAsync(urlUsuarios);
            respuestaUsuarios.EnsureSuccessStatusCode();
            var cuerpoRespuestaUsuarios = await respuestaUsuarios.Content.ReadAsStringAsync();

            return cuerpoRespuestaUsuarios;
        }

        public void EscribirPantalla(string v)
        {
            Console.WriteLine(v);
        }

        public void EscribirFichero(string v)
        {
            using (StreamWriter writetext = new StreamWriter($@"{Directory.GetCurrentDirectory()}\tareas pendientes.txt"));
        }
    }
}
