﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Monedero
{
    public abstract class Calculos
    {
        public abstract void CalcularGanacia(int eventoSeleccionado, MonederoClass monedero);
    }
}
