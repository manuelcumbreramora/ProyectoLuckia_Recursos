﻿namespace ServicioCopy
{
    partial class Copy
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.sTimer = new System.Timers.Timer();
            ((System.ComponentModel.ISupportInitialize)(this.sTimer)).BeginInit();
            // 
            // sTimer
            // 
            this.sTimer.Enabled = true;
            this.sTimer.Interval = 120000D;
            this.sTimer.Elapsed += new System.Timers.ElapsedEventHandler(this.sTimer_Elapsed);
            // 
            // Copy
            // 
            this.ServiceName = "Service1";
            ((System.ComponentModel.ISupportInitialize)(this.sTimer)).EndInit();

        }

        #endregion

        private System.Timers.Timer sTimer;
    }
}
