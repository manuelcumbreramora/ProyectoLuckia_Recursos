﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ej2tema3._4
{
    abstract class Juego
    {


        public void Jugar(Jugador p)
        {
            // Lógica del juego.
            // La que sea.
            Console.WriteLine("El jugador " + p.Nombre + " juega a " + this.Nombre());

            DetectarTrampas(p);

        }

        protected abstract Boolean DetectarTrampa1();
        protected abstract Boolean DetectarTrampa2();
        protected abstract Boolean DetectarTrampa3();


        protected void DetectarTrampas(Jugador p)
        {
            // Tipo trampa 1.
            if (DetectarTrampa1())
            {
                new PenalizadorConcreto().Penalizar(p, this, Penalizador.TipoPenalizacion.Tipo1);
                // El penalizador es el que sabe la penalización.
            }

            // Tipo trampa 2.
            if (DetectarTrampa2())
            {
                new PenalizadorConcreto().Penalizar(p, this, Penalizador.TipoPenalizacion.Tipo2);
                // El penalizador es el que sabe la penalización.
            }

            // Tipo trampa 3.
            if (DetectarTrampa3())
            {
                new PenalizadorConcreto().Penalizar(p, this, Penalizador.TipoPenalizacion.Tipo3);
                // El penalizador es el que sabe la penalización.
            }
        }

        protected abstract String Nombre();


    }
}
