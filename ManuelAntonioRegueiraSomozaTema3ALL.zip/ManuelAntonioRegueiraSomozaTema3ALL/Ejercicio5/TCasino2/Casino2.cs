﻿using InterfaceCasino;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCasino2
{
    public class Casino2 : ICasino
    {
        private String Nombre;
        public Casino2(String nombre)
        {
            Nombre = nombre;

        }
        public void Jugar()
        {
            Console.WriteLine("Jugando a juego casinoTipo2 {0}", this.Nombre);
        }
    }
}
