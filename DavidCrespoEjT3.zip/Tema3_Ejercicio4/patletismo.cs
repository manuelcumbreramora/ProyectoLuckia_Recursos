﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ejercicio4
{
    class Patletismo : IPuntos
    {

        public int punt1 { get; set; }
        public int puntos { get; set; }

        public int calcularPuntos()
        {
            Random ran = new Random();
            punt1 = ran.Next(500, 1000);
            puntos = punt1 / 2;
            Console.WriteLine("El jugador ha ganado " + puntos + " puntos apostando al atletismo");
            return puntos;
        }

    }
}
