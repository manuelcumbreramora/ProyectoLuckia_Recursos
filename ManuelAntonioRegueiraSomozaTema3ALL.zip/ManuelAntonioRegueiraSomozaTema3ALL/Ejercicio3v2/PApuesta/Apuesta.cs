﻿using InterfazTipoJuego;
using InterfazTipoJugador;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PApuesta
{
    public class Apuesta
    {
        public IJuego Tjuego;
        public IJugador Tjugador;

        public Apuesta()
        {

        }
        public Apuesta(IJuego juego,IJugador jugador)
        {
            Tjuego = juego;
            Tjugador = jugador;

        }

       public void Apostar()
        {
            if (this.Tjugador.comprobarEdad())
            {
                Console.WriteLine("Jugador mayor de edad, puede jugar.");

                if (this.Tjugador.Pago())
                {
                    Console.WriteLine("Jugador a pagado, puede jugar.");
                    this.Tjuego.jugar();
                }
                else
                {
                    Console.WriteLine("Jugador no ha pagado, no jugar.");
                }
            }
            else
            {
                Console.WriteLine("Jugador menor de edad, no puede jugar.");
            }
           
        }


    }
}
