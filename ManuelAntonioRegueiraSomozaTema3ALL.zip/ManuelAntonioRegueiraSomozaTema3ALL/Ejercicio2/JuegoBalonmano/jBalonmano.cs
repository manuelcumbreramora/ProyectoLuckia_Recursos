﻿using JuegoJuego;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JuegoBalonmano
{
    public class JBalonmano : Juego
    {


        public JBalonmano(string nombre, string equipo1, string equipo2)
        {
            Nombre = nombre;
            Equipo1 = equipo1;
            Equipo2 = equipo2;
            Penalizacion = 2;
            Ganador = "Sin jugar";
        }
    }
}

