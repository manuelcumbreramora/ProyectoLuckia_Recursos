﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tema3Ej3B;
using Interfaces;

namespace Herencias
{
    public class Cuadrado : FiguraGeometrica, IPoligono
    {
        public Cuadrado(int longitudLado) : base(4, longitudLado)
        {
        }

        public double ObtenerArea()
        {
            return this.LongitudLado * this.LongitudLado;
        }

        public int ObtenerLongitud()
        {
            return this.NumLados * this.LongitudLado;
        }
    }
}
