﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimuladorCarreras
{
    class Caballo : IParticipante
    {
        private String Nombre { get; set; }

        private int Edad { get; set; }

        public float VelocidadMedia { get; set; }
        public float DesviacionTipica { get; set; }

        private Corredor jinete { get; set; }

        public string ObtenerInformacion()
        {
            return "Nombre: " + Nombre + "; Edad: " + Edad + "; Jinete: " + jinete.ObtenerInformacion();
        }

        public double ObtenerTiempo(double longitud)
        {

            double velocidadAhora = General.GenerarAleatorioDistNormal(VelocidadMedia, DesviacionTipica);

            double tiempo = velocidadAhora * longitud;

            return tiempo;
        }
    }
}
