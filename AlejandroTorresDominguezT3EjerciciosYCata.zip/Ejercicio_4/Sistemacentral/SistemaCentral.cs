﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_4
{
    public class SistemaCentral
    {
        public void calculoDinero(Jugador jugador)
        {
            foreach(var apuesta in jugador.listaApuestas)
            {
                jugador.monedero.cargaMonedero(apuesta.evento.generaPuntos() * 15);
            }
        }
    }
}
