﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Persistencia;

namespace Ejercicio_3._2.Datos
{
    class ManejoDatos
    {
        private IPersistencia persistencia;
        public ManejoDatos(IPersistencia _persistencia)
        {
            this.persistencia = _persistencia;
        }
        public void guardaDatos (Array array)
        {
            persistencia.guardaDatos(array);
        }
        public void cargaDatos (Array array)
        {
            persistencia.cargaDatos(array);
        }

    }
}
