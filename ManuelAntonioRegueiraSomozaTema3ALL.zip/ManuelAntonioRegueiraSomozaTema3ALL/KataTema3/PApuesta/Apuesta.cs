﻿using PEventos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PApuesta
{
   
    public class Apuesta
    {
        private int Importe;
        private int IdApuesta;
        private DateTime FechaApuesta;
        public IEventos EventoApuesta;
        private int ResultadoApostado;
        private int ResultadoFinalApostado;//0 aun no resuelta, 1 ganada, 2 perdida
        

        public Apuesta(int idApuesta,int importe, IEventos evento, int resultado)
        {
            Importe = importe;
            EventoApuesta = evento;
            FechaApuesta = DateTime.Now;
            ResultadoApostado = resultado;
            ResultadoFinalApostado = 0;
            IdApuesta = idApuesta;
        }

        public bool ResolverApuesta()
        {
            bool exitoApuesta = false;
            if ((this.EventoApuesta.DevolverResultadoFinal() == this.ResultadoApostado) && (this.EventoApuesta.DevolverResultadoFinal()!=0))
            {
                exitoApuesta = true;
                Console.WriteLine("La apuesta ha sido ganada.");
                this.ResultadoFinalApostado = 1;

            }
            else if(this.EventoApuesta.DevolverResultadoFinal()==0)
            {
                Console.WriteLine("Aun no se ha resuelto el evento");
                
            }
            else
            {
                Console.WriteLine("La apuesta ha sido perdida.");
                this.ResultadoFinalApostado = 2;
            }
            return exitoApuesta;
        }
        public void MostrarApuesta()
        {
            Console.WriteLine("IdApuesta: {0}", this.IdApuesta);
            Console.WriteLine("Fecha: {0}", this.FechaApuesta);
            Console.WriteLine("Importe: {0}", this.Importe);
            Console.WriteLine("Resultado apostado: {0}", this.ResultadoApostado);
            if (this.ResultadoFinalApostado == 1)
            {
                Console.WriteLine("GANADA");
            }else if(this.ResultadoFinalApostado==0){
                Console.WriteLine("Apuesta aun no resuelta");
            }else if (this.ResultadoFinalApostado == 2)
            {
                Console.WriteLine("PERDIDA");
            }
            Console.WriteLine("Evento");
            this.EventoApuesta.MostrarEvento();
        }
        public int GetResultadoFinal()
        {
            return this.ResultadoFinalApostado;
        }
        public int GetImporteApuesta()
        {
            return this.Importe;
        }
    }
}
