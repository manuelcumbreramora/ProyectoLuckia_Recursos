﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


/** En Futbol, se obtiene 0, 200 ó 300 puntos en función de si el jugador: 
resultado 1: ha fallado el resultado y fallado la quiniela, 
resultado 2: ha fallado el resultado pero ha acertado la quiniela, 
resultado 3: ha acertado resultado. */

namespace Tema3_Ejercicio4
{
    class Pfutbol : IPuntos
    {
        public int resultado { get; set; }
        public int puntos { get; set; }

        public int calcularPuntos()
        {
            Random ran = new Random();
            resultado = ran.Next(1, 4); //Simulamos resultado
            Console.WriteLine("El jugador está apostando al fútbol");
            switch (resultado)
            {
                case 1:
                    puntos = 0;
                    Console.WriteLine("El jugador ha fallado el resultado y fallado la quiniela");
                    break;

                case 2:
                    puntos = 200;
                    Console.WriteLine("El jugador ha fallado el resultado y pero acertado la quiniela");
                    break;
                case 3:
                    puntos = 300;
                    Console.WriteLine("El jugador ha acertado el resultado");
                    break;
            }
            
            Console.WriteLine("El jugador ha ganado " + puntos + " puntos apostando al fútbol");
            return puntos;

        }


    }
}
