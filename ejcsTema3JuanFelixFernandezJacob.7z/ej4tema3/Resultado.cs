﻿namespace ej4tema3
{
    interface Resultado
    {
        int Comparar(Resultado otroResultado);
    }
}