﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kata3Eloy
{
    public static class Usuario
    {
        private static string nombre;
        private static string pass;
     

        public static string Nombre { get => nombre; set => nombre = value; }
        public static string Pass { get => pass; set => pass = value; }
      

        public static void InsertarNombre(string nombre, string pass) {

            Usuario.nombre = nombre;
            Usuario.pass = pass;
        
        }
    }
}
