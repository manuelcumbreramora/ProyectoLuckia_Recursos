﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Taxes;

namespace TaxCalculator
{
    public abstract class AbstractTaxCalculator : ITaxCalculator
    {
        // An identifier.
        // If empty string, the tax calculator is intended to be the default one.
        public string id { get; }

        public AbstractTaxCalculator(string id)
        {
            this.id = id;
        }

        public abstract float calculateTotalTaxes(List<ITax> taxes, float amount);
    }
}
