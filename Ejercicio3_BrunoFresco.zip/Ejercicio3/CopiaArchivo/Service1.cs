﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace CopiaArchivo
{
    public partial class Service1 : ServiceBase
    {
        public Service1()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            string file = "test.txt";
            string rutaBase = "C:\\Users\\bruno.frescootero\\Desktop\\Ejercicio3";
            string rutaCopia = "C:\\Users\\bruno.frescootero\\Desktop\\Ejercicio3\\Copia";
            string origen = System.IO.Path.Combine(rutaBase, file);
            string destino = System.IO.Path.Combine(rutaCopia, file);
            System.IO.File.Copy(origen, destino, true);
            if (System.IO.Directory.Exists(rutaBase))
            {
                string[] files = System.IO.Directory.GetFiles(origen);
                foreach (string s in files)
                {
                    file = System.IO.Path.GetFileName(s);
                    destino = System.IO.Path.Combine(rutaCopia, file);
                    System.IO.File.Copy(s, destino, true);
                }
            }
            else
            {
                Console.WriteLine("La ruta origen no existe.");
            }
        }

        protected override void OnStop()
        {
            Console.Write("Fin de programa.");
        }
    }
}
