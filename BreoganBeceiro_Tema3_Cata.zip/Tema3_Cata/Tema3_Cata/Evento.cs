﻿//BreoBeceiro:26/03/2020
//PLEXUS | Tema3

//Introducir Evento como una Interfaz (IEvento) sería otra opción.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Cata
{
    public abstract class Evento
    {
        public string resultado { get; set; }

        public DateTime fecha { get; set; }


        public string resultadoEvento(string dateTime)
        {
            //Consulta a la BBDD y devuelve el marcador o resultado del evento...
            return "resultado";
        }

        public virtual bool hola()
        {
            return true;
        }
    }
}
