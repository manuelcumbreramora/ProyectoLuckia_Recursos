﻿//BreoBeceiro:24/03/2020
//PLEXUS | Tema3

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ej3
{
    class Arbitro : Persona, IPersona
    {
        private string numColegio { get; set; }


        /// <summary>
        /// Envía una petición a la aplicación para obtener el historial de participaciones del árbitro en los torneos de
        /// cartas.
        /// </summary>
        /// <param name="id">El código del árbitro.</param>
        /// <returns>TRUE si la petición es aceptada o FALSE si es rechazada.</returns>
        public override bool solicitaHistorial(string id)
        {
            return true;
        }

        /// <summary>
        /// Añade una entrada en el registro de árbitros.
        /// </summary>
        /// <returns>TRUE si todo fue bien o FALSE si hubo algún error.</returns>
        public bool fichar()
        {
            return true;
        }
    }
}
