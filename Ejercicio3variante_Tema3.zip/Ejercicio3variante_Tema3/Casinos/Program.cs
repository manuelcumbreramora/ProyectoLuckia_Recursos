﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hosteleria
{
    class Program
    {
        static void Main(string[] args)
        {   
            Restaurante res = new Restaurante();
            res.registro();
            Comida com = new Comida();
            Precio prec = new Precio();
            PagoRestaurante pago = new PagoRestaurante(com,prec);
            pago.comer(res);
            Console.WriteLine("Pulse una tecla para salir.");
            Console.ReadKey();
        }
    }
}
