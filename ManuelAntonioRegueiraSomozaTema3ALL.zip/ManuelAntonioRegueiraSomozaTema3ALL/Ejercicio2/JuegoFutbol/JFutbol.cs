﻿using JuegoJuego;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JuegoFutbol
{
    public class JFutbol : Juego
    {


        public JFutbol(string nombre, string equipo1, string equipo2)
        {
            Nombre = nombre;
            Equipo1 = equipo1;
            Equipo2 = equipo2;
            Penalizacion = 1;
            Ganador = "Sin jugar";
        }
    }
}
