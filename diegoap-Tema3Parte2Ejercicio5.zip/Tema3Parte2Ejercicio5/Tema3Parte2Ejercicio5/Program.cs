﻿using Bets;
using Casino;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3Parte2Ejercicio5
{
    public class Program
    {
        static List<IBet> bets;
        static List<AbstractCasino> casinos;

        static void Main(string[] args)
        {
            initBets();
            initCasinos();

            bool exitLoop = false;
            do
            {
                Console.WriteLine("\n\n");
                play();

                Console.Write("\n>>> Press 'x' to exit or any other key to play again ... ");
                char c = Console.ReadKey().KeyChar;

                exitLoop = (c == 'x') || (c == 'X');
            } while (!exitLoop);
        }

        static void initBets()
        {
            bets = new List<IBet>();
            bets.Add(new RouletteBet(new string[] { "12" }, 100f));
            bets.Add(new RouletteBet(new string[] { "9" }, 32f));
            bets.Add(new RouletteBet(new string[] { "25" }, 25f));
            bets.Add(new RouletteBet(new string[] { "0" }, 125f));
            bets.Add(new RouletteBet(new string[] { "11" }, 10f));
            bets.Add(new RouletteBet(new string[] { "37" }, 5f));
            bets.Add(new RouletteBet(new string[] { "18" }, 20f));
            bets.Add(new RouletteBet(new string[] { "000" }, 50f));
            bets.Add(new RouletteBet(new string[] { "31" }, 30f));
            bets.Add(new RouletteBet(new string[] { "6" }, 22f));
        }

        static void initCasinos()
        {
            casinos = new List<AbstractCasino>() { 
                new CaesarCasino(), 
                new FlamingoCasino(), 
                new StardustCasino() 
            };
        }

        static void play()
        {
            HelperMethods.shuffleList(casinos);
            HelperMethods.shuffleList(bets);

            foreach (AbstractCasino casino in casinos) {
                foreach (RouletteBet bet in bets)
                {                   
                    Tuple<Boolean, string> roulette = casino.playRouletteBet(bet);
                    bool winner = roulette.Item1;
                    string _roulette = roulette.Item2;

                    float amount = (winner) ? casino.calculateWinnerBetAmount(bet) : 0f;

                    Console.Write("casino " + casino.Id + ": bet = " + bet.GetBet()[0] + ", ");
                    Console.Write("betted amount = " + bet.GetAmount() + ", roulette = " + _roulette + ", ");
                    Console.WriteLine("winner " + winner.ToString() + ", amount = " + amount);
                }
            }
        }
    }
}
