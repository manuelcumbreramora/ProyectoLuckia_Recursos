﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BetEvents
{
    public class BetEventRacing : AbstractBetEvent
    {
        public BetEventRacing(int id, DateTime date, Bettor.Bettor bettor) : base(id, date, "racing", bettor) { }

        public BetEventRacing(int id, Bettor.Bettor bettor) : base(id, new DateTime(), "racing", bettor) { }

        // Fake, random calculation.
        public override string[] reportResult()
        {
            Random rnd = new Random(Guid.NewGuid().GetHashCode());
            int points = (rnd.NextDouble() < 0.33) ? 0 : rnd.Next(125, 250);
            return new string[] { (points + "") };
        }

        public override string resultHumanReadable(string[] result)
        {
            return (result[0] + " points");
        }
    }
}
