﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_Pago
{
    public class Jugador : Persona
    {
        public int edad { get; set; }
        public Jugador() { }
        public Jugador(int age)
        {
            this.nombre = "Bruno";
            this.edad = age;
        }
    }
}
