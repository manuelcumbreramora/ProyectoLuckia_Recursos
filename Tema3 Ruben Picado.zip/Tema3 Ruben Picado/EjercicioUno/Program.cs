﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioUno
{
    class Program
    {
        static void Main(string[] args)
        {
            Jugador jugador = new Jugador();
            jugador.inicio(jugador);

        }
    }
}
