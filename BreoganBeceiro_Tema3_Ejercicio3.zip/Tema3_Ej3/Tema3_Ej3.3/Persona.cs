﻿//BreoBeceiro:25/03/2020
//PLEXUS | Tema3

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ej3._3
{
    public abstract class Persona
    {
        private string id { get; set; }
        public string nombre { get; set; }


        public void enviaIncidencia()
        {
            //Envía un parte al servidor con la incidencia genérica...
        }
    }
}
