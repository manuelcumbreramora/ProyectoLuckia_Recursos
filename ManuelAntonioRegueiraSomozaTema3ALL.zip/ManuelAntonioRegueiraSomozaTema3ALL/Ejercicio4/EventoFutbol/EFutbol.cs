﻿using InterfaceEventos;
using InterfaceSistemaCentral;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventoFutbol
{
    public class EFutbol : IEvento
    {
        private DateTime Fecha;
        private String Nombre;
        private String Equipo1;
        private String Equipo2;
        private int Resultado;

        public EFutbol(String nombreE,String equipo1,String equipo2)
        {
            Fecha = DateTime.Now;
            Nombre = nombreE;
            Equipo1 = equipo1;
            Equipo2 = equipo2;
            Resultado = 3;
        }

        public int GetResultado()
        {
            return this.Resultado;
        }

        public void JugarEvento()
        {
            Random random = new Random();
            int numAleatorio = random.Next(0, 2);
           
            Console.ReadLine();
            if (numAleatorio == 1)
            {
                this.Resultado = 1;
                Console.WriteLine("Gano Equipo1 {0} ", this.Equipo1);
            }
            else if(numAleatorio == 2)
            {
                this.Resultado = 2;
                Console.WriteLine("Gano Equipo2 {0} ", this.Equipo2);

            }else if (numAleatorio == 0)
            {
                this.Resultado = 0;
                Console.WriteLine("Empate  ");
            }


        }

        public void MostrarEvento()
        {
            Console.WriteLine("Nombre: {0} ", this.Nombre);
            Console.WriteLine("Fecha: {0} ", this.Fecha);
            Console.WriteLine("Equipo1: {0} ", this.Equipo1);
            Console.WriteLine("Equipo2: {0} ", this.Equipo2);

            if (this.Resultado == 0)
            {
                Console.WriteLine("Resultado Actual : Empate ");

            }else if (this.Resultado == 1)
            {
                Console.WriteLine("Resultado Actual : Ganador {0} ", this.Equipo1);
            }else if (this.Resultado == 2)
            {
                Console.WriteLine("Resultado Actual : Ganador {0} ", this.Equipo2);
            }else if (this.Resultado == 3)
            {
                Console.WriteLine("Resultado Actual : No jugado");
            }


        }

    
    }
}
