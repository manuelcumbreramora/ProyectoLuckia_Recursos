﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace Tema2_Servicio
{
    public partial class Service1 : ServiceBase
    {
        public Service1()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            Process process = new Process();
            process.StartInfo.FileName = "cmd.exe";
            process.StartInfo.UseShellExecute = true;
            process.StartInfo.RedirectStandardInput = true;
            process.StartInfo.RedirectStandardOutput = true;
            process.StartInfo.UseShellExecute = false;
            process.Start();
            process.StandardInput.Write("copy C:\\Users\\david.crespopardo\\carpetaLocal1\\c1 C:\\Users\\david.crespopardo\\carpetaLocal2");
            process.StandardInput.Flush();
            process.StandardInput.Close();
            process.WaitForExit();


        }

        protected override void OnStop()
        {
        }
    }
}
