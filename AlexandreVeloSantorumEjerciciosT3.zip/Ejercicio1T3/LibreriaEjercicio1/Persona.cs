﻿using System;

namespace PersonaClase
{
    public class Persona
    {

        public string Nombre { get; set; }
        public int Edad { get; set; }
        public bool Suscripcion { get; set; }

        

        public void realizarSuscripcion(string nombre, int edad)
        {
            Nombre = nombre;
            Edad = edad;
            Suscripcion = true;
            Console.WriteLine("Suscripción realizada");
        }
    }
}
