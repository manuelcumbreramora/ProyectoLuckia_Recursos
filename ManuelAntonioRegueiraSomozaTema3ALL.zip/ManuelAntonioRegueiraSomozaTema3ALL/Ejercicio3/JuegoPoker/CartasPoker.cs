﻿using JuegoCartas;
using OperacionesGeneracionAleatorias;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JuegoPoker
{
    public class CartasPoker:Cartas
    {
        private int ApuestaMaxMesa;//cantidad maxima de apuesta por ronda
 
        public CartasPoker(int numCartas, int apuestaMaxMesa,string nombreJuego)
        {
            NumeroCartas = numCartas;
            ApuestaMaxMesa = apuestaMaxMesa;
            NombreJuego = nombreJuego;
        }

        public void MostrarDetallesDatosJuego()
        {
            this.MostrarDatosJuego();
            Console.WriteLine("Maximo de apuesta en mesa {0}", this.ApuestaMaxMesa);
        }
    }
}
