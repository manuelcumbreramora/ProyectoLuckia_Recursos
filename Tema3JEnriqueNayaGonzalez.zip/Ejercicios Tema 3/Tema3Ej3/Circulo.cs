﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3Ej3
{
    class Circulo:FiguraGeometrica
    {
        public Circulo(int radio)
        {
            this.radio = radio;
        }

        public int radio { get; set; }

        public override double obtenerArea(int radio)
        {
            return base.obtenerArea(radio)*Math.PI;
        }
    }
}
