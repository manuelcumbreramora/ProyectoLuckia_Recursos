﻿using System;
using System.Collections.Generic;
using System.Text;
using CasinoInterfaz;

namespace CasinoMonedaClase
{
    class CasinoMoneda : ICasino
    {
        public string resolverCasino()
        {
            Random ne = new Random();
            return ne.Next(1, 2).ToString();
        }

        public int jugar(string apuestaUsuario, string cantidad)
        {
            string resultado = resolverCasino();
            Console.WriteLine("La cara de la moneda correcta es " + resultado);
            if (apuestaUsuario == resultado)
            {
                Console.WriteLine("Has acertado tú apuesta en la moneda");
                return Int32.Parse(cantidad) * 2;
            }
            else
            {
                return -Int32.Parse(cantidad);
            }
        }
    }
}
