﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ej4tema3
{
    class ApuestaFutbol : Apuesta
    {
        ResultadoFutbol ResultadoApuesta;
        public ApuestaFutbol(int importe, IEvento evento, ResultadoFutbol resultadoApostado, Jugador jugador) : base(importe, evento, jugador)
        {
            this.ResultadoApuesta = resultadoApostado;
        }

        public override int CalcularPuntosGanados()
        {
            Resultado resultadoEvento = Evento.ObtenerResultado();

            if (!(resultadoEvento is null))
            {
                // No hay resultado todavía.
                return 0;
            }
            else
            {
                int tipoAcierto = ResultadoApuesta.Comparar(resultadoEvento);

                //0: sin aciertos 1: acierto resultado 2: acierta quiniela, 3: acierta quiniela y resultado
                switch (tipoAcierto)
                {
                    case 0:
                        return 0;
                    case 1:
                        return 300;
                    case 2:
                        return 200;
                    case 3:
                        // Ha acertado resultado y quiniela. Asumo que el premio es 300 
                        // como si acertase el resultado, ya que es el premio más alto.
                        return 300;
                    default:
                        throw new Exception("Valor desconocido");
                }
            }
        }
    }
}
