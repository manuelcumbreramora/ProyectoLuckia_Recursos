﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PointsCalculator
{
    interface IPointsCalculator
    {
        // Calculates the points assigned to the user from the bet results.
        // If there is an error while parsing the input parameters, this method will return a negative number.
        float calculatePoints(params string[] args);
    }
}
