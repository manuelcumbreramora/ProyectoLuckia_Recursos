﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.IO;
using System.Net.Http;

namespace Consola
{
    public class TareaViewModel
    {
        public TareaViewModel()
        {
        }

        public int Id { get; set; }
        public string NombreUsuario { get; set; }
        public string Title { get; set; }

        EnvironmentVariableTarget usuarios;

        public List<Consola.Tarea> TareasViewModel { get; set; }

        public async Task escribirTareas(usuarios)
        {
        Console.WriteLine("Inicio transformación ViewModels");
        List < TareaViewModel > tvm = new List<TareaViewModel>();

        foreach (var tarea in tvm)
        {
                var tareaViewModel = new TareaViewModel()
                {
                    Id = tarea.Id,
                    Title = tarea.Title.Trim(),
                    NombreUsuario = usuarios.Where(x => x.Id == tarea.UserId).First().Nombre.Trim()
                };
                tvm.Add(tareaViewModel);
        }

        Console.WriteLine("Inicio escritura de tareas en archivo");
        using (StreamWriter writetext = new StreamWriter($@"{Directory.GetCurrentDirectory()}\tareas pendientes.txt"));
        }







    }


    
                
}
