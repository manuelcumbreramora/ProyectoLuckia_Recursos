﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_Pago
{
    public abstract class CalculoDineroFinal
    {
        public int multiplicador { get; set; }
        public double dineroFinal { get; set; }
        public CalculoDineroFinal()
        {

        }
        public CalculoDineroFinal(int multi, int divisor, double pointsTotal, double finalCash)
        {
            this.multiplicador = multi;
            this.dineroFinal = finalCash;
        }
        public abstract double calculo(int puntos, int divisor);
        public abstract void sumaPuntos(double pointsFut, double pointsRace, double pointsAtle);
        public abstract void dineroGanado();
    }
}
