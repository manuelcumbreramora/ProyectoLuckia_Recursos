﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cata
{
    public interface IEvento
    {
        int resolverEvento();
        void registrarResultadoFinal(int _resultado);
        int devolverResultadFinal();
        string devolverNombreEvento();
    }
}
