﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bets
{
    public abstract class AbstractBet : IBet
    {
        public enum BetGame { Roulette = 0, TexasPoker = 10 }

        public BetGame Game;

        public string[] Bet { get; }

        public float Amount { get; }

        public AbstractBet(BetGame game, string[] bet, float amount)
        {
            this.Game = game;
            this.Bet = bet;
            this.Amount = amount;
        }

        public BetGame GetGame()
        {
            return this.Game;
        }

        public string[] GetBet()
        {
            return this.Bet;
        }

        public float GetAmount()
        {
            return this.Amount;
        }
    }
}
