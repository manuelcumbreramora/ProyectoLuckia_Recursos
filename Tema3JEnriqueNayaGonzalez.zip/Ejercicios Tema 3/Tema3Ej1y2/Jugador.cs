﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3Ej1
{
    class Jugador:Persona
    {
        public int bonus { get; set; }
        public int juegos { get; set; }
        public double monedero { get; set; }
        public override string ToString()
        {
            return "Jugador: "+this.nombre+", saldo disponible: "+this.monedero;
        }
        public void apostar()
        {
            Console.WriteLine("Desea realizar alguna apuesta?(S/N)");
            if (!(Console.ReadLine().ToUpper() == "S"))
            {
                Console.WriteLine("De acuerdo, hasta la próxima!");
            }
            else
            {
                juegos++;
                Random random = new Random();
                bonus = random.Next(10, 100);
                String deporte="";
                Console.WriteLine("Seleccione el deporte al que quiera jugar: \n1-Futbol \n2-Balonmano \n3-Boleibol");
                int opcion =int.Parse(Console.ReadLine());
                switch (opcion)
                {
                    case 1:
                        Console.WriteLine("Ha seleccionado usted: Futbol");
                        deporte = "Futbol";
                        break;
                    case 2:
                        Console.WriteLine("Ha seleccionado usted: Balonmano");
                        deporte = "Balonmano";
                        break;
                    case 3:
                        Console.WriteLine("Ha seleccionado usted: Boleibol");
                        deporte = "Boleibol";
                        break;
                    default:
                        Console.WriteLine("El juego seleccionado no existe");
                        break;
                }
                Juego juego = new Juego(deporte);
                if (deporte != "") {                 
                    int apuesta = random.Next(1, 4);
                    switch (apuesta)
                    {
                        case 1:
                            Console.WriteLine("Enhorabuena, ha acertado usted la apuesta! Además ha recibido un bonus de:" + bonus);
                            this.monedero = this.monedero + bonus;
                            Console.WriteLine(this.ToString());
                            break;
                        case 2:
                            Console.WriteLine("Lo sentimos, ha perdido usted la apuesta");
                            this.monedero = this.monedero - bonus;
                            Console.WriteLine(this.ToString());
                            break;
                        case 3:
                            Console.WriteLine("Hemos detectado prácticas incorrectas, por lo que se le aplicará una penalización");
                            this.penalizar(juego, this);
                            Console.WriteLine(this.ToString());
                            break;
                        default:
                            break;
                    }
                    apostar();
                }
            }
        }

    }
}
