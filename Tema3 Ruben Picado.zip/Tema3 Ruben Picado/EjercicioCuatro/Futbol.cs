﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioCuatro
{
    class Futbol : IPuntuacion
    {
        public int puntos { get; set; }
        public int puntosf { get; set; }

        public  override int CalculoPuntos(Jugador jugador, int importeApostado)
        {
            Console.WriteLine("Apostando al futbol");
            Random randomf = new Random();
            puntosf= randomf.Next(1, 3);
            switch (puntosf)
            {
                case 1:
                    puntos = importeApostado + 300;
                    Console.WriteLine("El jugador ha ganado 300 puntos");
                    break;
                case 2:
                    puntos = importeApostado + 200;
                    Console.WriteLine(" El jugador falla en la apuesta pero gana  la quiniela");
                    break;
                case 3:
                    puntos = 0;
                    Console.WriteLine("El jugador ha perdido");
                    break;

            }
            Console.WriteLine(" El jugador gana " + puntos*15 + " euros");
                return puntos * 15;
        }


    }
}

          