﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio2
{
    public class Monedero
    {
        private int saldo { get; set; }

        public Monedero()
        {
            this.saldo = 0;
        }

        public Monedero(int saldo)
        {
            this.saldo = saldo;
        }

        public void quitaSaldo(int cant)
        {
            this.saldo -= cant;
        }
        public int compruebaSaldo()
        {
            return this.saldo;
        }
    }
}
