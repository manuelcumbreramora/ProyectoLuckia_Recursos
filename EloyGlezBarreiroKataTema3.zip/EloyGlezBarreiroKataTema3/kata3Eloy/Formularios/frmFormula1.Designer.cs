﻿namespace kata3Eloy.Formularios
{
    partial class frmFormula1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmFormula1));
            this.panel2 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblF1Espana = new System.Windows.Forms.Label();
            this.lblF1Mundial = new System.Windows.Forms.Label();
            this.pbvuelta = new System.Windows.Forms.PictureBox();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbvuelta)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel2.Controls.Add(this.label4);
            this.panel2.Location = new System.Drawing.Point(12, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(414, 40);
            this.panel2.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Impact", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(154, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(112, 35);
            this.label4.TabIndex = 0;
            this.label4.Text = "Eventos";
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel1.Location = new System.Drawing.Point(461, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(105, 100);
            this.panel1.TabIndex = 7;
            // 
            // lblF1Espana
            // 
            this.lblF1Espana.AutoSize = true;
            this.lblF1Espana.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblF1Espana.Font = new System.Drawing.Font("Comic Sans MS", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblF1Espana.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lblF1Espana.Location = new System.Drawing.Point(8, 112);
            this.lblF1Espana.Name = "lblF1Espana";
            this.lblF1Espana.Size = new System.Drawing.Size(341, 19);
            this.lblF1Espana.TabIndex = 9;
            this.lblF1Espana.Text = "•  Apuestas Gran Premio de España de F1 2020";
            // 
            // lblF1Mundial
            // 
            this.lblF1Mundial.AutoSize = true;
            this.lblF1Mundial.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblF1Mundial.Font = new System.Drawing.Font("Comic Sans MS", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblF1Mundial.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lblF1Mundial.Location = new System.Drawing.Point(12, 194);
            this.lblF1Mundial.Name = "lblF1Mundial";
            this.lblF1Mundial.Size = new System.Drawing.Size(285, 19);
            this.lblF1Mundial.TabIndex = 10;
            this.lblF1Mundial.Text = "•  Apuestas Mundial 2017 de Fórmula 1";
            // 
            // pbvuelta
            // 
            this.pbvuelta.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbvuelta.Image = ((System.Drawing.Image)(resources.GetObject("pbvuelta.Image")));
            this.pbvuelta.Location = new System.Drawing.Point(516, 225);
            this.pbvuelta.Name = "pbvuelta";
            this.pbvuelta.Size = new System.Drawing.Size(50, 43);
            this.pbvuelta.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbvuelta.TabIndex = 11;
            this.pbvuelta.TabStop = false;
            this.pbvuelta.Click += new System.EventHandler(this.pbvuelta_Click);
            // 
            // frmFormula1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(578, 280);
            this.Controls.Add(this.pbvuelta);
            this.Controls.Add(this.lblF1Mundial);
            this.Controls.Add(this.lblF1Espana);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.MaximumSize = new System.Drawing.Size(596, 327);
            this.MinimumSize = new System.Drawing.Size(596, 327);
            this.Name = "frmFormula1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Apuestas Formula1";
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbvuelta)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblF1Espana;
        private System.Windows.Forms.Label lblF1Mundial;
        private System.Windows.Forms.PictureBox pbvuelta;
    }
}