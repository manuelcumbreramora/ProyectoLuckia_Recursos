﻿//BreoBeceiro:23/03/2020
//PLEXUS | Tema3

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ej2
{
    public class Persona
    {
        public string nombre { get; set; }
        public string apellidos { get; set; }
        private string usuario { get; set; }
        private string password { get; set; }

        //Constructor vacío (al estilo de Visual Basic, en C# también se pone):
        public Persona() { }

        public Persona(string name, string surname, string user)
        {
            nombre = name;
            apellidos= surname;
            usuario = user;
        }

    }
}
