﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimuladorCarreras
{
    class CarreraPorTramos : Competicion
    {
        public HashSet<CarreraSencilla> Tramos { get; set; }


        public CarreraPorTramos(HashSet<CarreraSencilla> tramos)
        {
            this.Tramos = tramos;
        }

        public override void MostrarResultado()
        {
            foreach(CarreraSencilla carrera in Tramos){
                carrera.MostrarResultado();
            }
        }

        public override void SimularCompeticion()
        {
            foreach (CarreraSencilla carrera in Tramos){
                carrera.SimularCompeticion();
            }
        }
    }
}
