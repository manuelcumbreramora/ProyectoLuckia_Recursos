﻿using System;
using System.Collections.Generic;
using ClasesEstaticas;
using Interfaces;

namespace Herencia
{
    public class HerenciaClass : Interfaz
    {
        public static int aforoMaximo = 100;

        public void generarDesastreNatural(int numeroAleatorio)
        {
            if (numeroAleatorio <= 20)
            {
                Console.WriteLine("Cae un diluvio, la gente empieza a no estar comoda...");
                aforoMaximo = aforoMaximo - numeroAleatorio;
            }
            else if(numeroAleatorio > 20 && numeroAleatorio <= 40)
            {
                Console.WriteLine("El terremoto azota el lugar, que alguien se intente salvar!!!.");
                aforoMaximo = aforoMaximo - numeroAleatorio;
            }
            else if (numeroAleatorio > 40 && numeroAleatorio <= 80)
            {
                Console.WriteLine("Vientos, tormentas y truenos. Corred insensatos!!!.");
                aforoMaximo = aforoMaximo - numeroAleatorio;
            }else if (numeroAleatorio > 80)
            {
                Console.WriteLine("Maremotoooooooooooo!!!.");
                aforoMaximo = aforoMaximo - numeroAleatorio;
            }else {
                Console.WriteLine("Has tenido mucha suerte y hoy todo esta tranquilo.");
                aforoMaximo = aforoMaximo - numeroAleatorio;
            }
        }

        public void pedirRefuerzos()
        {
            aforoMaximo = aforoMaximo + StaticClass.refuerzos;
            Console.WriteLine("Se han solicitado refuerzos actualmente somos " + aforoMaximo);
        }
    }
}
