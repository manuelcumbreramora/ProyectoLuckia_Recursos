﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimuladorCarreras
{
    abstract class Competicion
    {
        protected HashSet<IParticipante> Participantes=new HashSet<IParticipante>();

        // Si no tiene virtual puede dar problemas.
        public virtual void ApuntarParticipante(IParticipante p)
        {
            Participantes.Add(p);
        }

        public String Nombre { get; set; }

        public abstract void SimularCompeticion();

        public abstract void MostrarResultado();
    }
}
