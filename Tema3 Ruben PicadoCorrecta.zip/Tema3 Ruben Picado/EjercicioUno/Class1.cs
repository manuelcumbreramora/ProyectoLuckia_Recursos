﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioUno
{
    class Persona
    {
        public string nombre { get; set; }

        public int edad { get; set; }

        public string jugador { get; set; }

        public void realizarSubscripcion(String nombre, int edad, Jugador jugador)
        {
           
        }
    }
    class Jugador : Persona
    {
        private int bonus { get; set; }

        private int juegos { get; set; }
        public void jugador(Jugador jugador)
        {

        }
        public void inicio(Jugador jugador)
        {
            Console.WriteLine("Introduzca el nombre  de inicio: ");
            String nombre = Console.ReadLine();
            Console.WriteLine("Introduzca su edad: ");
            int edad = int.Parse(Console.ReadLine());
            jugador.realizarSubscripcion(nombre, edad, jugador);
            jugador.juegos = 0;
            string apuesta = "";
            while (apuesta != "f")
            {
      
                {
                    Console.WriteLine("Pulse cualquier telca para empezar ");
                    apuesta = Console.ReadLine();
                    apostar();
                    var random = new Random();
                    if (random.Next(0, 50) > 45)
                    {
                        Console.WriteLine("ganas");
                    }else
                    {
                        Console.WriteLine("pierdes!");
                    }
                    Console.WriteLine("Llevas " + jugador.juegos + " juegos, " + jugador.nombre + ".");
                }
            }
        }
        public void apostar()
        {
            var random = new Random();
            juegos++;
            bonus = random.Next(0, 50);
        }

    }

    
}
