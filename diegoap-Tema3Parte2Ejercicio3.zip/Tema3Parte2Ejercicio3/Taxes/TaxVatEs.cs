﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taxes
{
    public class TaxVatEs : AbstractTax
    {
        public TaxVatEs() : base("VAT", "ES", "Impuesto sobre el Valor Añadido") { }

        public override float calculateTax(float amount)
        {
            return amount * 0.21f;
        }
    }
}
