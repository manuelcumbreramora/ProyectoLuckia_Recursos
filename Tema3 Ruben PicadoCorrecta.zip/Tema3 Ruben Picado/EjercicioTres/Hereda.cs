﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioDosU
{
    public class Hereda : IPosicion
    {
        private int num = 0;
        public Hereda()
        {

        }
        public void PosicionCampo(int num)
        {
            if (num == 1)
            {
                Console.WriteLine("Es portero");
            }
            else if (num <=2 | num <= 4)
            {
                Console.WriteLine("Es defensa");
            }
            else if (num >=4 | num <= 9)
            {
                Console.WriteLine("Es mediocampista");
            }
            else if (num >=9 | num <= 11)
            {
                Console.WriteLine("Es delantero");
            }
        }
       
    }
}
