﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioCuatro
{
    public class Jugador
    {
        public string nombre { get; set; }
        public int monedero { get; set; }

        public Jugador()
        {
            this.nombre = nombre;
            this.monedero = monedero;
        }

        public List<Apuesta> GenerarApuestas()
        {
            List<Apuesta> apuestas = new List<Apuesta>();
            Apuesta miapuesta1 = new Apuesta();
            Apuesta miapuesta2 = new Apuesta(); 
            Apuesta miapuesta3 = new Apuesta();

            miapuesta1.evento = 1;
            miapuesta1.importeApostado = 100;

            miapuesta2.evento = 2;
            miapuesta2.importeApostado = 200;

            miapuesta3.evento = 3;
            miapuesta3.importeApostado = 300;

            apuestas.Add(miapuesta1);
            apuestas.Add(miapuesta2);
            apuestas.Add(miapuesta3);
            return apuestas;
        }
    }
}
