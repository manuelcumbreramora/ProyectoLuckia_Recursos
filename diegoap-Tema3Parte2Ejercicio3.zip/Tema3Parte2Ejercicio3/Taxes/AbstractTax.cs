﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taxes
{
    public abstract class AbstractTax : ITax
    {
        public string id { get; set; }
        public string countryCode { get; }

        // A short description.
        public string desc { get; }

        public AbstractTax(string id, string countryCode, string desc)
        {
            this.id = id;
            this.countryCode = countryCode;
            this.desc = desc;
        }

        public abstract float calculateTax(float amount);
    }
}
