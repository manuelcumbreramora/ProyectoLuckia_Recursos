﻿using PTarea;
using PTareaViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRepositorioTareaViewModel
{
    public class RepositorioTareaViewModel //en esta clase se guardan las TareaViewModel
    {
        public List<TareaViewModel> DatosTVM;

        public RepositorioTareaViewModel()
        {
            DatosTVM = new List<TareaViewModel>();
        }
        public void InsertaTareaViewModel(int id, String nombreUsuario, String title)
        {
            
            TareaViewModel tareaTVM = new TareaViewModel(id, nombreUsuario, title);
            this.DatosTVM.Add(tareaTVM);
        }

    }
}

/*
 * 
 public class TareaViewModel
    {
        public int Id { get; set; }
        public string NombreUsuario { get; set; }
        public string Title { get; set; }
    }
 */
