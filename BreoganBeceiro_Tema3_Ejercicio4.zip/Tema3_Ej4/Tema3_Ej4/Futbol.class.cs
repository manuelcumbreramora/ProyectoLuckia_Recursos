﻿//BreoBeceiro: 24/03/2020
//PLEXUS | Tema3

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ej4
{
    public class Futbol
    {
        public IPuntosJugador puntos { get; set; }


        public bool comprobarQuiniela()
        {
            return Convert.ToBoolean(new Random().Next(0, 2));
        }

        public bool comprobarResultado()
        {
            return Convert.ToBoolean(new Random().Next(0, 2));
        }

        /// <summary>
        /// Recibe los fallos o aciertos del jugador en el partido y la quiniela como valores lógicos.
        /// </summary>
        /// <param name="resultadoPartido">El resultado del partido (TRUE si acertó, FALSE si falló).</param>
        /// <param name="resultadoQuiniela">El resultado de la quiniela (TRUE si la acertó, FALSE si la falló).</param>
        /// <returns>Los puntos obtenidos según los resultados o 1, en caso de error.</returns>
        public int obtienePuntos(bool resultadoPartido, bool resultadoQuiniela)
        {
            int puntos;

            if(!resultadoPartido && !resultadoQuiniela)
            {
                puntos = 0;
            }else if(resultadoQuiniela && !resultadoPartido)
            {
                puntos = 200;
            }else if (resultadoPartido)
            {
                puntos = 800;
            }
            else
            {
                puntos = 1;
            }

            return puntos;
        }
    }
}
