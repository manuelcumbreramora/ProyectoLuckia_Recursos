﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ej1tema3._4
{
    class Persona
    {
        private readonly String Nombre;

        private UInt16 Edad;

        public Persona(String nombre, UInt16 edad)
        {
            this.Nombre = nombre;
            this.Edad = edad;
        }

        public Jugador RealizarSubscripcion()
        {
            return new Jugador(this.Nombre, this.Edad);
        }
    }
}
