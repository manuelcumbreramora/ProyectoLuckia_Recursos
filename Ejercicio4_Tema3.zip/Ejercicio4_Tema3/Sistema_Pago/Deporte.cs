﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_Pago
{
    public abstract class Deporte
    {
        public string nombre { get; set; }
        public Deporte() { }
        public Deporte(string nom, int puntos)
        {
            this.nombre = nom;
        }
    }
}
