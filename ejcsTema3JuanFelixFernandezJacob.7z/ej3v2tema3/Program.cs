﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ej3v2tema3
{
    class Program
    {
        static void Main(string[] args)
        {

            // Código de ejemplo:
            Almacen almacen = new Almacen();

            List<Producto> productos = new List<Producto>();

            productos.Add(new Libro("Felipe", "Mi madre", DateTime.Parse("1/1/2000"), "Terror", 20, 200));
            productos.Add(new Libro("José", "Mi madre", DateTime.Parse("1/1/2001"), "Terror", 20, 199));
            productos.Add(new Libro("Felipe", "Mi madre", DateTime.Parse("1/1/2002"), "Terror", 20, 198));
            productos.Add(new Libro("Amaral", "Mis colegas", DateTime.Parse("1/1/2005"), "Terror", 20, 100));
            productos.Add(new Libro("Mama Ladilla", "Mi madre", DateTime.Parse("1/1/2090"), "Terror", 20, 200));
            productos.Add(new Libro("Felipe", "Mi madre", DateTime.Parse("1/1/2000"), "Terror", 20, 200));
            productos.Add(new Disco("Perico Pérez", "La Regenta", DateTime.Parse("1/1/2000"), "Rock Punk", 10));
            productos.Add(new Disco("Cervantes", "Sinfonías locas", DateTime.Parse("1/1/2000"), "Rock Punk", 10));
            productos.Add(new Disco("José Perro", "Sinfonías locas", DateTime.Parse("1/1/2000"), "Rock Punk", 10));
            productos.Add(new Disco("José Perro", "El perro del vecino", DateTime.Parse("1/1/2000"), "Rock Punk", 10));
            productos.Add(new Disco("José Perro", "Sinfonías locas, décima parte", DateTime.Parse("1/1/2000"), "Rock Punk", 10));

            almacen.Productos = productos;

            almacen.EscribirInformacion(new SerializadorXML());

            almacen.EscribirInformacion(new SerializadorJson());
        }
    }
}
