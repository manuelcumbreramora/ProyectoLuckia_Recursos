﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ejercicio2
{
    class Persona
    {
        public Persona(string nombre, int edad)
        {
            this.nombre = nombre;
            this.edad = edad;
        }

        public Persona()
        {
        }

        public String nombre { get; set; }
        public int edad { get; set; }


        public void realizarSuscripcion()
        {
            Console.WriteLine("Introduzca su nombre");
            nombre = Console.ReadLine();
            Console.WriteLine("Introduzca su edad");
            edad = Int16.Parse(Console.ReadLine());
        }

    }
}
