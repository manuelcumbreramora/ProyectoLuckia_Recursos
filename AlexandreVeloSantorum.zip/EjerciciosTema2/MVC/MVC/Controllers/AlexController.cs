﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVC.Controllers
{
    public class AlexController : Controller
    {
        // GET: Alex
        public ActionResult HolaMundo()
        {
            ViewBag.Message = "Your application description page.";
            return View();
        }

    }
}
