﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PEventos
{
    public class EventoFutbol:IEventos
    {
        private String Nombre;
        private String Equipo1;
        private String Equipo2;
        private DateTime Fecha;
        private int ResultadoFinal;// 0 sin jugar, 2 gana equipo 2, 1 gana equipo 1, 3 empate

        public EventoFutbol(String nombre, String equipo1, String equipo2)
        {
            Nombre = nombre;
            Equipo1 = equipo1;
            Equipo2 = equipo2;
            ResultadoFinal = 0;
            Fecha = DateTime.Now;
        }

        public int DevolverResultadoFinal()
        {
            return this.ResultadoFinal;
        }

        public void MostrarEvento()
        {
            Console.WriteLine("Tipo de evento: {0}", this.GetType());
            Console.WriteLine("Nombre: {0} ", this.Nombre);
            Console.WriteLine("Fecha: {0} ", this.Fecha);
            Console.WriteLine("Equipo1: {0} ", this.Equipo1);
            Console.WriteLine("Equipo2: {0} ", this.Equipo2);

            if (this.ResultadoFinal == 3)
            {
                Console.WriteLine("Resultado Actual : Empate ");

            }
            else if (this.ResultadoFinal == 1)
            {
                Console.WriteLine("Resultado Actual : Ganador {0} ", this.Equipo1);
            }
            else if (this.ResultadoFinal == 2)
            {
                Console.WriteLine("Resultado Actual : Ganador {0} ", this.Equipo2);
            }
            else if (this.ResultadoFinal == 0)
            {
                Console.WriteLine("Resultado Actual : No jugado");
            }
        }


        public void ResolverEvento()
        {
            Random random = new Random();
            int numAleatorio = random.Next(1, 3);

            Console.ReadLine();
            if (numAleatorio == 1)
            {
                this.ResultadoFinal = 1;
                Console.WriteLine("Gano Equipo1 {0} ", this.Equipo1);
            }
            else if (numAleatorio == 2)
            {
                this.ResultadoFinal = 2;
                Console.WriteLine("Gano Equipo2 {0} ", this.Equipo2);

            }
            else if (numAleatorio == 3)
            {
                this.ResultadoFinal = 3;
                Console.WriteLine("Empate  ");
            }

        }
        public string GetNombre()
        {
            return this.Nombre;
        }
    }
}
