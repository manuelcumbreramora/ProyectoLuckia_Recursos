﻿using Core;
using JuegoBalonmano;
using JuegoBoleibol;
using JuegoFutbol;
using JuegoJuego;
using JuegoPersona;
using PenalizacionJuego;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3Ejercicio2
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Persona jugador = new Persona(18, "Eduardo", 25); //las personas son jugadores con atributo edad, nombre y monedero
            JFutbol juegoFutbol = new JFutbol("Partido Champions Futbol", "Real Madrid", "Deportivo de la coruña"); // los juegos se diferencian e la penalización(se asigna valor en el constructor), y tienen nombre, equipo1, equipo2 
            JBalonmano juegoBalomano = new JBalonmano("Partido Copa Balonmano", " BL valencia", "BL Barcelona");
            JVoleibol juegoVoleibol = new JVoleibol("Partido Campeonato Sanxenxo Voleibol", " VB Ribeira", "VB Pontevedra");
            Console.WriteLine("MOSTRAMOS JUGADOR");
            Console.WriteLine("*********************************** ");
            jugador.mostrarPersona();
            Console.WriteLine("                  ");
            Console.WriteLine("MOSTRAMOS JUEGOS");
            Console.WriteLine("*********************************** ");
            juegoFutbol.mostrarJuego();
            Console.WriteLine("                  ");
            juegoBalomano.mostrarJuego();
            Console.WriteLine("                  ");
            juegoVoleibol.mostrarJuego();
            Console.WriteLine("                  ");
            // Console.WriteLine("Seleccionamos (1 o 2) para seleccionar como ganador equipo 1 o equipo 2 al llamar al metodo jugar");
            Console.WriteLine("SE JUEGAN LOS PARTIDOS");
            Console.WriteLine("*********************************** ");
            juegoFutbol.Jugar(1); //se juega un partido entre los 2 equipos y seleccionarmos el ganador
            juegoBalomano.Jugar(2);
            juegoVoleibol.Jugar(1);
            
            juegoFutbol.mostrarJuego();
            Console.WriteLine("                  ");
            juegoBalomano.mostrarJuego();
            Console.WriteLine("                  ");
            juegoVoleibol.mostrarJuego();
            Console.WriteLine("                  ");
            CorePenalizacion penalizacion1 = new CorePenalizacion();//todas las penealizaciones llevaran una fecha, jugador y juego donde se aplica
            CorePenalizacion penalizacion2 = new CorePenalizacion();
            CorePenalizacion penalizacion3 = new CorePenalizacion();

            Console.WriteLine("SE APLICAN PENALIZADORES ");
            Console.WriteLine("*********************************** ");
            penalizacion1.PenalizarPersonaJuego(jugador, juegoFutbol);// se penaliza al jugador por un partido(del tipo que sea) y se guarda la fecha,penalización aplicada, jugador y juego
            penalizacion2.PenalizarPersonaJuego(jugador, juegoBalomano);
            penalizacion3.PenalizarPersonaJuego(jugador, juegoVoleibol);
            Console.WriteLine("                  ");
            penalizacion1.mostrarPenalizacion();
            Console.WriteLine("                  ");
            penalizacion2.mostrarPenalizacion();
            Console.WriteLine("                  ");
            penalizacion3.mostrarPenalizacion();
            Console.WriteLine("                  ");
            Console.WriteLine("SE MUESTRA JUGADOR TRAS PENALIZADOR");
            Console.WriteLine("*********************************** ");
            Console.WriteLine("                  ");
            jugador.mostrarPersona();

            Console.ReadLine();







        }
    }
}
