﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Tareas;
using Usuarios;

namespace Consola   
{
    public class ProcesadorTareas
    {
        public void toFile()
        {
            Console.WriteLine("Inicio escritura de tareas en archivo");
            using (StreamWriter writetext = new StreamWriter($@"{Directory.GetCurrentDirectory()}\tareas pendientes.txt")) ;
        }

        
        internal async Task Procesar()
        {
            try{



                Console.WriteLine("Inicio de procesamiento");

                var client = new HttpClient();
                Tarea tarea = new Tarea();
                var tareasNoRealizadas = await tarea.procesarAsync(client);
                Usuario usuario = new Usuario();
                var usuarios = await usuario.procesarAsync(client);
                TareaViewModel tareaViewModel1 = new TareaViewModel();
                tareaViewModel1.EscribirTareas(tareasNoRealizadas, usuarios);
               
                Console.WriteLine("Inicio transformación ViewModels");

                toFile();
                
                Console.ReadKey();
            }catch (IOException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    }

}
