﻿using System;

namespace Polimorfismo
{
    public class PolimorfismoClass
    {
        public void meotodoPolimorfista(int aforo)
        {
            if (aforo >= 100)
            {
                Console.WriteLine("Estamos a tope!");
            }
            else if (aforo < 99 && aforo >= 50)
            {
                Console.WriteLine("Hemos sufrido bajas...pero seguimos en pie.");
            }
            else if (aforo < 50 && aforo >= 1)
            {
                Console.WriteLine("Estamos a mínimos...pide refuerzos!!!.");
            }
            else
            {
                Console.WriteLine("No queda nadie a quien salvar...has perdido.");
            }
        }

    }
}
