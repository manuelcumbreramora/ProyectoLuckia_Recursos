﻿using System;
using System.Collections.Generic;

namespace Base
{
    public class Jugador : HistorialApuestas
    {

        public int evento { get; set; }

        public Monedero monedero { get; set; }

    }
}
