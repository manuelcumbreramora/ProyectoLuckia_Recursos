﻿using System;
using System.Collections.Generic;
using System.Text;
using InterfaceEvento;

namespace CarrerasClase
{
    class Carreras : IEvento
    {
        public string generarApuestaCorrecta()
        {
            return "Jorge Lorenzo";
        }

        public int generarPuntos()
        {
            string apuestaUsuario = generarApuestaUsuario();
            string apuestaCorrecta = generarApuestaCorrecta();
            if(apuestaUsuario == apuestaCorrecta)
            {
                Random rn = new Random();
                return rn.Next(300) / 10;
            }
            else
            {
                return 0;
            }
        }

        public string generarApuestaUsuario()
        {
            string[] apuestas = new string[] { "", "Jorge Lorenzo", "Marc Marquez", "Dani Pedrosa" };
            int opcion = 0;
            while (opcion != 1 && opcion != 2 && opcion != 3)
            {
                Console.WriteLine("Apuesta Carreras:");
                Console.WriteLine("1. Jorge Lorenzo");
                Console.WriteLine("2. Marc Marquez");
                Console.WriteLine("3. Dani Pedrosa");
                Console.WriteLine("Elige una opción:");
                opcion = Int32.Parse(Console.ReadLine());
            }
            return apuestas[opcion];
        }
    }
}
