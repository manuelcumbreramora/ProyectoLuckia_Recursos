﻿using System;
using System.Collections.Generic;

namespace Eventos
{
    public class EventoClass
    {
        private Dictionary<int, string> eventos = new Dictionary<int, string>();

        public int eventoSeleccionado { get; set; }

        public void GenerarEventos()
        {
            eventos.Add(1, "Atletismo");
            eventos.Add(2, "Fútbol");
            eventos.Add(3, "Carreras");
        }

        public void listarEventos()
        {
            Console.WriteLine("Lista de eventos");
            Console.WriteLine("---------------------------");
            foreach (KeyValuePair<int, string> kvp in eventos)
            {
                Console.WriteLine(kvp.Key + ". " + kvp.Value);
            }
            Console.WriteLine("---------------------------");
        }
    }
}
