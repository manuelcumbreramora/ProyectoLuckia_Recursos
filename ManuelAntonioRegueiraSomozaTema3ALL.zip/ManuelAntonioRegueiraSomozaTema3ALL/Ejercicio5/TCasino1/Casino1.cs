﻿using InterfaceCasino;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCasino1
{
    public class Casino1 : ICasino
    {
        private String Nombre;
        public Casino1(String nombre)
        {
            Nombre = nombre;

        }
        public void Jugar()
        {
            Console.WriteLine("Jugando a juego casinoTipo1 {0}",this.Nombre);
        }
    }
}
