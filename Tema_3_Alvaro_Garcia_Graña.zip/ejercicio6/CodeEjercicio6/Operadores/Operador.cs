﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Operadores
{
    public class Operador
    {

        public async Task generarTarea()
        {
            throw new NotImplementedException();
        }

        public async Task generarUsuario()
        {
            throw new NotImplementedException();
        }

        public async Task<string> obtenerCuerpoRespuesta(HttpClient client, string urlTareas)
        {
            var respuestaTareas = await client.GetAsync(urlTareas);
            respuestaTareas.EnsureSuccessStatusCode();
            return await respuestaTareas.Content.ReadAsStringAsync();
            
        }
    }
}
