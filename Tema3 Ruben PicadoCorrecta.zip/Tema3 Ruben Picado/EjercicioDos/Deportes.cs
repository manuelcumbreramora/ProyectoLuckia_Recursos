﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioDos
{
    public class Deportes : Deporte
    {
        int opcion;
        
        public int DeporteFutbol()
        {
            Console.WriteLine("Ha escogido futbol");
            return opcion;
        }

        public int DeporteBalonMano()
        {
            Console.WriteLine("Ha escogido Balonmano");
            return opcion;
        }

        public int DeporteVoleybol()
        {
            Console.WriteLine("Ha escogido Voleybol");
            return opcion;
        }



    }
}
