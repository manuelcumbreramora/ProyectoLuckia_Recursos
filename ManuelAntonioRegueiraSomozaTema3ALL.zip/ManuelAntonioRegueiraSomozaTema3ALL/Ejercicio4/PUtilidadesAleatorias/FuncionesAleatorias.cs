﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PUtilidadesAleatorias
{
    public static class FuncionesAleatorias
    {
        public static int generarAleatorio()
        {
            Random random = new Random();
            int numAleatorio = random.Next(0, 1000);
            Console.WriteLine("Generando aleatorio");
            Console.ReadLine();
            return numAleatorio;
        }
    }
}
