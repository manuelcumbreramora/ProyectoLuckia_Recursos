﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace Ejercicio3
{
    public partial class CopiaService : ServiceBase
    {
        public CopiaService()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            System.Diagnostics.Debugger.Launch();
            string sourcePath = @"C:\Users\Alejandro\Desktop\Carpeta A";
            string targetPath = @"C:\Users\Alejandro\Desktop\Carpeta B";
            string destFile;
            string fileName;
            try{
                Directory.CreateDirectory(targetPath);
                if (Directory.Exists(sourcePath))
                {
                    EventLog.WriteEntry("Se inicio proceso de copiado", EventLogEntryType.Information);
                    string[] files = Directory.GetFiles(sourcePath);

                    foreach (string s in files)
                    {
                        
                        fileName = Path.GetFileName(s);
                        destFile = Path.Combine(targetPath, fileName);
                        File.Copy(s, destFile, true);
                    }
                    EventLog.WriteEntry("Se finalizo el proceso de copiado con exito", EventLogEntryType.Information); 
                }
                else
                {
                    EventLog.WriteEntry("La ruta de origen no existe", EventLogEntryType.Error);
                }
            }catch (IOException ex)
            {
                EventLog.WriteEntry("Error de IO"+ex.Message, EventLogEntryType.Error);
            }
        }

        protected override void OnStop()
        {
            EventLog.WriteEntry("Se paro el proceso de copiado", EventLogEntryType.Information);
        }
        internal void TestStartupAndStop(String[] args)
        {
            this.OnStart(args);
            Console.ReadLine();
            this.OnStop();


        }
    }
}
