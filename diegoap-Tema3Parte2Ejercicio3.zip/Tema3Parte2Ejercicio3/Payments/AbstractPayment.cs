﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaxCalculator;
using Taxes;
using Users;

namespace Payments
{
    public abstract class AbstractPayment : IPaymentTaxes
    {
        public string paymentType { get; }

        public User user { get; }

        public float amount { get; }

        public ITaxCalculator taxCalculator { get; }

        public AbstractPayment(string paymentType, User user, float amount, ITaxCalculator taxCalculator)
        {
            this.paymentType = paymentType;

            this.user = user;
            this.amount = amount;
            this.taxCalculator = taxCalculator;
        }

        public float getAmount()
        {
            return this.amount;
        }

        // Order a bank transfer for paying bettor.
        // Returns the transfered amount.
        public float doBankTransfer()
        {
            float finalAmount = this.calculateFinalAmount();

            this.doTransfer(user.checkingAccount, finalAmount);

            return finalAmount;
        }

        public float calculateFinalAmount()
        {
            float _amount = this.amount;

            float _t;
            foreach (AbstractTax item in this.getAllTaxes())
            {
                _t = item.calculateTax(_amount);
                _amount = _amount - _t;
            }

            return _amount;
        }

        public void doTransfer(string checkingAccount, float amount)
        {
            Console.WriteLine("Transfer to checking account '" + checkingAccount + "' ordered");
        }

        public abstract List<ITax> getAllTaxes();
        public abstract float calculateTotalTaxes();
    }
}
