﻿//BreoBeceiro:24/03/2020
//PLEXUS | Tema3

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ej4
{
    public class Atletismo : IPuntosJugador
    {
        /// <summary>
        /// Calcula los puntos obtenidos por el jugador en base al resultado de sus apuestas en eventos de Atletismo.
        /// </summary>
        /// <param name="points">El resultado de sus apuestas.</param>
        /// <returns>Los puntos obtenidos.</returns>
        public float calculaPuntos(int points)
        {
            float puntosObtenidos = points / 2;
            return puntosObtenidos;
        }
    }
}
