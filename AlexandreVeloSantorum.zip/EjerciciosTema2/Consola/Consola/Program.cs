﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Negocio;

namespace Consola
{
    class Program
    {
        static void Main(string[] args)
        {
            MiClase negocio = new MiClase();
            String user, nombre, email;
            Console.WriteLine("Escribe el usuario");
            user = Console.ReadLine();
            Console.WriteLine("Escribe el email");
            email = Console.ReadLine();
            Console.WriteLine("Escribe el nombre");
            nombre = Console.ReadLine();
            negocio.getConsoleContent(user, email, nombre);
            negocio.sendContentToDatos();

        }
    }
}
