﻿//BreoBeceiro:25/03/2020
//PLEXUS | Tema3

//¿NO SE PUEDE CONCATENAR UNA VARIABLE A LA INSTANCIA DE UN OBJETO? LÍNEA 41: 
//   Turista tourist = new Turista(nombre, new + transporteUpper + ());

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ej3._3
{
    class Program
    {
        static void Main()
        {
            string nombre;
            string transporte;
            string primeraLetra;
            string primeraLetraUpper;
            string restoLetras;
            string transporteUpper;

            Console.WriteLine("Eres un turista, tu nombre es...");
            nombre = Console.ReadLine();

            Console.WriteLine("Quieres viajar en (avion, barco o coche)...");
            transporte = Console.ReadLine();

            #region "Intento fallido"
            transporte.ToLower();
            primeraLetra = transporte.Substring(0, 1);
            primeraLetraUpper= primeraLetra.ToUpper();
            restoLetras = transporte.Substring(1, transporte.Length-1);

            transporteUpper = primeraLetraUpper + restoLetras;
            Console.WriteLine(transporteUpper);
            #endregion

            Turista tourist = new Turista(nombre, new Mar());
            Viaje vacaciones = new Viaje();

            Console.WriteLine("El turista " + tourist.nombre + " se deplaza en " + tourist.transporte() + ".");
            // Console.WriteLine(tourist.transporte(new Mar()));

            if (Persistencia.registraViaje(tourist.nombre, vacaciones.id))
            {
                //Viaje registrado...
            }
            else
            {
                //Fallo registrando el viaje...
            }


            Console.ReadKey();
        }
    }
}
