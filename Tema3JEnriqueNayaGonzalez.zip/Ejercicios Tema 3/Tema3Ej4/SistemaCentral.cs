﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3Ej4
{
    static class SistemaCentral
    {
        static double CalcularImporte(int Modalidad,int Importe)
        {
            double puntos=0;
            switch (Modalidad)
            {
                case 1:
                    puntos= Importe / 2;
                    break;
                case 2:
                    Random Rdm = new Random();
                    if (Rdm.Next(2) == 1)
                    {
                        if (Rdm.Next(2)==1)
                        {
                            puntos= 300;
                        }
                        else
                        {
                            puntos = 200; 
                        }
                    }
                    else
                    {
                        puntos = 0;
                    }
                    break;
                case 3:
                    puntos = Importe / 10;
                    break;
            }
            return puntos * 15;
        }
        public static void RealizarApuesta(Apuesta apuesta)
        {
            Console.WriteLine("El jugador "+apuesta.jugador+" ha jugado en "+apuesta.evento+" la cantidad de "+apuesta.importe+". El resultado ha sido: "+
                CalcularImporte(apuesta.evento,apuesta.importe));
        }
    }
}
