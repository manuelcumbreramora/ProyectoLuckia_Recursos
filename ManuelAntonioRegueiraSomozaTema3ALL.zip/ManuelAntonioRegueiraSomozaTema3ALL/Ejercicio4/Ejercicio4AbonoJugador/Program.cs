﻿using EventoAtletismo;
using EventoCarreras;
using EventoFutbol;
using PJugador;
using PSistemaApuestaAtletismo;
using PSistemaApuestaCarreras;
using PSistemaApuestaFutbol;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio4AbonoJugador
{
    class Program
    {
        static void Main(string[] args)
        {

            Jugador j1 = new Jugador("Juan", 80);//creamos jugador
            Jugador j2 = new Jugador("Manuel", 10);
            Jugador j3 = new Jugador("Angel", 50);
    

            EAtletismo eventoAt1 = new EAtletismo("Carrera 100 metros");//creamos evento
            EAtletismo eventoAt2 = new EAtletismo("Carrera 50 metros");
            EAtletismo eventoAt3 = new EAtletismo("Carrera 10 metros");

            EFutbol eventoFt1 = new EFutbol("Copa", "Madrid", "Barsa");
            EFutbol eventoFt2 = new EFutbol("Liga", "Valencia", "Atletico");
            EFutbol eventoFt3 = new EFutbol("Derbi", "Depor", "Celta");

            ECarreras eventoCar1 = new ECarreras("Torneo España", " pista A");
            ECarreras eventoCar2 = new ECarreras("Torneo Francia", " pista B");
            ECarreras eventoCar3 = new ECarreras("Torneo Portugal", " pista C");


            ApuestaFutbol[] arrayApuestaFt = new ApuestaFutbol[3]; // Resultado puede ser 0 empate,1 ganador equipo1, 2 ganador equipo 2
            arrayApuestaFt[0] = new ApuestaFutbol(j1, eventoFt1, 1);
            arrayApuestaFt[1] = new ApuestaFutbol(j2, eventoFt2, 2);
            arrayApuestaFt[2] = new ApuestaFutbol(j3, eventoFt3, 1);

            ApuestaAtletismo[] arrayApuestaAt = new ApuestaAtletismo[3];
            arrayApuestaAt[0] = new ApuestaAtletismo(j1, eventoAt1);
            arrayApuestaAt[1] = new ApuestaAtletismo(j2, eventoAt2);
            arrayApuestaAt[2] = new ApuestaAtletismo(j3, eventoAt3);


            ApuestaCarreras[] arrayApuestaCarerra = new ApuestaCarreras[3];
            arrayApuestaCarerra[0] = new ApuestaCarreras(j1, eventoCar1);
            arrayApuestaCarerra[1] = new ApuestaCarreras(j2, eventoCar1);
            arrayApuestaCarerra[2] = new ApuestaCarreras(j3, eventoCar1);

            Console.WriteLine("INICIO DE TODAS LAS APUESTAS DE FUTBOL");
            Console.WriteLine("-----------------------------------------");
            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine("APUESTA DE FUTBOL");
                Console.WriteLine("INICIO DE APUESTA DE JUGADOR");
                arrayApuestaFt[i].Player.MostrarJugador();
                Console.WriteLine("**************************************");
                arrayApuestaFt[i].mostrarApuesta();
                Console.ReadLine();
                Console.WriteLine("JUGAMOS APUESTA");
                arrayApuestaFt[i].JugarApuesta();
                Console.WriteLine("    ");
                Console.WriteLine("INFORMACION DE LA APUESTA TRAS RESOLUCION DE PARTIDO");
                arrayApuestaFt[i].mostrarApuesta();
                Console.WriteLine("INFORMACIÓN DE JUGADOR TRAS APUESTA");
                arrayApuestaFt[i].Player.MostrarJugador();
                Console.WriteLine("FIN DE APUESTA DE JUGADOR");
                Console.ReadLine();
                Console.Clear();
            }
            Console.WriteLine("FINALIZACION DE TODAS LAS APUESTAS DE FUTBOL");
            Console.WriteLine("    ");
            Console.WriteLine("    ");
            Console.WriteLine("INICIO DE TODAS LAS APUESTAS DE ATLETISMO");
            Console.WriteLine("-----------------------------------------");
            for (int x = 0; x < 3; x++)
            {
                Console.WriteLine("APUESTA DE ATLETISMO");
                Console.WriteLine("INICIO DE APUESTA DE JUGADOR");
                arrayApuestaAt[x].Player.MostrarJugador();
                Console.WriteLine("**************************************");
                arrayApuestaAt[x].mostrarApuesta();
                Console.ReadLine();
                Console.WriteLine("JUGAMOS APUESTA");
                arrayApuestaAt[x].JugarApuesta();
                Console.WriteLine("    ");
                Console.WriteLine("INFORMACION DE LA APUESTA TRAS RESOLUCION DE PRUEBA ATLETISMO");
                arrayApuestaAt[x].mostrarApuesta();
                Console.WriteLine("INFORMACIÓN DE JUGADOR TRAS APUESTA");
                arrayApuestaAt[x].Player.MostrarJugador();
                Console.WriteLine("FIN DE APUESTA DE JUGADOR");
                Console.ReadLine();
                Console.Clear();
            }
            Console.WriteLine("FINALIZACION DE TODAS LAS APUESTAS DE ATLETISMO");
            Console.WriteLine("    ");
            Console.WriteLine("    ");
            Console.WriteLine("INICIO DE TODAS LAS APUESTAS DE CARRERAS");
            Console.WriteLine("-----------------------------------------");
            for (int z = 0; z < 3; z++)
            {
                Console.WriteLine("APUESTA DE CARRERAS");
                Console.WriteLine("INICIO DE APUESTA DE JUGADOR");
                arrayApuestaCarerra[z].Player.MostrarJugador();
                Console.WriteLine("**************************************");
                arrayApuestaCarerra[z].mostrarApuesta();
                Console.ReadLine();
                Console.WriteLine("JUGAMOS APUESTA");
                arrayApuestaCarerra[z].JugarApuesta();
                Console.WriteLine("    ");
                Console.WriteLine("INFORMACION DE LA APUESTA TRAS RESOLUCION DE CARRERA");
                arrayApuestaCarerra[z].mostrarApuesta();
                Console.WriteLine("INFORMACIÓN DE JUGADOR TRAS APUESTA");
                arrayApuestaCarerra[z].Player.MostrarJugador();
                Console.WriteLine("FIN DE APUESTA DE JUGADOR");
                Console.ReadLine();
                Console.Clear();
            }

            Console.WriteLine("FINALIZACION DE TODAS LAS APUESTAS DE CARRERAS");
            Console.WriteLine("    ");
            Console.WriteLine("    ");
            Console.WriteLine("FIN DE TODAS LAS APUESTAS");
            Console.WriteLine("PULSA CUALQUIER TECLA PARA SALIR");

            Console.ReadLine();
   

        }
    }
}
