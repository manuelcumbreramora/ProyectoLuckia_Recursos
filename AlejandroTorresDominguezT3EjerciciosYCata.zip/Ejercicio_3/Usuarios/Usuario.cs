﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_3
{
    abstract class Usuario
    {
        public Usuario()
        {
        }

        public Usuario(string nombre, string contra)
        {
            Nombre = nombre;
            Contra = contra;
        }

        private string Nombre {get; set;}
        private string Contra { get; set; }

        public virtual void verNotas()
        {
            Console.WriteLine("Ver todas la notas");
        }

    }
}
