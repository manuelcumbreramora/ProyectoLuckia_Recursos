﻿using System;
using Abstraccion;

namespace Herencias
{
    public class Hospital : Plazas
    {
        public InterfazMedico interfazMedico;
        public InterfazCirujano interfazCirujano;
        public Hospital(InterfazMedico interfazMedico, InterfazCirujano interfazCirujano)
        {
            this.interfazMedico = interfazMedico;
            this.interfazCirujano = interfazCirujano;
        }

        public void asignarMedico(Medico medico)
        {
            interfazMedico.operarPaciente(medico);
        }

        public void asignarCirujano(Cirujano cirujano)
        {
            interfazCirujano.operarPaciente(cirujano);
        }

        public override string devolverCamasDisponibles(int tipo)
        {
            if (tipo == 1)
            {
                return "Hay " + camasParaSanos + " camas disponibles!";
            }
            else{
                return "Hay " + camasParaGraves + " camas disponibles!";
            }
            
        }
    }

    public interface InterfazMedico
    {
        void operarPaciente(Medico medico);
    }

    public interface InterfazCirujano
    {
        void operarPaciente(Cirujano cirujano);
    }

}
