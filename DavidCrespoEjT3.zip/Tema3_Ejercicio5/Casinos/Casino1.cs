﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ejercicio5
{
    class Casino1 : ICasino
    {
        int numJug, numGen, ganancia;
        public int Juego()
        {
            var rand = new Random();
            numGen = rand.Next(1, 50);

            Console.WriteLine("Has apostado 100 euros!!");
            Console.WriteLine("Está jugando a la ruleta de la fortuna");
            Console.WriteLine("Elija un número entero entre 1 y 50");
            numJug = Int16.Parse(Console.ReadLine());
            if (numJug == numGen){
                Console.WriteLine("Ha ganado 3000 euros!!");
                ganancia = 3000;
                return ganancia;
            }
            else
            {
                Console.WriteLine("Has perdido...");
                ganancia = 0;
                return ganancia;
            }


        }

    }
}
