﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Consola
{
    public class IODatos
    {
        public void EscribirDatos(List<TareaViewModel> tareaViewModels)
        {
            try
            {
                IOLog.EscribirLog("Inicio escritura de tareas en archivo");
                StreamWriter writetext = new StreamWriter($@"{Directory.GetCurrentDirectory()}\tareas pendientes.txt");
                foreach(TareaViewModel tVM in tareaViewModels)
                {
                    writetext.WriteLine(tVM.ToString());
                }
                writetext.Flush();
                writetext.Close();

            }
            catch (IOException ex)
            {
                IOLog.EscribirLog(ex.Message);
            }
        }
    }
}
