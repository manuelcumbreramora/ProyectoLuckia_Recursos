﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BibliotecaClases
{
    public class Core : Penalizador
    {
        public int Penalizacion { get; set; }
        public override int PenalizarFutbol()
        {
            Penalizacion = 50;
            return Penalizacion;
        }
        public override int PenalizarBoleibal()
        {
            Penalizacion = 30;
            return Penalizacion;
        }
        public override int PenalizarBalonmano()
        {
            Penalizacion = 20;
            return Penalizacion;
        }
        public override void AvisarPenalizacion()
        {
            Console.WriteLine("Te vamos a penalizar con " + Penalizacion + " por acciones ilegales");
        }
    }
}
