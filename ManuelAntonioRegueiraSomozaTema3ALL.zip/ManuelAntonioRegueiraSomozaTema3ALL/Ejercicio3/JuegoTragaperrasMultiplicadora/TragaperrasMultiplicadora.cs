﻿using JuegoTragaperras;
using OperacionesGeneracionAleatorias;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JuegoTragaperrasMultiplicadora
{
    public class TragaperrasMultiplicadora:Tragaperras
    {
        private int PagoMultiplicador;


        public TragaperrasMultiplicadora(int numeroLineas, string nombreJuego, int pagoMultiplicador)
        {
            NombreJuego = nombreJuego;
            NumeroLineas = numeroLineas;
            PagoMultiplicador = pagoMultiplicador;

        }
        
        public void MostrarDetallesDatosJuego()
        {
            this.MostrarDatosJuego();
            Console.WriteLine("Pago Multiplicador {0}", this.PagoMultiplicador);
        }
    }
}
