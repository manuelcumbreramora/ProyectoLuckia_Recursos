﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio2
{
    public class Sistema_penalizacion : Penalizador
    {
        public override void penalizar(int tipo,Jugador jugador)
        {
            int pen = 0;
            switch (tipo)
            {
                case 1:
                    pen = 20;
                    break;
                case 2:
                    pen = 40;
                    break;
                case 3:
                    pen = 100;
                    break;
            }
            if (jugador.monedero.compruebaSaldo() - pen <= 0)
                jugador.monedero = new Monedero();
            else
                jugador.monedero.quitaSaldo(pen);
#if DEBUG
            Console.WriteLine(jugador.monedero.compruebaSaldo());
#endif
        }
    }
}

