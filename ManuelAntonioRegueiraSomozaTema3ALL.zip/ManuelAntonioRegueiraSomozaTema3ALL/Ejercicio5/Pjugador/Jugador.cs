﻿using InterfaceCasino;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pjugador
{
   
    public class Jugador
    {
        private String Nombre;
        public ICasino Juego1;
        public ICasino Juego2;
        public ICasino Juego3;
        public Jugador(String nombre,ICasino juego1, ICasino juego2, ICasino juego3)
        {
            Nombre = nombre;
            Juego1 = juego1;
            Juego2 = juego2;
            Juego3 = juego3;

        }

        public void JugandoSecuencia()
        {
            Juego1.Jugar();
            Juego2.Jugar();
            Juego3.Jugar();

        }
    }
}
