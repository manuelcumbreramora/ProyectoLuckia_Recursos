﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.IO;
using System.Net.Http;

namespace Consola
{
    public class Usuario
    {
        public Usuario()
        {
        }

        public int Id { get; set; }
        public string Nombre { get; set; }
        public List<Consola.Tarea> tareasNoRealizadas { get; set; }
        public HttpClient client;
        EnvironmentVariableTarget usuarios;

        public async Task CrearTareasNoRealizadas()
        {
            Console.WriteLine("Inicio de procesamiento");
            client = new HttpClient();
            var urlTareas = "https://jsonplaceholder.typicode.com/todos";
            var respuestaTareas = await client.GetAsync(urlTareas);
            respuestaTareas.EnsureSuccessStatusCode();
            var cuerpoRespuestaTareas = await respuestaTareas.Content.ReadAsStringAsync();
            Console.WriteLine(cuerpoRespuestaTareas);
            var tareas = JsonConvert.DeserializeObject<Tarea[]>(cuerpoRespuestaTareas);
            tareasNoRealizadas = tareas.Where(x => !x.Completed).ToList();
        }

        public async Task CrearUsuarios()
        {
            var urlUsuarios = "https://jsonplaceholder.typicode.com/users";
            var respuestaUsuarios = await client.GetAsync(urlUsuarios);
            respuestaUsuarios.EnsureSuccessStatusCode();
            var cuerpoRespuestaUsuarios = await respuestaUsuarios.Content.ReadAsStringAsync();
            Console.WriteLine(cuerpoRespuestaUsuarios);
            var usuarios = JsonConvert.DeserializeObject<Usuario[]>(cuerpoRespuestaUsuarios);

        }






    }
}
