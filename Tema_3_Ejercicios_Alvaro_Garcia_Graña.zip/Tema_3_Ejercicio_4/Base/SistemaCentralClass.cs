﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Eventos;
using Monedero;

namespace SistemaCentral
{
    class SistemaCentralClass
    {
        public void ComprobarApuesta(Apuesta apuesta)
        {
            Console.WriteLine("Si desea comprobar sus apuestas pulse ENTER!.");
            apuesta.monedero.CalcularGanacia(apuesta.evento.eventoSeleccionado, apuesta.monedero);
        }

        public void GenerarApuestas(List<Apuesta> apuestas)
        {
            Apuesta apuesta1 = new Apuesta();
            EventoClass evento1 = new EventoClass();
            MonederoClass monedero1 = new MonederoClass();

            Apuesta apuesta2 = new Apuesta();
            EventoClass evento2 = new EventoClass();
            MonederoClass monedero2 = new MonederoClass();

            Apuesta apuesta3 = new Apuesta();
            EventoClass evento3 = new EventoClass();
            MonederoClass monedero3 = new MonederoClass();

            Apuesta apuesta4 = new Apuesta();
            EventoClass evento4 = new EventoClass();
            MonederoClass monedero4 = new MonederoClass();



            //Apuesta1
            monedero1.importeApuesta = 100;
            evento1.eventoSeleccionado = 1;
            apuesta1.cobrador = "Alvaro";
            apuesta1.evento = evento1;
            apuesta1.monedero = monedero1;
            
            //Apuesta2
            monedero2.importeApuesta = 50;
            evento2.eventoSeleccionado = 2;
            apuesta2.cobrador = "Alvaro";
            apuesta2.evento = evento2;
            apuesta2.monedero = monedero2;
            
            //Apuesta3
            monedero3.importeApuesta = 20;
            evento3.eventoSeleccionado = 3;
            apuesta3.cobrador = "Alvaro";
            apuesta3.evento = evento3;
            apuesta3.monedero = monedero3;
            
            //Apuesta4
            monedero4.importeApuesta = 60;
            evento4.eventoSeleccionado = 1;
            apuesta4.cobrador = "Alvaro";
            apuesta4.evento = evento4;
            apuesta4.monedero = monedero4;

            apuestas.Add(apuesta1); 
            apuestas.Add(apuesta2);
            apuestas.Add(apuesta3);
            apuestas.Add(apuesta4);
        }
    }
}
