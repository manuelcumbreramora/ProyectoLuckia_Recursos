﻿using System;
using RectanguloSpace;
using TrianguloSpace;
using CuadradoSpace;
using CalcularClase;

namespace Ejercicio3T3
{
    class Program
    {
        static void Main(string[] args)
        {
            Calcular calc = new Calcular(new Triangulo(3, 3, 3, 4));
            Console.WriteLine("Triangulo");
            Console.WriteLine(calc.calcArea());
            Console.WriteLine(calc.calcPerimetro());
            Calcular calc1 = new Calcular(new Cuadrado(3));
            Console.WriteLine("Cuadrado");
            Console.WriteLine(calc1.calcArea());
            Console.WriteLine(calc1.calcPerimetro());
            Calcular calc2 = new Calcular(new Rectangulo(3, 7));
            Console.WriteLine("Rectangulo");
            Console.WriteLine(calc2.calcArea());
            Console.WriteLine(calc2.calcPerimetro());
        }
    }
}
