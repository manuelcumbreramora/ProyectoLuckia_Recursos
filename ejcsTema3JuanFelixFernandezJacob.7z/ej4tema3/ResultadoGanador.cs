﻿using System;

namespace ej4tema3
{
    internal class ResultadoGanador: Resultado
    {
        private readonly String Ganador;

        public ResultadoGanador(String ganador)
        {
            this.Ganador = ganador;
        }
        public int Comparar(Resultado otroResultado)
        {
            if (otroResultado is ResultadoGanador otroResultadoAtletismo)
            {
                if (Ganador.Equals(otroResultadoAtletismo.Ganador))
                {
                    // Ganador coincide.
                    return 1;
                }
                else
                {
                    // Ningún acierto.
                    return 0;
                }
            } else
            {
                // Se está comparando con un resultado de otra cosa.
                throw new Exception("Tipo de resultado no reconocido.");
            }
        }
    }
}