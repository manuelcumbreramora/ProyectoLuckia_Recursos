﻿using System;

namespace Base
{
    public class ExcepcionCustom : Exception
    {
        string _Message;

        public ExcepcionCustom(dynamic json) : base("Plep")
        {
            // Some parsing to create a human readable message (simplified)
            _Message = json.message;
        }

        public override string Message
        {
            get { return _Message; }
        }
    }
}
