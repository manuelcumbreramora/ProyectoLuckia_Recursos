﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Taxes;

namespace TaxCalculator
{
    public interface ITaxCalculator
    {
        float calculateTotalTaxes(List<ITax> taxes, float amount);
    }
}
