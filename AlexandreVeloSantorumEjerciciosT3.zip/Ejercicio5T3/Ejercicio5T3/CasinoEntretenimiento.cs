﻿using System;
using System.Collections.Generic;
using System.Text;
using CasinoInterfaz;

namespace CasinoEntretenimientolase
{
    class CasinoEntretenimiento : ICasino
    {
        public string resolverCasino()
        {
            string[] resultados = { "X", "1", "2" };
            Random rn = new Random();
            return resultados[rn.Next(0, 3)];
        }

        public int jugar(string apuestaUsuario, string cantidad)
        {
            string resultado = resolverCasino();
            Console.WriteLine("El resultado correcto es " + resultado);
            if (apuestaUsuario == resultado)
            {
                Console.WriteLine("Has acertado tú apuesta en el partido");
                return Int32.Parse(cantidad) * 2;
            }
            else
            {
                return -Int32.Parse(cantidad);
            }
        }
    }
}
