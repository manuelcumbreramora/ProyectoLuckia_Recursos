﻿//BreoBeceiro:19/03/2020
//PLEXUS | Tema2

//FALTA EL INSTALADOR.

using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace SegundoIntento
{
    static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        static void Main()
        {
            ServiceBase[] ServicesToRun;
            ServicesToRun = new ServiceBase[]
            {
                new Service1()
            };
            ServiceBase.Run(ServicesToRun);

            //Se define el nombre del archivo a copiar y las rutas de las carpetas de origwn y destino:
            string fileName = "ficheroPrueba.txt";
            string sourcePath = @"C:\Users\breogan.beceirocasti\Desktop\Origen";
            string targetPath = @"C:\Users\breogan.beceirocasti\Desktop\Destino";

            //Se comprueba que la ruta exista:
            if (System.IO.Directory.Exists(sourcePath))
            {
                //Se combina cada ruta con el nombre del archivo a copiar:
                string sourceFile = System.IO.Path.Combine(sourcePath, fileName);
                string destFile = System.IO.Path.Combine(targetPath, fileName);

                //Se crea la carpeta de destino (a menos que ya exista, en ese caso, no hay acción):
                System.IO.Directory.CreateDirectory(targetPath);

                //Se ejecuta la copia del archivo. Si en la carpeta de destinio ya existe uno con el mismo nombre, se sobreescribe;
                //   si no existe, se crea:
                System.IO.File.Copy(sourceFile, destFile, true);

            }
            else
            {
                //Si la ruta no existe, se muestra el mensaje (estos mensajes no se mostrarían en realidad, dado que estos servicios
                //   son procesos automatizados que no cuentan con salida por pantalla):
                Console.WriteLine("ERROR: No se encuentra la ruta.");
            }

            Console.ReadKey();
        }
    }
}
