﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Bets.AbstractBet;

namespace Bets
{
    public interface IBet
    {
        BetGame GetGame();

        string[] GetBet();

        float GetAmount();
    }
}
