﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_Pago
{
    public class Futbol : Deporte
    {
        public int puntos { get; set; }
        public Futbol() { }
        public Futbol(string nomEvent, int points) {
            this.nombre = "Futbol";
            this.puntos = points;
        }
        public void resultados()
        {
            Random rnd = new Random();
            int opt = rnd.Next(1, 3);
            switch (opt)
            {
                case 1:
                    Console.WriteLine("Ha fallado en el resultado y en la quiniela.");
                    this.puntos = 0;
                    break;
                case 2:
                    Console.WriteLine("Ha fallado el resultado pero ha acertado la quiniela");
                    this.puntos = 200;
                    break;
                case 3:
                    Console.WriteLine("Ha acertado el resultado.");
                    this.puntos = 300;
                    break;
            }
        }
    }
}
