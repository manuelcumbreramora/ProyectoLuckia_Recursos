﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hosteleria
{
    public class PagoRestaurante
    {
        private Comida comida;
        private Precio precio;
        public PagoRestaurante(Comida com, Precio prec)
        {
            this.comida = com;
            this.precio = prec;
        }
        public void comer(Restaurante res)
        {
            comida.elegir(res);
            precio.pagar(res);
        }
    }
}
