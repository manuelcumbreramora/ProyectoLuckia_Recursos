﻿using OperacionesGeneracionAleatorias;
using ProyectoInterfazJuego;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JuegoMesa
{
    public class Mesa : IJuegoCasino
    {
        protected int NumeroMesa;
        protected string NombreJuego;
        public Mesa()
        {

        }
        public Mesa(int numMesa,String nombreJuego)
        {
            NumeroMesa = numMesa;
            NombreJuego = nombreJuego;
        }
        public void Apostar(int valorApuesta)
        {
            Console.WriteLine("Apostando {0} a juego de Mesa {1}", valorApuesta, this.NombreJuego) ;
        }

        public void Jugar()
        {
            int valorAleatorio = AleatorioBasico.generarAleatorioBasico();
            Console.WriteLine("Jugando a juego de Mesa {0}, Valor aleatorio {1}", this.NombreJuego, valorAleatorio);
            
        }

        public void MostrarDatosJuego()
        {
            Console.WriteLine("Nombre Juego Mesa {0}", this.NombreJuego);
            Console.WriteLine("Numero de Mesa  {0}", this.NumeroMesa);
        }
    }
}
