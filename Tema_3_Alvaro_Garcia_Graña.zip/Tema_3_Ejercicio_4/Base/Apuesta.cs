﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Eventos;
using Monedero;

namespace SistemaCentral
{

    public class Apuesta
    {
        public string cobrador { get; set; }
        public EventoClass evento { get; set; }
        public MonederoClass monedero { get; set; }
    }
}
