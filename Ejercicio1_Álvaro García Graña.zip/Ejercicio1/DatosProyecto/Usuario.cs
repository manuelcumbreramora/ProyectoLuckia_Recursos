﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DatosProyecto
{
    public class Usuario
    {
        private int identificador;
        private String nombreUsuario;
        private String password;

        public void guardarUsuario(String user, String pass)
        {
            Random r = new Random();
            identificador = r.Next(0, 100);
            nombreUsuario = user;
            password = pass;
        }

    }
}
