﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Net.Http;

namespace Consola
{
    class ProcesarUsuario
    {
        public async Task<Usuario[]> RecuperarUsuarios(HttpClient client)
        {
            IOLog.EscribirLog("Inicio procesamiento de usuarios");
            var urlUsuarios = "https://jsonplaceholder.typicode.com/users";
            var respuestaUsuarios = await client.GetAsync(urlUsuarios);
            respuestaUsuarios.EnsureSuccessStatusCode();
            var cuerpoRespuestaUsuarios = await respuestaUsuarios.Content.ReadAsStringAsync();
            Console.WriteLine(cuerpoRespuestaUsuarios);

            var usuarios = JsonConvert.DeserializeObject<Usuario[]>(cuerpoRespuestaUsuarios);
            return usuarios;
        }

    }
}
