﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio1
{
    public class Persona
    {
        public string Nombre { get; set; }
        public int Edad { get; set; }

        public Persona()
        {
        }

        public Persona(string nombre, int edad)
        {
            this.Nombre = nombre;
            this.Edad = edad;
        }

        

        public void realizarsuscripcion()
        {
            Console.WriteLine("Introduce tu nombre");
            this.Nombre = Console.ReadLine();
            Console.WriteLine("Introduce tu edad");
            this.Edad = int.Parse(Console.ReadLine());
            if(Edad>=18)
                Console.WriteLine("Creado con exito el usuario " + this.Nombre + " de " + this.Edad + " años");
            else
                Console.WriteLine("No se admiten menores");
        }

    }
}
