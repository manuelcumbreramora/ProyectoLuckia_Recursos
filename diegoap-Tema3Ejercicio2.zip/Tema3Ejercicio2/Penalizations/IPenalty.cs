﻿using Games;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Users;
using static BettorPenalties.AbstractPenalty;

namespace Penalizations
{
    public interface IPenalty
    {
        int GetId();

        IBettor GetBettor();

        AbstractGame GetGame();

        PenaltySeverity GetSeverity();

        void ExecutePenalty();

        float GetPenaltyBaseAmount();

        float GetPenaltyAmount();
    }
}
