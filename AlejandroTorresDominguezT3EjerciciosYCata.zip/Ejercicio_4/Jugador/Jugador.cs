﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_4
{
    public class Jugador
    {
        public Monedero monedero{ get; set; }
        public List<Apuesta> listaApuestas { get; set; }
        public Jugador()
        {
            this.listaApuestas = new List<Apuesta>();
        }

        public Jugador(Monedero _monedero)
        {
            this.monedero = _monedero;
            this.listaApuestas = new List<Apuesta>();
        }

        public void Apostar(IEvento evento)
        {
           listaApuestas.Add(new Apuesta(evento));
        }

    }
}
