﻿using System;
using IFiguraSpace;

namespace TrianguloSpace
{
    public class Triangulo : IFigura
    {
        private int Lado1 { get; set; }
        private int Lado2 { get; set; }
        private int Lado3 { get; set; }
        private int Altura { get; set; }
        public Triangulo(int lado1, int lado2, int lado3, int altura)
        {
            Lado1 = lado1;
            Lado2 = lado2;
            Lado3 = lado3;
            Altura = altura;
        }

        public int Area()
        {
            return (Lado1 * Altura);
        }

        public int Perimetro()
        {
            return (Lado1 + Lado2 + Lado3);
        }
    }
}
