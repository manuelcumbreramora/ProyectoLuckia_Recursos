﻿using Payments;
using Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaxCalculator;
using Taxes;
using Users;

namespace Tema3Parte2Ejercicio3
{
    class Program
    {
        public static List<User> users;
        public static List<AbstractTax> taxes;
        public static List<AbstractTaxCalculator> taxCalculators;
        public static List<AbstractPayment> payments;

        static void Main(string[] args)
        {
            initData();
            mainMenu();
        }

        public static void initData()
        {
            users = new List<User>();
            users.Add(new User("Sherwood Whitman", 28, "3785-2015-6344"));
            users.Add(new User("Hans-Dieter Kauffman", 35, "9502-6941-3852"));
            users.Add(new User("Paolo Bassini", 21, "9624-3575-1092"));
            users.Add(new User("Albert Ernaux", 41, "6501-9086-2887"));
            users.Add(new User("Belén Ortega", 28, "8162-5407-6152"));

            taxes = new List<AbstractTax>() { new TaxIesadEs(), new TaxVatEs() };

            taxCalculators = new List<AbstractTaxCalculator>() { new FootballTaxCalculator(), new RacingTaxCalculator() };

            payments = new List<AbstractPayment>();
;       }

        public static void mainMenu()
        {
            bool exitLoop = false;
            do
            {
                Console.WriteLine();

                Console.WriteLine("\n");
                Console.WriteLine("1. Show user list.");
                Console.WriteLine("2. Show taxes list.");
                Console.WriteLine("3. Show payments ordered.");
                Console.WriteLine("4. Order a payment.");
                Console.WriteLine("x. Exit application.");
                Console.WriteLine("");
                Console.Write("> ");
                string s = Console.ReadLine().ToLower();
                switch (s)
                {
                    case "1":
                        showAllUsers();
                        break;
                    case "2":
                        showAllTaxes();
                        break;
                    case "3":
                        showAllPayments();
                        break;
                    case "4":
                        doPayment();
                        break;
                    case "x":
                        exitLoop = true;
                        break;
                    default:
                        Console.WriteLine("\nError, illegal option value.");
                        break;
                }
            } while (!exitLoop);
        }

        static void showAllUsers()
        {
            Console.WriteLine();

            int count = users.Count();

            if (count == 0)
            {
                Console.WriteLine("No users found.");
            }
            else
            {
                Console.WriteLine("id ;; name ;; age ;; checking account");
                for (int i = 0; i < count; i++)
                {
                    var item = users.ElementAt(i);
                    Console.WriteLine(i + " ;; " + item.name + " ;; " + item.age + " ;; " + item.checkingAccount);
                }
            }
        }

        static void showAllTaxes()
        {
            Console.WriteLine();

            int count = taxes.Count();

            if (count == 0)
            {
                Console.WriteLine("No taxes found.");
            }
            else
            {
                Console.WriteLine("id ;; name ;; country code ;; description");
                for (int i = 0; i < count; i++)
                {
                    var item = taxes.ElementAt(i);
                    Console.WriteLine(i + " ;; " + item.id + " ;; " + item.countryCode + " ;; " + item.desc);
                }
            }
        }

        static void showAllPayments()
        {
            Console.WriteLine();

            int count = payments.Count();
            if (count == 0)
            {
                Console.WriteLine("No ordered payments found.");
            }
            else
            {
                Console.WriteLine("id ;; amount ;; user name ;; user checking account ;; payment type ;; taxes ;; transfered amount");
                for (int i = 0; i < payments.Count(); i++)
                {
                    var item = payments.ElementAt(i);
                    Console.Write(i + " ;; " + item.amount + " ;; " + item.user.name + " ;; ");
                    Console.Write(item.user.checkingAccount + " ;; " + item.paymentType + " ;; ");
                    Console.WriteLine(item.calculateTotalTaxes() + " ;; " + item.calculateFinalAmount());
                }
            }
        }
        static void doPayment() {
            string[] data = showPaymentMenu();

            if (data == null)
            {
                return;
            }

            uint score = 0;

            int userId = int.MinValue;
            if (! Int32.TryParse(data[0], out userId))
            {
                Console.WriteLine("Error, illegal user id value.");
                score++;
            }

            float amount = float.MinValue;
            if (! float.TryParse(data[1], out amount))
            {
                Console.WriteLine("Error, illegal amount value.");
                score++;
            }

            string sport = data[2].ToLower();
            if ((! sport.Equals("football")) && (!sport.Equals("racing")))
            {
                Console.WriteLine("Error, illegal sport value (must be 'football' or 'racing').");
                score++;
            }

            User user = null;
            try
            {
                user = users.ElementAt(userId);
            } 
            catch (ArgumentException ex) 
            {
                Console.WriteLine("Error, illegal user id value (" + userId + ")");
                score++;
            }

            if (score > 0)
            {
                return;
            }

            Tuple<bool, AbstractPayment> r = PaymentService.doPayment(user, amount, sport);
            bool success = r.Item1;
            AbstractPayment payment = r.Item2;
            if (success)
            {
                Console.WriteLine("Payment successfully ordered.\n");
                Console.WriteLine("Payment data:\n");
                Console.WriteLine("  -- amount: " + payment.amount);
                Console.WriteLine("  -- taxes: " + payment.calculateTotalTaxes());
                Console.WriteLine("  -- transfered amount ordered (after taxes): " + payment.calculateFinalAmount());

                payments.Add(payment);
            } 
            else
            {
                Console.WriteLine("Error(s) found, payment not ordered.");
            }
        }

        static string[] showPaymentMenu()
        {
            Console.WriteLine("\n");
            Console.WriteLine("Enter user id [or 'x' to cancel payment].");
            Console.Write("> ");
            string userId = Console.ReadLine();
            if (userId.ToLower().Equals("x"))
            {
                return null;
            }

            Console.WriteLine("Enter payment amount [or 'x' to cancel payment].");
            Console.Write("> ");
            string amount = Console.ReadLine();
            if (amount.ToLower().Equals("x"))
            {
                return null;
            }

            Console.WriteLine("Enter bet sport ('football' or 'racing') [or 'x' to cancel payment].");
            Console.Write("> ");
            string sport = Console.ReadLine();
            if (sport.ToLower().Equals("x"))
            {
                return null;
            }

            return new string[] { userId, amount, sport };
        }

    }
}
