﻿//BreoBeceiro:24/03/2020
//PLEXUS | Tema3

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ej3
{
    public class Jugador : Persona, IPersona
    {   
        public Jugador() { }

        public Jugador(string user, string password)
        {
            this.usuario = user;
            this.contrasena = password;
        }

        /// <summary>
        /// Función a ejecutar cada vez que un Jugador entre en una partida.
        /// </summary>
        /// <returns>TRUE si la ejecución tiene éxito o FALSE si falla.</returns>
        public bool participa() 
        {
            Console.WriteLine("El jugador " + this.usuario + " está jugando.");
            return true;
        }

        /// <summary>
        /// Envía una petición a la aplicación para obtener el historial de participaciones del jugador en los torneos de
        /// cartas.
        /// </summary>
        /// <param name="id">El código del jugador.</param>
        /// <returns>TRUE si la petición es aceptada o FALSE si es rechazada.</returns>
        public override bool solicitaHistorial(string idJugador)
        {
            return true;
        }

        /// <summary>
        /// Añade una entrada en el registro de jugadores.
        /// </summary>
        /// <returns>TRUE si todo fue bien o FALSE si hubo algún error.</returns>
        public bool fichar()
        {
            return true;
        }
    }
}
