﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Persistencia
{
    public class SQL : IPersistencia
    {
        public void cargaDatos(Array array)
        {
            Console.WriteLine("Carga de datos desde una base de datos SQL");
        }

        public void guardaDatos(Array array)
        {
            Console.WriteLine("Guardado en la base de datos SQL");
        }
    }
}
