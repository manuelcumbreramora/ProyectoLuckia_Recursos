﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioCuatro
{

     class SistemaCentral
    {
        public int importeSumados { get; set; }

        public void mostrarTotalImporte(Jugador jugador)
        {
            Console.WriteLine("Has ganado en total : " + jugador.monedero);
        }
   }















}
    

           