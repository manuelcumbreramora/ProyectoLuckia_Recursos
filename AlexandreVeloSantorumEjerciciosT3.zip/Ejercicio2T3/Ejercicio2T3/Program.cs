﻿using System;
using BibliotecaClases;

namespace Ejercicio2T3
{
    class Program
    {
        static void Main(string[] args)
        {
            Persona p = new Persona();
            Juego juego = new Juego();
            Core c = new Core();
            string nombre;
            int edad;
            string cantidad;
            Console.WriteLine("Introduce el nombre");
            nombre = Console.ReadLine();
            Console.WriteLine("Introduce la edad");
            edad = Int32.Parse(Console.ReadLine());
            p.realizarSuscripcion(nombre, edad);
            juego.elegirJuego("Futbol");
            Jugador j = new Jugador(p);
            int counter = 0;
            do
            {
                Console.WriteLine("Escribe la cantidad que quieres apostar (10,20,100) o * para salir:");
                cantidad = Console.ReadLine();
                counter=counter+1;
                int penalizar = 0;
                if (cantidad != "*")
                {
                    if (counter % 3 == 0)
                    {
                        if (juego.Tipo == "Futbol")
                        {
                            penalizar = c.PenalizarFutbol();
                            c.AvisarPenalizacion();
                        }
                        else if (juego.Tipo == "Balonmano")
                        {
                            penalizar = c.PenalizarBalonmano();
                            c.AvisarPenalizacion();
                        }
                        else
                        {
                            penalizar = c.PenalizarBoleibal();
                            c.AvisarPenalizacion();
                        }
                        j.Penalizar(penalizar);
                    }
                    j.apostar(cantidad);
                }
            } while (cantidad != "*");
            Console.WriteLine("Gracias por jugar con nosotros");
        }
    }
}
