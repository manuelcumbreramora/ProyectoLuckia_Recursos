﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio3._2
{
    interface iVehiculos
    {
        string Conducir();
    }

    public class tipoVehiculo1 : iVehiculos
    {
        public string Conducir()

        {
            return ("A todo gas");
        }
    }

    public class tipoVehiculo2 : iVehiculos
    {
        public string Conducir()
        {
            return ("A todo gas");
        }

        
    }
       
}