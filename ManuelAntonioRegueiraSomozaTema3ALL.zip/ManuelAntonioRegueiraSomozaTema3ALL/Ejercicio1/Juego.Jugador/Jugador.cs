﻿
using JuegoPersona;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Juego.Jugador
{
    public class Jugador : Persona
    {
        public int Bonus { get; set; }
        public int Juegos { get; set; }

        public Jugador()
        {
            Bonus = 0;
            Juegos = 0;

        }
        public Jugador(int edad, string nombre)
        {
            this.Edad = edad;
            this.Nombre = nombre;
            this.Bonus = 0;
            this.Juegos = 0;
        }
        public void Apostar()
        {
           
            this.Juegos = this.Juegos + 1;
            this.Bonus = Jugador.generarAleatorio(); 
        }
        public static Jugador RegistrarComoJugador(Persona person)
        {
            Jugador nuevoJugador = new Jugador(person.Edad, person.Nombre);
            return nuevoJugador;
        }
        public static int generarAleatorio()
        {
            Random random = new Random();
            int numAleatorio = random.Next(0, 100);
            return numAleatorio;
        }
    } 
}
