﻿using JuegoJuego;
using JuegoPersona;
using PenalizacionJuego;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core
{
    public class CorePenalizacion : Penalizador
    {
        public CorePenalizacion()
        {
            Penalizacion = 0;
        }
        public override void PenalizarPersonaJuego(Persona persona, Juego juego)
        {
            this.JugadorPenalizado = persona;
            Fecha = DateTime.Now;
            Penalizacion = juego.Penalizacion;
            persona.Monedero = persona.Monedero - juego.Penalizacion;
        }
        public void mostrarPenalizacion()
        {
            Console.WriteLine("Penalizador de Jugador {0}", this.JugadorPenalizado.getNombre());
            Console.WriteLine("Fecha {0}", this.Fecha);
            Console.WriteLine("Penalización {0}", this.Penalizacion);
        }
    }
}
