﻿//BreoBeceiro:24/03/2020
//PLEXUS | Tema3

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Cata
{
    class Jugador
    {
        public string usuario { get; set; }
        public string contrasena { get; set; }
        

        public Jugador() { }

        public Jugador(string user, string passw)
        {
            this.usuario = user;
            this.contrasena = passw;
        }

        /// <summary>
        /// Ejecuta una apuesta si el jugador dispone de fondos en su monedero, incrementando su registro de apuestas en la BBDD.
        /// </summary>
        /// <returns>TRUE si la apuesta se efectuó con éxito o FALSE si no.</returns>
        public bool apostar()
        {
            bool resultado;

            if (InteraccionBBDD.consultaSaldo(this.usuario) > 0)
            {
                if (InteraccionBBDD.nuevaApuesta(this.usuario))
                {
                    resultado = true;
                }
                else
                {
                    resultado = false;
                }
            }
            else
            {
                resultado = false;
            }
            return resultado;
        }
    }
}
