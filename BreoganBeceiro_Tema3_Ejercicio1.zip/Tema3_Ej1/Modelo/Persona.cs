﻿//BreoBeceiro:23/03/2020
//PLEXUS | Tema3

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo
{
    public class Persona
    {
        //Métodos autoimplementados (en PHP se definen los métodos 'get' y 'set' para las propiedades privadas o protegidas,
        //  pero en C# se recomienda su uso para todos los niveles de accesibilidad):
        public string nombre { get; set; }
        public string apellido { get; set; }
        public int edad { get; set; }

        public Persona() { }

        public Persona(string name, string surname)
        {
            this.nombre = name;
            this.apellido = surname;
        }

        public bool realizarSuscripcion()
        {
            return true;
        }
    }
}
