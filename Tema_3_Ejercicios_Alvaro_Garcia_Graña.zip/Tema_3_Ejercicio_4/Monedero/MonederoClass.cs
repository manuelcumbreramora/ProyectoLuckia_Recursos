﻿using System;

namespace Monedero
{
    public class MonederoClass : Calculos
    {
        public int importeApuesta { get; set; }

        private int importeGanancia { get; set; }

        public override void CalcularGanacia(int eventoSeleccionado, MonederoClass monedero)
        {
            int puntos = 0;
            Random random = new Random();
            switch (eventoSeleccionado)
            {
                case 1:
                    if (random.Next(0,100) <40)
                    {
                        puntos = monedero.importeApuesta / 2;
                        monedero.importeGanancia = puntos * 15;
                        Console.WriteLine("El jugador ha ganado en la modalidad de atletismo: " + monedero.importeGanancia + " Euros");
                    }
                    else
                    {
                        puntos = 0;
                        monedero.importeGanancia = puntos;
                        Console.WriteLine("El jugador ha perdido en la modalidad de atletismo: " + monedero.importeGanancia + " Euros");
                    }
                    break;
                case 2:
                    if (random.Next(0, 100) < 40)
                    {
                        if (random.Next(0, 50) < 20) {
                            puntos = monedero.importeApuesta + 300;
                            monedero.importeGanancia = puntos * 15;
                            Console.WriteLine("El jugador ha ganado 300 puntos en la modalidad de futbol: " + monedero.importeGanancia + " Euros");
                        } else {
                            puntos = monedero.importeApuesta + 200;
                            monedero.importeGanancia = puntos * 15;
                            Console.WriteLine("El jugador ha ganado otros 200 puntos en la modalidad de futbol: " + monedero.importeGanancia + " Euros");
                        }
                    }
                    else{
                        puntos = 0;
                        monedero.importeGanancia = puntos;
                        Console.WriteLine("El jugador ha perdido en la modalidad de futbol: " + monedero.importeGanancia + " Euros");
                    }
                    break;
                case 3:
                    if (random.Next(0, 100) < 40)
                    {
                        puntos = monedero.importeApuesta / 10;
                        monedero.importeGanancia = puntos * 15;
                        Console.WriteLine("El jugador ha ganado en la modalidad de carreras: " + monedero.importeGanancia + " Euros");
                    }
                    else
                    {
                        puntos = 0;
                        monedero.importeGanancia = puntos;
                        Console.WriteLine("El jugador ha perdido en la modalidad de carreras: " + monedero.importeGanancia + " Euros");
                    }
                    break;
                default:
                    break;
            }
        }

    }
}
