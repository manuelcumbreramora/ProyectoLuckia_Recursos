﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Games
{
    public class Basketball : AbstractGame
    {
        public Basketball() : base(AvailableGame.Basketball) { }
    }
}
