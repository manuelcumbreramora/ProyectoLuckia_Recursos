﻿using OperacionesGeneracionAleatorias;
using ProyectoInterfazJuego;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JuegoTragaperras
{
    public class Tragaperras : IJuegoCasino
    {
        protected string NombreJuego;
        protected int NumeroLineas;
        
        public Tragaperras()
        {

        }
        public Tragaperras(int numeroLineas, string nombreJuego)
        {
            NumeroLineas = numeroLineas;
            NombreJuego = nombreJuego;
        }
        public void Apostar(int valorApuesta)
        {
            Console.WriteLine("Apostando {0} a juego de Tragaperras {1}", valorApuesta,this.NombreJuego);
        }

        public void Jugar()
        {
            int valorAleatorio = AleatorioBasico.generarAleatorioBasico();
            Console.WriteLine("Jugando a juego de Tragaperras {0}, Valor aleatorio {1}", this.NombreJuego, valorAleatorio);
        }

        public void MostrarDatosJuego()
        {
            Console.WriteLine("Nombre Juego Tragaperras {0}", this.NombreJuego);
            Console.WriteLine("Numero Lineas {0}", this.NumeroLineas);
        }
        
    }
}
