﻿//BreoBeceiro:25/03/2020
//PLEXUS | Tema3

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Cata
{
    public static class InteraccionBBDD
    {
        /// <summary>
        /// Lista los eventos disponibles.
        /// </summary>
        /// <returns>La lista de eventos.</returns>
        public static List<string> listaEventos(string user)
        {
            List<string> resultado;

            if (consultaSaldo(user) > 0)
            {
                //Ejecuta la consulta y devuelve la lista...
                resultado = null;//"lista de eventos";
            }
            else
            {
                resultado = null;
            }
            return resultado;
        }

        /// <summary>
        /// Muestra el historial de apuestas de un jugador.
        /// </summary>
        /// <param name="user">El nombre de usuario del jugador dentro de la aplicación.</param>
        /// <returns>La lista con su historial de apuestas.</returns>
        public static List<string> historialApuestas(string user)
        {
            return null; //"historial";
        }

        /// <summary>
        /// Guarda en la BBDD la fecha de la apuesta e incrementa en uno el contador de apuestas en el registro.
        /// </summary>
        /// <param name="user">El nombre de usuario del jugador dentro de la aplicaión.</param>
        /// <returns>TRUE si todo fue bien o FALSE, si hubo algún error.</returns>
        public static bool nuevaApuesta(string user)
        {
            //Incrementa el registro de apuestas del usuario en la BBDD...
            return true;
        }

        /// <summary>
        /// Consulta los fondos que un jugador tiene en su monedero.
        /// </summary>
        /// <param name="user">El nombre de usuario del jugador dentro de la aplicación.</param>
        /// <returns>La cantidad disponible en su monedero.</returns>
        public static float consultaSaldo(string user)
        {
            //Consulta a la BBDD y devuelve el saldo...
            return 9;
        }

        /// <summary>
        /// Hace un ingreso de fondos en su monedero.
        /// </summary>
        /// <param name="user">El nombre de usuario del jugador dentro de la aplicación.</param>
        /// <param name="amount">La cantidad a ingresar</param>
        /// <returns>Los fondos de los que dispone en su monedero tras el ingreso.</returns>
        public static float ingresaSaldo(string user, float amount)
        {
            //Inserción a la BBDD y devuelve el saldo total...
            return 244;
        }

        /// <summary>
        /// Descuenta del monedero una cantidad de fondos.
        /// </summary>
        /// <param name="user">El nombre de usuario del jugador dentro de la aplicación.</param>
        /// <param name="amount">La cantidad a descontar</param>
        /// <returns>Los fondos de los que dispone en su monedero tras el descuento.</returns>
        public static float descuentaSaldo(string user, float amount)
        {
            //Actualiza campo de la BBDD y devuelve el saldo restante...
            return 224;
        }
    }
}
