﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ej3v2tema3
{
    class Disco: Producto
    {
        String Artista;
        String Estilo;
        

        public Disco(string artista, String titulo, DateTime fechaPublicacion, string estilo, double precio)
            :base(precio,  fechaPublicacion, titulo)
        {
            Artista = artista;
            Estilo = estilo;
        }

        public override string EscribirInformacion(StringBuilder salida, ISerializador serializador)
        {
            salida.Append(serializador.InicioEntidad("Disco"));

            base.EscribirTitulo(salida, serializador);

            salida.Append(serializador.Atributo("Artista", Artista));
            
            salida.Append(serializador.Atributo("Estilo", Estilo));
            
            base.EscribirFechaPublicacion(salida, serializador);

            base.EscribirPrecioUnitario(salida, serializador);

            salida.Append(serializador.FinEntidad());

            return salida.ToString();
        }
    }
}
