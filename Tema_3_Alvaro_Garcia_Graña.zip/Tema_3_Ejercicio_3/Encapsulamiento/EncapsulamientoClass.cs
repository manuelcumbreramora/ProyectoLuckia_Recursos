﻿using System;

namespace Encapsulamiento
{
    public class EncapsulamientoClass
    {
        private int multiplicadorPrivado;

        private int valorExtra;
        public void metodoPublico(int valorAleatorio, int aforo)
        {
            //Llamada con condiciones segun el valoAleatorio
            metodoProtegido(valorAleatorio, aforo);
        }

        protected void metodoProtegido(int valorAleatorio, int aforo)
        {
            //Calculos
            aforo = aforo - valorAleatorio;
        }
    }
}
