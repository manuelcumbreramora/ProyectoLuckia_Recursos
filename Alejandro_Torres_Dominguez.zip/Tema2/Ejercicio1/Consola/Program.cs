﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Negocio;
/*
Ejercicio 1-> 
Crear solución de consola, con tres proyectos: Consola, Negocio y Datos
Simular un guardado de usuario, donde desde consola se inserten los datos, se pasen a negocio y negocio los pase a
Datos, que será el que finalmente los guardará*/
namespace Consola
{
    class Program
    {
        static void Main(string[] args)
        {
            string nombre;
            int edad;
            bool correcto = false;
            while (!correcto)
            {
                try
                {

                    Console.WriteLine("Introduzca el nombre del usuario");
                    nombre = Console.ReadLine();
                    Console.WriteLine("Introduzca la edad");
                    edad = int.Parse(Console.ReadLine());
                    
                    negocio n = new negocio();
                    n.procesaNG(nombre, edad);
                    correcto = true;
                }
                catch (FormatException)
                {
                    Console.Error.WriteLine("La edad no tiene un formato adecuado");
                }
            }

            Console.ReadKey();
        }
    }
}
