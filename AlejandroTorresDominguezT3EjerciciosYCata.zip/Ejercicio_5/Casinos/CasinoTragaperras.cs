﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ejercicio_5.Juego;

namespace Ejercicio_5.Casinos
{
    public class CasinoTragaperras : IJugar
    {
        public void Jugar()
        {
            int rueda1, rueda2, rueda3;
            Console.WriteLine("Empiezan a girar las ruedas");
            Random r = new Random();
            rueda1 = r.Next(1, 3);
            rueda2 = r.Next(1, 3);
            rueda3 = r.Next(1, 3);
            Console.WriteLine("Rueda 1: {0}",rueda1);
            Console.WriteLine("Rueda 2: {0}", rueda2);
            Console.WriteLine("Rueda 3: {0}", rueda3);
            if (rueda1==rueda2 && rueda2 == rueda3)
            {
                Console.WriteLine("Enhorabuena has ganado");
            }
            else
            {
                Console.WriteLine("Lo siento, has perdido, mas suerte la proxima");
            }
        }
    }
}
