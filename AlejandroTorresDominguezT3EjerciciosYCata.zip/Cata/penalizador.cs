﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cata
{
    public abstract class Penalizador
    {
        public virtual void penalizar(int tipo)
        {
            Console.WriteLine("Expulsado");
        }
    }
}
