﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InterfaceEvento
{
    interface IEvento
    {
        int generarPuntos();
        string generarApuestaCorrecta();
        string generarApuestaUsuario();
    }
}
