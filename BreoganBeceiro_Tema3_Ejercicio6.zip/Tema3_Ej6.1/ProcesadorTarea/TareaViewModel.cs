﻿//BreoBeceiro:25/03/2020
//PLEXUS | Tema3

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Consola
{
    public class TareaViewModel
    {
        public int Id { get; set; }
        public string NombreUsuario { get; set; }
        public string Title { get; set; }
    }
}
