﻿using System;
using IFiguraSpace;
using RectanguloSpace;

namespace CuadradoSpace
{
    public class Cuadrado : Rectangulo
    {
        private int Lado1 { get; set; }

        public Cuadrado(int lado1) : base(lado1, lado1)
        {
            Lado1 = lado1;
        }
        public override int Area()
        {
            return (Lado1 * Lado1);
        }

        public override int Perimetro()
        {
            return (Lado1 * 4);
        }
    }
}
