﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PointsCalculator
{
    public abstract class AbstractPointsCalculator : IPointsCalculator
    {
        // The sport id.
        private string id;        

        public AbstractPointsCalculator(string id)
        {
            this.id = id;
        }

        public static float calculateAmount(float points)
        {
            return 15f * points;
        }

        public abstract float calculatePoints(params string[] args);
    }
}
