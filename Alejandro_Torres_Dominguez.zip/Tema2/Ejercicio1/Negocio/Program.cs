﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Datos;

namespace Negocio
{
    public class negocio
    {
        public void procesaNG(string nombre,int edad)
        {
            Dato d = new Dato();
            d.procesaDT(nombre, edad);
        }
    }
}
