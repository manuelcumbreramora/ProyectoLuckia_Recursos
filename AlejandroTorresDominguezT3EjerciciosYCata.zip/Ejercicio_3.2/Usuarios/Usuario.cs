﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_3._2
{
    abstract class Usuario
    {
        protected Usuario()
        {

        }

        protected Usuario(string nombre, string contra)
        {
            Nombre = nombre;
            Contra = contra;
        }

        private string Nombre { get; set; }
        private string Contra { get; set; }

    }
}
