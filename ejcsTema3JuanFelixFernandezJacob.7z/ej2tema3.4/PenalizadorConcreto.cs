﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ej2tema3._4
{
    class PenalizadorConcreto : Penalizador
    {
        internal override void Penalizar(Jugador p, Juego juego, TipoPenalizacion tipo)
        {
            if (tipo == TipoPenalizacion.Tipo1)
            {
                // Penalización para este tipo de penalización en el juego.
                if (juego is Futbol)
                {
                    // Penalizacion en fútbol
                    p.CambiarPuntos(-1000);
                }
                else if (juego is Balonmano)
                {
                    // Penalizacion en balonmano
                    p.CambiarPuntos(-3000);
                }
                else
                {
                    // Lllamamos a la penalización por omisión
                    base.Penalizar(p, juego, tipo);
                }
            }
            else if (tipo == TipoPenalizacion.Tipo2)
            {
                // Dejamos el que hay
                base.Penalizar(p, juego, tipo);
            }
            else if (tipo == TipoPenalizacion.Tipo3)
            {
                if (juego is Futbol)
                {
                    // Penalizacion en fútbol
                    p.CambiarPuntos(-4000);
                }
                else if (juego is Balonmano)
                {
                    // Penalizacion en balonmano
                    p.CambiarPuntos(-7000);
                }
                else
                {
                    // Lllamamos a la penalización por omisión
                    p.CambiarPuntos(-6000);
                }
            }
        }
    }
}
