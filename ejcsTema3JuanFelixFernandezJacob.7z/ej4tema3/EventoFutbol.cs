﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ej4tema3
{
    class EventoFutbol : IEvento
    {

        // Los equipos participantes en la quiniela.
        public String[,] Participantes { get; set; } = new String[15, 2] ;

        // Los equipos participantes en el resultado;
        public String LocalResultado, VisitanteResultado;

        private readonly Random Rand = new Random();

        private ResultadoFutbol Resultado = null;

        public void SetResultado(ResultadoFutbol resultado)
        {
            this.Resultado = resultado;
        }

        public Resultado ObtenerResultado()
        {
            return Resultado;
        }

        public void SimularResultado()
        {
            ResultadoFutbol resultado = new ResultadoFutbol();

            resultado.GolesLocal = (UInt16)Rand.Next(3);
            resultado.GolesVisitante = (UInt16)Rand.Next(3);

            for (int i=0;i<15; i++)
            {
                switch (Rand.Next(3))
                {
                    case 0:
                        resultado.RellenoQuiniela[i] = ResultadoFutbol.ValorCasilla.Uno;
                        break;
                    case 1:
                        resultado.RellenoQuiniela[i] = ResultadoFutbol.ValorCasilla.Equis;
                        break;
                    default:
                        resultado.RellenoQuiniela[i] = ResultadoFutbol.ValorCasilla.Dos;
                        break;
                }
            }
            
        }
    }
}
