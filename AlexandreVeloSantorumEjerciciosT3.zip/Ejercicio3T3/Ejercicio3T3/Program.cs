﻿using System;
using GeneradorSpace;
using RectanguloSpace;
using TrianguloSpace;
using CuadradoSpace;

namespace Ejercicio3T3
{
    class Program
    {
        static void Main(string[] args)
        {
            Rectangulo r = Generador.GenerarRectangulo();
            Triangulo t = Generador.GenerarTriangulo();
            Cuadrado c = Generador.GenerarCuadrado();
            Console.WriteLine("Figuras generadas por la clase estatica Generador");
            Console.WriteLine("Areas (Rectangulo, Triangulo, Cuadrado): "+ r.Area() + ", " + t.Area() + ", "+ c.Area());
            Console.WriteLine("Perimetro (Rectangulo, Triangulo, Cuadrado): " + r.Perimetro() + ", " + t.Perimetro() + ", " + c.Perimetro());
            Console.WriteLine("Necesito el lado 1 del Rectangulo");
            int lado1r = Int32.Parse(Console.ReadLine());
            Console.WriteLine("Necesito el lado 2 del Rectangulo");
            int lado2r = Int32.Parse(Console.ReadLine());
            Rectangulo ru = new Rectangulo(lado1r, lado2r);
            Console.WriteLine("Necesito el lado del Triangulo Equilatero");
            int ladot = Int32.Parse(Console.ReadLine());
            Triangulo tu = new Triangulo(ladot);
            Console.WriteLine("Necesito el lado del Cuadrado");
            int ladoc = Int32.Parse(Console.ReadLine());
            Cuadrado cu = new Cuadrado(ladoc);
            Console.WriteLine("Figuras generadas por el usuario");
            Console.WriteLine("Areas (Rectangulo, Triangulo, Cuadrado): " + ru.Area() + ", " + tu.Area() + ", " + cu.Area());
            Console.WriteLine("Perimetro (Rectangulo, Triangulo, Cuadrado): " + ru.Perimetro() + ", " + tu.Perimetro() + ", " + cu.Perimetro());
        }
    }
}
