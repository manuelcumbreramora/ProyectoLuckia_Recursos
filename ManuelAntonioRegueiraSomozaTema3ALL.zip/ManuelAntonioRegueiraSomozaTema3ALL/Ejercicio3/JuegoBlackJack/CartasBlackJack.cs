﻿using JuegoCartas;
using OperacionesGeneracionAleatorias;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JuegoBlackJack
{
    public class CartasBlackJack:Cartas
    {
        private String Crupier;


        public CartasBlackJack(int numCartas, string crupier,string nombreJuego)
        {
            NumeroCartas = numCartas;
            Crupier = crupier;
            NombreJuego = nombreJuego;
        }

        public void MostrarDetallesDatosJuego()
        {
            this.MostrarDatosJuego();
            Console.WriteLine("Nombre de Crupier{0}", this.Crupier);
        }

    }
}
