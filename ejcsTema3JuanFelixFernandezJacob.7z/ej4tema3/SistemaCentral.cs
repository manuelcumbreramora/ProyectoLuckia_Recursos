﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ej4tema3
{
    class SistemaCentral
    {
        public static void RealizarAbonos(Apuesta[] apuestas)
        {
            for (int i=0; i<apuestas.Length; i++)
            {
                Apuesta apuesta = apuestas[i];
                int puntosGanados=apuesta.CalcularPuntosGanados();

                int eurosGanados = puntosGanados * 15;

                Jugador jugador = apuesta.Jugador;

                jugador.Ingresar(eurosGanados);
            }
        }
    }
}
