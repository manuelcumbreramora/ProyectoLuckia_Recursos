﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio3._2
{
    class Conductor
    {
        protected iVehiculos vehiculos;
        public Conductor(iVehiculos _vehiculos)
        {
            this.vehiculos = _vehiculos;
        }

        public string Conducir()
        {
            return this.vehiculos.Conducir();
        }
    }
    
        
}
