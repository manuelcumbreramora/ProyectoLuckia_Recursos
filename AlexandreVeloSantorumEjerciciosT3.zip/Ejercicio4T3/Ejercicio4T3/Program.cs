﻿using System;
using JugadorClase;

namespace Ejercicio4T3
{
    class Program
    {
        static void Main(string[] args)
        {
            Jugador j = new Jugador();
            j.generarApuesta();
        }
    }
}
