﻿using System;
using IFiguraSpace;

namespace RectanguloSpace
{
    public class Rectangulo : IFigura
    {
        private int Lado1 { get; set; }
        private int Lado2 { get; set; }
        public Rectangulo(int lado1, int lado2)
        {
            Lado1 = lado1;
            Lado2 = lado2;
        }

        public virtual int Area()
        {
            return (Lado1 * Lado2);
        }

        public virtual int Perimetro()
        {
            return (Lado1 * 2) + (Lado2 * 2);
        }
    }
}
