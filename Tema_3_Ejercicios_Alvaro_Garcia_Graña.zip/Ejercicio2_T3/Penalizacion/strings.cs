﻿namespace Penalizacion
{
    public class strings
    {
    }
}