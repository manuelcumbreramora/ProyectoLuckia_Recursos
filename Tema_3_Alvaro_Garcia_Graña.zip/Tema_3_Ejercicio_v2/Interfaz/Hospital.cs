﻿using System;

namespace Interfaces
{
    public class Hospital
    {
        public interface InterfazMedico
        {
            string operarPaciente(Medico medico);
        }

        public interface InterfazCirujano
        {
            string operarPaciente(Cirujano cirujano);
        }

    }
    
}
