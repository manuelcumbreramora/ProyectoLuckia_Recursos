﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio2
{
    public abstract class Penalizador
    {
        public virtual void penalizar(int tipo,Jugador jugador)
        {
            Console.WriteLine("Expulsado");
        }
    }
}
