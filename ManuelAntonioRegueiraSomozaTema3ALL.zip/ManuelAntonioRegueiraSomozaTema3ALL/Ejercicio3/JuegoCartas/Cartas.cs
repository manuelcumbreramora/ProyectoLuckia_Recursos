﻿using OperacionesGeneracionAleatorias;
using ProyectoInterfazJuego;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JuegoCartas
{
    public class Cartas : IJuegoCasino
    {
        protected int NumeroCartas;
        protected string NombreJuego;


        public Cartas()
        {

        }
        public Cartas(int numCartas, string nombreJuego)
        {
            NombreJuego = nombreJuego;
            NumeroCartas = numCartas;
        }
        public void Apostar(int valorApuesta)
        {
            Console.WriteLine("Apostando {0} a juego de Cartas {1}", valorApuesta, this.NombreJuego);
        }

        public void Jugar()
        {
            int valorAleatorio = AleatorioBasico.generarAleatorioBasico();
            Console.WriteLine("Jugando a juego de Cartas {0}, Valor aleatorio {1}", this.NombreJuego, valorAleatorio);
        }

        public void MostrarDatosJuego()
        {
            Console.WriteLine("Nombre Juego Cartas {0}", this.NombreJuego);
            Console.WriteLine("Numero de Cartas  {0}", this.NumeroCartas);
        }
    }
}
