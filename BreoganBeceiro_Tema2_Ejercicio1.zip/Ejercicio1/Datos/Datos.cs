﻿//BreoBeceiro:18/03/2020
//PLEXUS | Tema2

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NS_Negocio;

namespace NS_Datos
{
    public class Datos
    {
        public static bool conectaBBDD()
        {
            //Método que automatiza la conexión con la BBDD

            return true;
        }

        //Recibe el objeto Usuario de Negocio y lo guarda...
        public bool guardaUsuario(Usuario user)
        {
            try
            {
                //Se abre la conexión
                Datos.conectaBBDD();
            }
            catch (Exception e)
            {
                //Tratamiento de excepciones (si las hay)
            }
            finally
            {
                //Cierre de la conexión con la BBDD
            }
            return true;
        }
    }
}
