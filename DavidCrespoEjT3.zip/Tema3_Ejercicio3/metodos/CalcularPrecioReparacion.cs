﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ejercicio3
{
    public static class CalcularPrecioReparacion
    {
       

        public static int CalcularPrecioRep(int anio)
        {
            int costeReparacion;
            costeReparacion = anio * 100;
            return costeReparacion;
        }




    }
}
