﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3Ej3
{
    class Cuadrado : FiguraGeometrica, IPoligonoRegular
    {
        int lados { get; set; }
        int largo { get; set; }

        public Cuadrado(int lados, int largo)
        {
            this.lados = lados;
            this.largo = largo;
        }

        public int NumeroLados()
        {
            return lados;
        }

        public int LargoLados()
        {
            return largo;
        }
    }
}
