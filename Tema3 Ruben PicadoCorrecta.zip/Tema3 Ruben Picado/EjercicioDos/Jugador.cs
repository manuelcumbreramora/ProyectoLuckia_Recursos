﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioDos
{
    class Jugador: Persona
    {
        public int monedero { get; set; }

        public int monederoActual()
        {
            var ran = new Random();
            monedero = ran.Next(100, 1000);
            Console.WriteLine("Su saldo es de : " + monedero);
            Console.ReadLine();
            return monedero;
        }
        
        
    }
}
