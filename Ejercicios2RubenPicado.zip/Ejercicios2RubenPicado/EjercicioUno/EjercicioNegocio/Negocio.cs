﻿using System;
using EjercicioUno;


namespace EjercicioNegocio
{
    public class Negocio
    {
        public void recogerDatos(string user, string pass)
        {
            Datos datos;
            datos = new Datos;
            System.Console.WriteLine("Tu usuario y tu pass han sido enviadas);
             datos.recogerDatos(user, pass);
        }
    }
}
