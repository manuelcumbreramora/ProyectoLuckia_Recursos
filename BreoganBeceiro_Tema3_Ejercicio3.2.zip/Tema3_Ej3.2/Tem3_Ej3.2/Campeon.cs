﻿//BreoBeceiro:24/03/2020
//PLEXUS | Tema3

//Los arrays en C# son como en VB, su dimensión es fija. Las listas, en cambio, son más flexibles en ese sentido,
//  pues se les puede añadir y quitar elementos sin provocar problemas derivados de su dimensión.
//Las listas se definen con List<tipoDatos> nombreLista.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ej3
{
    public class Campeon : Jugador
    {
        public int victoriasMagistrales { get; set; }
        public List<string> privilegios { get; set; }

        public Campeon(string user, string password, List<string> _privileges) : base(user, password)
        {
            this.usuario = user;
            this.contrasena = password;
            this.privilegios = _privileges;
        }

        /// <summary>
        /// Añade un elemento a la Lista de privilegios del jugador Campeón.
        /// </summary>
        /// <param name="victorias">El número de victorias del Jugador. Si éste es menor de 50, no es un Campeón.</param>
        /// <param name="privilegio">El privilegio a añadir a la Lista.</param>
        /// <returns></returns>
        public bool nuevoPrivilegio(int victorias, string privilegio)
        {
            if (victorias < 50)
            {
                return false;
            }
            else if(victorias >50 && victorias < 70)
            {
                //Añade privilegio al Array privilegios...
                privilegios.Add(privilegio);
            }
            else
            {
                return false;
            }

            return true;
        }

        public bool participa(int a)
        {
            Console.WriteLine("El jugador " + this.usuario + " está jugando y utiliza el privilegio "+this.privilegios[a]+".");
            return true;
        }
    }
}
