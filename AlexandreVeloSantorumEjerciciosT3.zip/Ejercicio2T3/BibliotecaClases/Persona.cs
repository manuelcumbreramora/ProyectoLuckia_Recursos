﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BibliotecaClases
{
    public class Persona
    {

        public string Nombre { get; set; }
        public int Edad { get; set; }
        public bool Suscripcion { get; set; }

        public Persona()
        {

        }
        public Persona(Persona p)
        {

        }

        public void realizarSuscripcion(string nombre, int edad)
        {
            Nombre = nombre;
            Edad = edad;
            Suscripcion = true;
            Console.WriteLine("Suscripción realizada");
        }
    }
}
