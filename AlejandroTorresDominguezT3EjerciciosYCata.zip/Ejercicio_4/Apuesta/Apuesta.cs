﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_4
{
    public class Apuesta
    {
        public IEvento evento { get; set; }
        public Apuesta(IEvento _evento)
        {
            this.evento = _evento;
        }
    }
}
