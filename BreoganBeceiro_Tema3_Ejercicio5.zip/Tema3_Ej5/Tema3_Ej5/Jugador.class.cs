﻿//BreoBeceiro:24/03/2020
//PLEXUS | Tema3

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ej5
{
    public class Jugador
    {
        public string nombre { get; set; }
        public string apellidos { get; set; }
        private string identificador { get; set; }
        public ICasino juego { get; set; }

        public Jugador() { }

        public Jugador(string name, string surname, ICasino play)
        {
            this.nombre = name;
            this.apellidos = surname;
            this.juego = play;
        }

        public void jugando()
        {
            //Juega en el Casino X...
            juego.juega();
        }
    }
}
