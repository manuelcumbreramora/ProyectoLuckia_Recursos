﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BetEvents
{
    public abstract class AbstractBetEvent : IResultReporter
    {
        // The event id.
        public int id { get; }

        public DateTime date { get; }

        // A string like "football", "f1", "nascar" ... taken from a given enum.
        public string sport { get; }

        public Bettor.Bettor bettor { get; }

        public AbstractBetEvent(int id, DateTime date, string sport, Bettor.Bettor bettor)
        {
            this.id = id;
            this.date = date;
            this.sport = sport;
            this.bettor = bettor;
        }

        public abstract string[] reportResult();

        public abstract string resultHumanReadable(string[] result);
    }
}
