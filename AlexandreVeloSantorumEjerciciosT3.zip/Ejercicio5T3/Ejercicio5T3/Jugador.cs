﻿using System;
using System.Collections.Generic;
using System.Text;
using CasinoCartasClase;
using CasinoEntretenimientolase;
using CasinoMonedaClase;

namespace Ejercicio5T3
{
    class Jugador
    {
        CasinoMoneda cm = new CasinoMoneda();
        CasinoCartas cc = new CasinoCartas();
        CasinoEntretenimiento ce = new CasinoEntretenimiento();
        private int Monedero { get; set; }
        public void realizarApuestaMoneda()
        {
            Console.WriteLine("Vas a realizar una apuesta en el juego de monedas. Escoge cantidad");
            string apuesta = Console.ReadLine();
            Console.WriteLine("Escoge un lado de la moneda");
            Console.WriteLine("1. Cara");
            Console.WriteLine("2. Cruz");
            Console.WriteLine("Elige una opción (1 o 2): ");
            string ladoMonedaUsuario = Console.ReadLine();
            Monedero += cm.jugar(ladoMonedaUsuario, apuesta);
            Console.WriteLine("Despues de la apuesta realizada en la moneda. Tú monedero se queda a " + Monedero);
        }

        public void realizarApuestaCarta()
        {
            Console.WriteLine("Vas a realizar una apuesta en el juego de cartas. Escoge cantidad");
            string apuesta = Console.ReadLine();
            Console.WriteLine("Escoge un número del 1 al 12");
            string numeroUsuario = Console.ReadLine();
            Monedero += cc.jugar(numeroUsuario, apuesta);
            Console.WriteLine("Despues de la apuesta realizada en las cartas. Tú monedero se queda a " + Monedero);
        }

        public void realizarApuestaEntretenimiento()
        {
            Console.WriteLine("Vas a realizar una apuesta al partido. Escoge cantidad");
            string apuesta = Console.ReadLine();
            Console.WriteLine("Escoge un resultado para el partido Madrid-Barça (1/X/2):");
            string apuestaUsuario = Console.ReadLine();
            Monedero += ce.jugar(apuestaUsuario, apuesta);
            Console.WriteLine("Despues de la apuesta realizada en el partido. Tú monedero se queda a " + Monedero);
        }
    }
}
