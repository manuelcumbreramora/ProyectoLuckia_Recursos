﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CasinoInterfaz
{
    interface ICasino
    {
        string resolverCasino();
        int jugar(string apuestaUsuario, string cantidad);
    }
}
