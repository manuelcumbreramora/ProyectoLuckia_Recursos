﻿using System;

namespace Base
{
    public class Monedero
    {
        public int saldo { get; set; }
        public int importeApostado { get; set; }
        public int importeGanancia { get; set; }

        public virtual void GuardarSaldo(int saldoIngreso, Jugador jugador, int importe)
        {
            jugador.monedero.saldo = saldoIngreso;
            jugador.monedero.importeApostado = importe;
        }

        public void calcularGananciaApuesta(Jugador jugador, int parametroApuesta)
        {
            if (parametroApuesta < 20)
            {
                jugador.monedero.importeGanancia = jugador.monedero.importeApostado * 2;
                jugador.monedero.saldo = jugador.monedero.saldo + jugador.monedero.importeGanancia;
            }
            else
            {
                jugador.monedero.saldo = jugador.monedero.saldo - jugador.monedero.importeApostado;
            }
        }
    }
}
