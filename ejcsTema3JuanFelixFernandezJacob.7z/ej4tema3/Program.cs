﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ej4tema3
{
    class Program
    {
        static void Main(string[] args)
        {

            EventoFutbol quiniela = new EventoFutbol();

            Jugador jose = new Jugador("José", "1828 1818 1818 1818 1818");

            Jugador maria = new Jugador("María", "1828 1818 1818 1818 1819");

            ResultadoFutbol resultadoJose = new ResultadoFutbol();
            resultadoJose.GolesLocal = 2;
            resultadoJose.GolesVisitante = 0;

            resultadoJose.RellenoQuiniela[0] = ResultadoFutbol.ValorCasilla.Uno;
            resultadoJose.RellenoQuiniela[1] = ResultadoFutbol.ValorCasilla.Dos;
            resultadoJose.RellenoQuiniela[2] = ResultadoFutbol.ValorCasilla.Uno;
            resultadoJose.RellenoQuiniela[3] = ResultadoFutbol.ValorCasilla.Uno;
            resultadoJose.RellenoQuiniela[4] = ResultadoFutbol.ValorCasilla.Uno;
            resultadoJose.RellenoQuiniela[5] = ResultadoFutbol.ValorCasilla.Uno;
            resultadoJose.RellenoQuiniela[6] = ResultadoFutbol.ValorCasilla.Uno;
            resultadoJose.RellenoQuiniela[7] = ResultadoFutbol.ValorCasilla.Uno;
            resultadoJose.RellenoQuiniela[8] = ResultadoFutbol.ValorCasilla.Uno;
            resultadoJose.RellenoQuiniela[9] = ResultadoFutbol.ValorCasilla.Uno;
            resultadoJose.RellenoQuiniela[10] = ResultadoFutbol.ValorCasilla.Uno;
            resultadoJose.RellenoQuiniela[11] = ResultadoFutbol.ValorCasilla.Equis;
            resultadoJose.RellenoQuiniela[12] = ResultadoFutbol.ValorCasilla.Uno;
            resultadoJose.RellenoQuiniela[13] = ResultadoFutbol.ValorCasilla.Uno;
            resultadoJose.RellenoQuiniela[14] = ResultadoFutbol.ValorCasilla.Uno;

            ResultadoFutbol resultadoMaria = new ResultadoFutbol();
            resultadoMaria.GolesLocal = 0;
            resultadoMaria.GolesVisitante = 1;

            resultadoMaria.RellenoQuiniela[0] = ResultadoFutbol.ValorCasilla.Uno;
            resultadoMaria.RellenoQuiniela[1] = ResultadoFutbol.ValorCasilla.Dos;
            resultadoMaria.RellenoQuiniela[2] = ResultadoFutbol.ValorCasilla.Uno;
            resultadoMaria.RellenoQuiniela[3] = ResultadoFutbol.ValorCasilla.Uno;
            resultadoMaria.RellenoQuiniela[4] = ResultadoFutbol.ValorCasilla.Uno;
            resultadoMaria.RellenoQuiniela[5] = ResultadoFutbol.ValorCasilla.Uno;
            resultadoMaria.RellenoQuiniela[6] = ResultadoFutbol.ValorCasilla.Uno;
            resultadoMaria.RellenoQuiniela[7] = ResultadoFutbol.ValorCasilla.Uno;
            resultadoMaria.RellenoQuiniela[8] = ResultadoFutbol.ValorCasilla.Uno;
            resultadoMaria.RellenoQuiniela[9] = ResultadoFutbol.ValorCasilla.Uno;
            resultadoMaria.RellenoQuiniela[10] = ResultadoFutbol.ValorCasilla.Uno;
            resultadoMaria.RellenoQuiniela[11] = ResultadoFutbol.ValorCasilla.Equis;
            resultadoMaria.RellenoQuiniela[12] = ResultadoFutbol.ValorCasilla.Uno;
            resultadoMaria.RellenoQuiniela[13] = ResultadoFutbol.ValorCasilla.Uno;
            resultadoMaria.RellenoQuiniela[14] = ResultadoFutbol.ValorCasilla.Uno;

            List<Apuesta> apuestas = new List<Apuesta>();
            apuestas.Add(new ApuestaFutbol(100, quiniela, resultadoJose, jose));
            apuestas.Add(new ApuestaFutbol(90, quiniela, resultadoMaria, maria));

            quiniela.SimularResultado();

            Console.WriteLine("Simulando resultado:");
            SistemaCentral.RealizarAbonos(apuestas.ToArray());

            Console.WriteLine("Ahora probamos con un acierto: ");
            quiniela.SetResultado(resultadoMaria);
            SistemaCentral.RealizarAbonos(apuestas.ToArray());
        }
    }
}
