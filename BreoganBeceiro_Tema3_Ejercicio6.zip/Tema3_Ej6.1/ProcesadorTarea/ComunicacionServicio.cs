﻿//BreoBeceiro:25/03/2020
//PLEXUS | Tema3

//ESTA CLASE CONTIENE LOS 3 MÓDULOS QUE SE DERIVAN DEL SCRIPT INICIAL DEL EJERCICIO.
//DE LOS MÓDULOS SE INDICA, PRIMERO, LA SIGNATURA (PRECEDIDA ÉSTA POR EL TIPO DE VALOR DEVUELTO) Y
//  A CONTINUACIÓN SE DESCRIBEN LOS ARGUMENTOS Y EL VALOR DEVUELTO.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Net.Http;

namespace Consola
{
    public static class ComunicacionServicio
    {
        // List|Array conectaServicioAsinc(URL)
        //   El argumento URL es la dirección del servicio web de la que se extrae el JSON.
        //   Devuelve 'tareas' (una lista, colección o matriz de elementos obtenidos del JSON).


        // bool creaListaTareasParaHacer(TAREAS)
        //   El argumento TAREAS es un dato de tipo List o Array que contiene los elementos obtenidos del JSON.
        //   Este método convierte el tipo JSON en List, Array o Enumerable.
        //   Devuelve TRUE o FALSE dependiendo de si consigue generar la lista de tareas o no.


        // bool escribeTareas()
    }
}
