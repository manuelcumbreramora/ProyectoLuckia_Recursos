﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kata3Eloy
{
    public partial class MenuPrincipal : Form
    {
        private string nombre;

        public MenuPrincipal()
        {
            InitializeComponent();

           

            
            lblUsuario.Text = Usuario.Nombre;
            lblCartera.Text = Convert.ToString(Monedero.Cartera);
        }

       

        public string Nombre { get => nombre; set => nombre = value; }

        private void btnCargar_Click(object sender, EventArgs e)
        {
            RecargaSaldo rs = new RecargaSaldo();

            this.Hide();

            rs.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();


         

            Formularios.SeleccionJuego sj = new Formularios.SeleccionJuego();

            sj.ShowDialog();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();




            Formularios.Historico hs = new Formularios.Historico();

            hs.ShowDialog();
        }
    }
}
