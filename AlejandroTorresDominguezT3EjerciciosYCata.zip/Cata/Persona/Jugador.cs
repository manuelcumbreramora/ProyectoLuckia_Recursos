﻿/*Luckia necesita implementar su nuevo proceso de apuestas OnLine.Para ello, se especifica lo siguiente.
 * El Jugador, debe autenticarse en la plataforma, y, debe llenar su monedero para poder realizar las apuestas.
Sólo si tiene cash en su monedero, se le permitirá ver el listado de los eventos disponibles (Fútbol, Baloncesto, F1).
Podrá realizar las apuestas que quiera, y a los eventos que quiera.
El sistema automático de apuestas de Luckia, identificará las apuestas, las procesará, evaluará los resultados y hará el ingreso en caso de acierto.
El usuario, podrá revisar sus apuestas, consultando su historial.

Se pide implementar Clases e Interfaces necesarias, aplicando correctamente herencia y respetando los conceptos de cohesión y bajo acoplamiento
y principio de única responsabilidad*/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cata
{
    public class Jugador : Usuario
    {
        public List<Apuesta> listaApuestas { get; set; }
        public Monedero monedero { get; set; }
        public Jugador(Monedero _monedero)
        {
            this.monedero = _monedero;
            this.listaApuestas = new List<Apuesta>();
        }
        
        public void Apostar(IEvento evento,int importe, int resultadoApostado)
        {
            if (monedero.comprobarCash() <= importe)
            {
                listaApuestas.Add(new Apuesta(importe, evento, resultadoApostado));
                Console.WriteLine("Apuesta correcta");
            }
            else
            {
                Console.WriteLine("No hay suficiente saldo para la apuesta");
            }
        }

        public void historialApuestas()
        {
            foreach (var apuesta in listaApuestas)
            {
                apuesta.mostrarApuesta();
            }
        }
    }
}
