﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Taxes;

namespace TaxCalculator
{
    public class RacingTaxCalculator : AbstractTaxCalculator
    {
        public RacingTaxCalculator() : base("football") { }

        // The only tax paid is the highest.
        // Additionaly, the total taxe cannot be greater than the 20% of the input amount.
        public override float calculateTotalTaxes(List<ITax> taxes, float amount)
        {
            float maxAmount = amount * 0.20f;

            float _amount = float.MinValue;
            foreach (AbstractTax item in taxes)
            {
                _amount = Math.Max(_amount, item.calculateTax(amount));
            }
            _amount = (_amount > maxAmount) ? maxAmount : _amount;

            return _amount;
        }
    }
}
