﻿//BreoBeceiro:23/03/2020
//PLEXUS | Tema3

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ej2
{
    public class Infraccion : Penalizador
    {
        public override void cuentaInfraccion()
        {
            string codigoJugador = "AA001";

            //Actualiza el registro de infracciones en la BBDD y añade una entrada al Log de infracciones con el
            //   método estático nuevaPenalizacion()...
            Registros.nuevaPenalizacion(codigoJugador);
        }

        /// <summary>
        /// Tramita la penalización por malas prácticas para las apuestas en tres deportes.
        /// </summary>
        /// <param name="deporte">Cadena de texto que indica el nombre del deporte.</param>
        /// <returns>TRUE si la penalización se efectúa con éxito o FALSE, si falla.</returns>
        public bool penaliza(string deporte)
        {
            deporte.ToLower();

            //Abstrayendo el método en una interfaz, esta estructura podría eliminarse y el código quedaría más abierto a cambios
            //  en el futuro (o ésos serían más sencillos de introducir):
            switch (deporte)
            {
                case "futbol":
                    //Lógica para la penalización propia de Fútbol...
                    break;
                case "balonmano":
                    //Lógica para la penalización propia de Balonmano...
                    break;
                case "boleibol":
                    //Lógica para la penalización propia de Boleibol...
                    break;
                default:
                    return false;
            }
            return true;
        }

    }
}
