﻿using System;

namespace ej4tema3
{
    public class Jugador
    {
        public Jugador(string nombre, string cuenta)
        {
            Nombre = nombre;
            Cuenta = cuenta;
        }

        public String Nombre { get; set; }

        public String Cuenta { get; set; }

        internal void Ingresar(int eurosGanados)
        {
            Console.WriteLine("Se ingresan " + eurosGanados + " al jugador " + Nombre + " en la cuenta " + Cuenta);
        }
    }
}