﻿/*Tenemos una aplicación que consulta un servicio que hace lo siguiente:
Devuelve un listado de tareas que un usuario necesita hacer. 
El listado de tareas sólo viene con el id del usuario, no con su nombre.
Consultar el servicio web para obtener los datos de los usuarios del sistema.
Unificar una lista de tareas sin realizar junto al nombre del usuario que debe realizarlas, escribiendo dichas tareas en un fichero txt.
Todo este proceso, es trazado en un log de errores/procesos.


Se pide aplicar el principio de única responsabilidad, separando las diferentes responsabilidades que se detecten
*/

using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Consola   
{
    public class ProcesadorTareas
    {
        public ProcesadorTareas()
        {
        }

        public async Task ProcesarTareas()
        {
            try{
                Usuario u = new Usuario();
                TareaViewModel tv = new TareaViewModel();
                await u.CrearTareasNoRealizadas();
                await u.CrearUsuarios();
                await tv.escribirTareas();

            }catch (IOException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    }







}
