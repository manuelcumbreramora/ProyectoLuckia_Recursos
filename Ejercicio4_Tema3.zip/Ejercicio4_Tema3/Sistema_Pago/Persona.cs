﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_Pago
{
    public abstract class Persona
    {
        public string nombre { get; set; }

        public Persona() { }
        public Persona(string nom, int edad)
        {
            this.nombre = nom;
        }
    }
}
