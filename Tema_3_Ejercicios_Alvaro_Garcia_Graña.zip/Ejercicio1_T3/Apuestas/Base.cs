﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Apuestas
{
    class Base
    {
        static void Main(string[] args)
        {
            Jugador jugador = new Jugador();
            jugador.nombre = "";
            jugador.edad = 0;
            while (jugador.nombre == "")
            {
                jugador.iniciarSesion(jugador);
            }
            
        }
    }

    class Jugador : Persona
    {
        private int bonus { get; set; }

        private int juegos { get; set; }

        public void iniciarSesion(Jugador jugador)
        {
            Console.WriteLine("Introduzca el nombre de usuario con el que desea jugar: ");
            String nombre = Console.ReadLine();
            Console.WriteLine("Introduzca su edad: ");
            int edad = int.Parse(Console.ReadLine());
            if (nombre != null && nombre != "" && edad >= 18)
            {
                jugador.realizarSubscripcion(nombre, edad, jugador);
                jugador.juegos = 0;
                string apuesta = "";
                while (apuesta != "*")
                {
                    Console.WriteLine("Pulse Enter para comenzar la apuesta o introduzca * para parar la apuesta:");
                    apuesta = Console.ReadLine();
                    apostar();
                    var random = new Random();
                    if (random.Next(0, 100) > 90)
                    {
                        Console.WriteLine("HAS GANADO EL GORDO!");
                    }
                    else
                    {
                        Console.WriteLine("MALA SUERTE, PRUEBE OTRA VEZ!");
                    }

                    Console.WriteLine("Llevas " + jugador.juegos + " juegos, " + jugador.nombre + ".");                }
                
            }
            else if(nombre == "" || nombre == null)
            {
                Console.WriteLine("No ha escrito ningún valor, porfavor introduzca un usuario.");
            }else if (edad < 18)
            {
                Console.WriteLine("No tienes edad suficiente para realizar apuestas. Get out!");
            }
        }
        public void apostar()
        {
            ///Declaramos un random para generar número aleatorio de bonos
            var random = new Random();
            //Sumamos un juego por cada apuesta
            juegos++;
            bonus = random.Next(10, 100);
        }
    }

    class Persona
    {
        public string nombre { get; set; }

        public int edad { get; set; }

        public void realizarSubscripcion(String nombre, int edad, Jugador jugador)
        {
            jugador.nombre = nombre;
            jugador.edad = edad;
        }
    }
}
