﻿namespace CargaArchivo
{
    partial class Archivos
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.sleep1 = new System.Windows.Forms.Timer(this.components);
            // 
            // sleep1
            // 
            this.sleep1.Enabled = true;
            this.sleep1.Interval = 10000;
            this.sleep1.Tick += new System.EventHandler(this.sleep1_Tick);
            // 
            // Archivos
            // 
            this.ServiceName = "Service1";

        }


        public System.Windows.Forms.Timer sleep1;
    }
}
