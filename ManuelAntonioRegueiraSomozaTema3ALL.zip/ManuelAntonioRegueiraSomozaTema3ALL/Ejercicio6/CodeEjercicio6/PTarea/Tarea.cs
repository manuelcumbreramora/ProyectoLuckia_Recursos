﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace PTarea
{
    public class Tarea
    {
        public int UserId { get; set; }
        public int Id { get; set; }
        public string Title { get; set; }
        public bool Completed { get; set; }

        public async Task<List<Tarea>> ProcesarTrabajoTarea(HttpClient client)
        {
            var urlTareas = "https://jsonplaceholder.typicode.com/todos";
            //conexión
            var respuestaTareas = await client.GetAsync(urlTareas);// abre hilo
            respuestaTareas.EnsureSuccessStatusCode();
            var cuerpoRespuestaTareas = await respuestaTareas.Content.ReadAsStringAsync();// cierra hilo tras recibir respues
            Console.WriteLine(cuerpoRespuestaTareas);

            var tareas = JsonConvert.DeserializeObject<Tarea[]>(cuerpoRespuestaTareas);
            return tareas.Where(x => !x.Completed).ToList();
        }

    }
}