﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ejercicio_5.Juego;

namespace Ejercicio_5.Casinos
{
    public class CasinoCartas : IJugar
    {
        public void Jugar()
        {
            int jug=0, banca = 0;
            Random r = new Random();
            Console.WriteLine("Empieza la partida de blackjack");
            do
            {
                jug += r.Next(1, 10);
                banca += r.Next(1, 10);
            } while (jug < 22 && banca < 22);
            Console.WriteLine("Acaba la partida. Jugador: {0} Banca: {1}",jug,banca);
            if (jug == 21)
            {
                Console.WriteLine("BlackJack, has ganado");
            }
            else
            {
                if (banca > 21)
                {
                    Console.WriteLine("Has ganado");
                }
                else
                {
                    if (jug > banca && jug < 21)
                    {
                        Console.WriteLine("Has ganado");
                    }
                    else
                    {
                        if (jug < banca && banca < 21)
                        {
                            Console.WriteLine("Lo siento, has perdido");
                        }
                        else
                        {
                            if (jug > 21)
                            {
                                Console.WriteLine("Lo siento, te has pasado");
                            }
                        }
                    }
                }
            }
        }
    }
}
