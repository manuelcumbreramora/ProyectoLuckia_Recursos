﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cata
{
    public class Apuesta
    {
        public int cantidad { get; set; }

        public IEvento evento { get; set; }

        public int resultadoapostado { get; set; }

        public Apuesta(int _cant, IEvento _even, int _resultado)
        {
            this.cantidad = _cant;
            this.evento = _even;
            this.resultadoapostado = _resultado;
        }

        public void mostrarApuesta()
        {
            Console.WriteLine("Evento: {0}",this.evento.devolverNombreEvento());
            Console.WriteLine("Cantidad: {0}", this.cantidad);
            Console.WriteLine("Evento: {0}", this.resultadoapostado);
        }
    }
}
