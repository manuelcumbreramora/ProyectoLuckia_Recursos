﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Consola
{
    class Program
    {
        static async Task Main(string[] args)
        {
            ProcesadorTareas procesadorTareas = new ProcesadorTareas();
            await procesadorTareas.Procesar();
        }
    }
}
