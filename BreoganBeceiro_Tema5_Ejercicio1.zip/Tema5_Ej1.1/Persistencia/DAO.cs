﻿//BreoBeceiro:30/03/2020
//PLEXUS | Tema5.1

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Persistencia
{
    public static class DAO
    {
        /// <summary>
        /// Almacena en la BBDD una nueva máquina del casino (INSERT INTO maquinas VALUES ...)...
        /// </summary>
        /// <param name="id">Código de la máquina.</param>
        /// <param name="tipo">Tipo o nombre de la máquina.</param>
        /// <param name="fechaLlegada">Fecha de llegada al casino.</param>
        /// <param name="origen">Fábrica o almacén de procedencia de la máquina.</param>
        /// <returns></returns>
        public static bool guardaMaquina(string id, string tipo, DateTime fechaLlegada, string origen)
        {
            return true;
        }

        /// <summary>
        /// Consulta a la BBDD los servicios contratados, coste incluído, por el casino.
        /// </summary>
        /// <returns>Una colección de valores asociativa corrspondiente a la lista.</returns>
        public static Dictionary<int, string> listaServicios(string cifCasino)
        {
            return null;
        }

        /// <summary>
        /// Ingresa en la BBDD una nueva tupla correspondiente con la incidencia enviada desde la Vista.
        /// </summary>
        /// <param name="nombre">El nombre o título de la incidencia.</param>
        /// <param name="descripcion">La descripción de la incidencia.</param>
        /// <returns></returns>
        public static bool registraIncidencia(string nombre, string descripcion)
        {
            return true;
        }

        /// <summary>
        /// Guarda en la BBDD la solicitud del casino.
        /// </summary>
        /// <returns>TRUE si la solicitud se guardó sin problemas o FALSE si hubo algún error.</returns>
        public static bool registraSolicitud(string _cifCasino, string _nombreCasinom, string _cpCasino)
        {
            return true;
        }

        public static bool guardaFactura(string _concepto, decimal _importe, DateTime _fecha)
        {
            //INSERT INTO facturas (Concepto, Importe, Fecha) VALUES (this.concepto, this.importe, this.fecha);
            return true;
        }

        public static void verFactura(string _num)
        {
            //Consulta a la BBDD y recupera la información de la factura de número correspondiente al del argumento de entrada...
        } 
    }
}
