﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio5
{
    class Program
    {
        static void Main(string[] args)
        {
            Jugar jug = new Jugar();
            jug.casinoMadrid();
            jug.casinoLugo();
            jug.casinoSevilla();
            Console.ReadKey();
        }
    }
}
