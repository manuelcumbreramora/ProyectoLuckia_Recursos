﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaDatos
{
    public class cParametros
    {
        //Declaro los parametro, si existiera base de datos se mandarian aquí.

        private string nombre;
        private string contraseña;
        private string mail;

        public cParametros(string nombre, string contraseña, string mail)
        {
            this.nombre = nombre;
            this.contraseña = contraseña;
            this.mail = mail;
        }

        //Acceso a los parametros
        public string Nombre { get => nombre; set => nombre = value; }
        public string Contraseña { get => contraseña; set => contraseña = value; }
        public string Mail { get => mail; set => mail = value; }
    }
}
