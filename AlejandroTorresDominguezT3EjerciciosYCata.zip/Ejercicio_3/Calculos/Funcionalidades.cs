﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_3
{
    static class Funcionalidades
    {
        public static double calculoNota(double nota, string tipo) {
            switch (tipo)
            {
                case "examen":
                    return nota * 0.6;
                    break;
                case "trabajos":
                    return nota * 0.3;
                    break;
            }
            return 0;
        }
        public static double calculoNota(double nota, int ponderacion)
        {
            return nota * (ponderacion / 10);
        }

        public static double calculoMedia(Array notas)
        {
            double suma = 0;
            foreach (double n in notas){
                suma += n;
            }
            return suma / notas.Length;
        }
        public static double notaFinal (double trabajos, double examen, double actitud)
        {
            return ((trabajos * 0.3) + (examen * 0.6) + actitud);
        }
    }
}
