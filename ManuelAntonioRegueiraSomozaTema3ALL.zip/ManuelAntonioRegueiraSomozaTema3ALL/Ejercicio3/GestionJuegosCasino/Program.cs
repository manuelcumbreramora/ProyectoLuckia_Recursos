﻿/*Diseñamos e implimentamos una aplicacion que permita gestionar varios tipos de juego y poder jugar.

Aplicamos interfaces en ProyectoInterfazJuego, donde implementamos interfaz IJuegoCasino, las clases JuegoCartas,JuegoMesa,
JuegoTragaperras.

Aplicamos herencia en clases JuegoTragaperrasMonedaUnica, JuegoTragaperrasMultiplicadora que ambas heredan de juegoTragaperras.

Aplicamos herencia en clases JuegoCartasBlackJack, JuegoCartasPoker que ambas heredan de JuegoCartas.

Aplicamos herencia en JuegoMesaRuletaAmericana, JuegoMesaRuletaEuropea, que ambas heredan de juegoMesa.

Tenemos un proyecto OperacionesGeneracionAleatorias, donde tenemos una clase estatica con un metodo estatico para generara datos 
aleatorios.

La encapsulación se aplica en cada una de las clases, ya que estan separadas por proyectos. pudiendo eliminar proyectos o agregando 
nuevos con indiferencia a otros proyectos que estan en la solución.

 
 */


using JuegoBlackJack;
using JuegoPoker;
using JuegoRuletaAmericana;
using JuegoRuletaEuropea;
using JuegoTragaperrasMonedaUnica;
using JuegoTragaperrasMultiplicadora;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionJuegosCasino
{
    class Program
    {
        static void Main(string[] args)
        {
            CartasBlackJack blackjack1 = new CartasBlackJack(42, "Alfonso","BlackJack");
            blackjack1.Apostar(10);
            blackjack1.Jugar();
            blackjack1.MostrarDetallesDatosJuego();
            Console.ReadLine();
            MesaRuletaAmericana ruleta1 = new MesaRuletaAmericana(1, 1,"Ruleta Americana");
            ruleta1.Apostar(10);
            ruleta1.Jugar();
            ruleta1.MostrarDetallesDatosJuego();
            Console.ReadLine();
            TragaperrasMonedaUnica tragaperras1 = new TragaperrasMonedaUnica(3, "Piratas", 2);
            tragaperras1.Apostar(10);
            tragaperras1.Jugar();
            tragaperras1.MostrarDetallesDatosJuego();
            Console.ReadLine();

        }
    }
}
