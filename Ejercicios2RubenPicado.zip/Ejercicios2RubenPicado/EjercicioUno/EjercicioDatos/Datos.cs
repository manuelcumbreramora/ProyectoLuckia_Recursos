﻿using System;
using EjercicioNegocio;


namespace EjercicioDatos

{
    public class Datos

    {
        public void recogerDatos(string user, string pass)
        {
            guardarUser(user, pass);
            System.Console.WriteLine(" Usuario y contrasea guardadp");

        }




    }
}
