﻿using Bets;
using CasinoGames;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Casino
{
    public abstract class AbstractCasino : IRouletteGame
    {
        public string Id { get; }

        public AbstractCasino(string id)
        {
            this.Id = id;
        }

        public abstract string[] GetRouletteNumberSequence();

        public abstract float calculateWinnerBetAmount(IBet bet);

        public virtual Tuple<Boolean, string> playRouletteBet(IBet bet)
        {
            string[] numbers = this.GetRouletteNumberSequence();
            Random rnd = new Random(Guid.NewGuid().GetHashCode());
            int index = rnd.Next(0, numbers.Length);

            string s = numbers[index];
            string _bet = bet.GetBet()[0];
            bool winner = _bet.Equals(s);

            return new Tuple<bool, string>(winner, s);
        }

    }
}
