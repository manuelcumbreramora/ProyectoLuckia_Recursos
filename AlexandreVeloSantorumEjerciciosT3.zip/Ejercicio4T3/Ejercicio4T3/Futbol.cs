﻿using System;
using System.Collections.Generic;
using System.Text;
using InterfaceEvento;

namespace FutbolClase
{
    class Futbol : IEvento
    {
        public int generarPuntos()
        {
            string apuestaUsuario = generarApuestaUsuario();
            string[] apuestasUsuario = apuestaUsuario.Split('/');
            string[] apuestaCorrecta = generarApuestaCorrecta().Split('/');
            int puntos = 0;

            if(apuestasUsuario[0] == apuestaCorrecta[0])
            {
                puntos += 200;
            }

            if(apuestasUsuario[1] == apuestaCorrecta[1])
            {
                puntos += 100;
            }

            return puntos;
        }

        public string generarApuestaCorrecta()
        {
            return "0-1/2";
        }

        public string generarApuestaUsuario()
        {
            string quiniela = "";
            while(quiniela != "X" && quiniela!= "1" && quiniela != "2")
            {
                Console.WriteLine("Apuesta al Madrid-Barça Quiniela (1/X/2)");
                quiniela = Console.ReadLine();
            }
            Console.WriteLine("Apuesta al Madrid-Barça Quiniela (X-X)");
            string resultado = Console.ReadLine();
            return resultado + "/" + quiniela;
        }
    }
}
