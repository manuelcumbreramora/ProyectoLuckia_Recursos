﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ej3v2tema3
{
    

    class SerializadorXML : ISerializador
    {

        private Stack<String> Entidades = new Stack<string>();

        public string AbrirLista()
        {
            return ""; // En XML no se usa nada para empezar lista.
        }

        public string Atributo(string nombre, string valor)
        {
            return "<" + nombre + ">" + valor + "</" + nombre + ">\n";
        }

        public string Atributo(string nombre, int valor)
        {
            return "<" + nombre + ">" + valor + "</" + nombre + ">\n";
        }

        public string Atributo(string nombre, double valor)
        {
            return "<" + nombre + ">" + valor + "</" + nombre + ">\n";
        }

        public string CerrarLista()
        {
            return ""; // En XML no se usa nada para empezar lista.
        }

        public string FinEntidad()
        {
            return "</" + Entidades.Pop() + ">\n";
        }

        public string InicioEntidad(string nombre)
        {
            Entidades.Push(nombre);
            return "<" + nombre + ">\n";
        }

        public String SeparadorLista()
        {
            return "";
        }
    }
}
