﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Eventos;
using Monedero;

namespace SistemaCentral
{
    class Base : SistemaCentralClass
    {
        
        static void Main(string[] args)
        {
            List<Apuesta> apuestas = new List<Apuesta>();
            SistemaCentralClass sistemaCentral = new SistemaCentralClass();
            sistemaCentral.GenerarApuestas(apuestas);
            Console.WriteLine("Bienvenido!");
            foreach (Apuesta apuesta in apuestas)
            {
                sistemaCentral.ComprobarApuesta(apuesta);
            }
            Console.WriteLine("Fin de las apuestas!");
            Console.ReadKey();
            
        }
    }
}
