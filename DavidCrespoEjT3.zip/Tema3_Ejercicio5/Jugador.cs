﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ejercicio5
{
    class Jugador
    {

         
        public Jugador(string nombre, int edad, int monedero)
        {
            this.nombre = nombre;
            this.edad = edad;
        }

        public Jugador()
        {
        }

        public String nombre { get; set; }
        public int edad { get; set; }

        public int monedero { get; set; }

        public int ingreso;


        public void realizarSuscripcion()
        {
            Console.WriteLine("Bienvenido a CasinoOnline");
            Console.WriteLine("Introduzca su nombre");
            nombre = Console.ReadLine();
            Console.WriteLine("Introduzca su edad");
            edad = Int16.Parse(Console.ReadLine());

        }

        public void cargaMonedero()
        {
            Console.WriteLine("Cuánto dinero quiere ingresar?");
            ingreso = Int16.Parse(Console.ReadLine());
            monedero = monedero + ingreso;
            Console.WriteLine("Su saldo actual es de " + monedero + " euros");

        }


        public void menu()
        {
            Console.WriteLine("A qué quieres jugar");
            Console.WriteLine("1: Ruleta");
            Console.WriteLine("2: Pares o nones");
            Console.WriteLine("3: Acierta la carta");
            Console.WriteLine("4: Quiero cargar mi monedero");
            Console.WriteLine("5: Log out");

        }

    }
}

