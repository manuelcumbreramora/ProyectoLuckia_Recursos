﻿//BreoBeceiro:25/03/2020
//PLEXUS | Tema3

//Los métodos de esta clase tendrían sentido en InteraccionBBDD.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Cata
{
    public class Monedero
    {
        public float cantidad { get; set; }
        public string usuario; 

        public Monedero(string user, float amount)
        {
            this.usuario = user;
            this.cantidad = amount;
        }
    }
}
