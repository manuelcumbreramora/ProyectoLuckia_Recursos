﻿//BreoBeceiro:30/03/2020
//PLEXUS | Tema5.1

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Persistencia;

namespace Negocio
{
    public static class Sistema
    {
        /// <summary>
        /// Comprueba las credenciales del usuario que quiera acceder a los servicios de root.
        /// </summary>
        /// <param name="_user">El nombre de usuario del administrador.</param>
        /// <param name="_passw">La contraseña del administrador.</param>
        public static void compruebaCredenciales(string _user, string _passw)
        {
            //De haber origen de datos, las credenciales se obtendrían de ahí para compararlas con las del formulario...
            if (_user == "Manuel" && _passw == "4321")
            {
                Console.Clear();
            }
            else
            {
                Environment.Exit(0);
            }
        }

        /// <summary>
        /// Este método devolvería una colección Dictionary o Lista de elementos que conforman la lista de servicios contratados por el casino.
        /// </summary>
        /// <param name="_casino">El objeto Casino del cual obtener el historial.</param>
        public static void servicios(Casino _casino)
        {
            DAO.listaServicios(_casino.cif);
        }
    }
}
