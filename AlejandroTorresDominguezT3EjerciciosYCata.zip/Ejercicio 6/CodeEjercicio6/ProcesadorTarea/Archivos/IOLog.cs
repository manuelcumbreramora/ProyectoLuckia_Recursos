﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Consola
{
    static class IOLog
    {
        public static void EscribirLog(string mensaje)
        {
            try
            {
                StreamWriter writetext = new StreamWriter($@"{Directory.GetCurrentDirectory()}\Log.txt") ;
                writetext.WriteLine(mensaje);
                writetext.Flush();
                writetext.Close();

            }
            catch (IOException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}