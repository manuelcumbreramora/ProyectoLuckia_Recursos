﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_Pago
{
    public class Atletismo : Deporte
    {
        public int puntos { get; set; }
        public Atletismo() { }
        public Atletismo(int points)
        {
            this.nombre = "Atletismo";
            this.puntos = points;
        }
    }
}
