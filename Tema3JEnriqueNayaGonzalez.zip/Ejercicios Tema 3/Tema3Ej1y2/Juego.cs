﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3Ej1
{
    class Juego
    {
        public Juego(string deporte)
        {
            this.deporte = deporte;
        }

        public String deporte { get; set; }

        
    }
}
