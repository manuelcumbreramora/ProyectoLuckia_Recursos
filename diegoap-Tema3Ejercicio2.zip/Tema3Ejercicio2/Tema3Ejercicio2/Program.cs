﻿using BettorPenalties;
using Games;
using Penalizations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Users;
using static BettorPenalties.AbstractPenalty;

namespace Tema3Ejercicio2
{
    class Program
    {
        static List<IBettor> bettors;

        static List<AbstractGame> availableGames;

        static List<IPenalty> penalties;

        static void Main(string[] args)
        {
            initData();

            bool exitApplication = false;
            do
            {
                int opt = showMainMenu();
                switch (opt)
                {
                    case 1:
                        showAllBettorsData();
                        break;
                    case 2:
                        showUserData();
                        break;
                    case 3:
                        showAvailableGames();
                        break;
                    case 4:
                        addPenalty();
                        break;
                    case 9:
                        exitApplication = true;
                        break;
                    default:
                        Console.WriteLine("*** Error, illegal option value.\n");
                        Console.Beep();
                        break;
                }
            } while (!exitApplication);
        }

        static void initData()
        {
            bettors = new List<IBettor>();
            bettors.Add(new Bettor(0, "John Doe", 200f, 0));
            bettors.Add(new Bettor(10, "Giovanni Buzzati"));
            bettors.Add(new Bettor(20, "Jean Baptiste Arbellot", 312.95f, 2));
            bettors.Add(new Bettor(30, "Enrique Guzmán", 50.25f, 0));
            bettors.Add(new Bettor(40, "Otto Steiner", 240.75f, 0));
            bettors.Add(new Bettor(50, "Alfred Erlander", 405.35f, 0));
            bettors.Add(new Bettor(60, "Felipe Acevedo", 95.05f, 0));
            bettors.Add(new Bettor(70, "Steve Harris"));
            bettors.Add(new Bettor(80, "Anna Arbuzov", 625.55f, 1));
            bettors.Add(new Bettor(80, "Mircea Cioran"));
            bettors.Add(new Bettor(90, "Isabel Sepúlveda", 2352.85f, 3));

            availableGames = new List<AbstractGame>() { new Basketball(), new Football(), new Racing() };

            penalties = new List<IPenalty>();
        }

        static int showMainMenu()
        {
            int opt = -1;

            Console.WriteLine("\n--- Main menu --- \n");
            Console.WriteLine("1. Show all users data.");
            Console.WriteLine("2. Show one user data.");
            Console.WriteLine("3. Show available games.");
            Console.WriteLine("4. Add penalization to a user.");
            Console.WriteLine("9. Exit program.");
            Console.WriteLine();

            bool done;
            char k;
            do
            {
                done = false;
                Console.Write("> ");
                k = Console.ReadKey().KeyChar;

                if (Char.IsDigit(k))
                {
                    done = int.TryParse((k + ""), out opt);
                }
            } while (!done);

            Console.WriteLine("");
            return opt;
        }

        static void showAllBettorsData()
        {
            Console.WriteLine("userId ;; name ;; wallet (amount) ;; num. strikes ;; num. penalties");

            int userId, numStrikes;
            string name;
            float wallet;
            List<IPenalty> userPenalties;
            foreach (IBettor item in bettors)
            {
                userId = item.GetId();
                name = item.GetName();
                wallet = item.GetWallet();
                numStrikes = item.GetNumStrikes();

                userPenalties = AppManager.AppManager.GetUserPenalties(penalties, userId);
                Console.WriteLine(userId + " ;; " + name + " ;; " + wallet + " ;; " + numStrikes + " ;; " + userPenalties.Count());
            }
        }

        static void showUserData()
        {
            bool done, parseOk;
            string s;
            int userId;
            IBettor bettor;
            List<IPenalty> bettorPenalties;
            do
            {
                Console.Write("Enter user id (or X to exit) > ");
                s = Console.ReadLine().ToLower();
                if (s.Equals("x"))
                {
                    done = true;
                }
                else
                {
                    parseOk = int.TryParse(s, out userId);
                    if (parseOk)
                    {
                        bettor = AppManager.AppManager.GetUserById(bettors, userId);
                        if (bettor == null)
                        {
                            Console.WriteLine("User with id " + userId + " not found.");
                        }
                        else
                        {
                            Console.WriteLine("user id = " + bettor.GetId());
                            Console.WriteLine("user name = " + bettor.GetName());
                            Console.WriteLine("wallet = " + bettor.GetWallet());
                            Console.WriteLine("num. strikes = " + bettor.GetNumStrikes());

                            bettorPenalties = AppManager.AppManager.GetUserPenalties(penalties, userId);
                            Console.WriteLine("num. penalties = " + bettorPenalties.Count());
                            if (bettorPenalties.Count() > 0)
                            {
                                Console.WriteLine("\npenalties data: ");
                                foreach (IPenalty item in bettorPenalties)
                                {
                                    Console.WriteLine(item.GetId() + " ;; " + item.GetGame().ToString() + " ;; " + item.GetPenaltyAmount());
                                }
                            }
                        }
                        done = true;
                    }
                    else
                    {
                        Console.WriteLine("*** Error, illegal user id value.\n");
                        Console.Beep();
                        done = true;
                    }
                }
            } while (!done);
        }

        static void showAvailableGames()
        {
            foreach (AbstractGame item in availableGames)
            {
                Console.WriteLine(item.ToString());
            }
        }

        static void addPenalty()
        {
            bool done, parseOk;

            int userId = -1;

            do
            {
                done = false;

                Console.Write("Enter user id (or X to exit) > ");
                string s = Console.ReadLine().ToLower();

                if (s.Equals("x"))
                {
                    done = true;
                    parseOk = false;
                }
                else
                {
                    parseOk = int.TryParse(s, out userId);
                    done = parseOk;
                }
            } while (!done);

            IBettor bettor = AppManager.AppManager.GetUserById(bettors, userId);
            if (bettor == null)
            {
                Console.WriteLine("Error, user with id " + userId + " not found.");
                return;
            }

            Random random = new Random();
            AbstractGame sport;
            IPenalty penalty;
            int sportIndex = random.Next(0, 3);
            switch (sportIndex)
            {
                case 0:
                    sport = new Basketball();
                    penalty = new BasketballPenalty(random.Next(0, 100000), bettor, PenaltySeverity.High);
                    break;
                case 1:
                    sport = new Football();
                    penalty = new FootballPenalty(random.Next(0, 100000), bettor, PenaltySeverity.Low);
                    break;
                case 2:
                    sport = new Racing();
                    penalty = new RacingPenalty(random.Next(0, 100000), bettor, PenaltySeverity.Medium);
                    break;
                default:
                    penalty = null;
                    break;
            }

            if (penalty == null)
            {
                Console.WriteLine(">>> Runtime error - unable to recover.");
                Console.WriteLine(">>> Press any key to recover.");
                Console.ReadKey();
            } else
            {
                penalty.ExecutePenalty();
                penalties.Add(penalty);
                Console.WriteLine("Penalty executed.");
            }
        }
    }
}