﻿Imports System.Web.Mvc

Namespace Controllers
    Public Class CurrentTime
        Inherits Controller

        ' GET: CurrentTime
        Function Index() As ActionResult
            Return View()
        End Function
    End Class
End Namespace