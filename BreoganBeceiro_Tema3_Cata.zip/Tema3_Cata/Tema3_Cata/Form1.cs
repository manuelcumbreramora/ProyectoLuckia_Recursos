﻿//BreoBeceiro:24/03/2020
//PLEXUS | Tema3

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tema3_Cata
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtNombre.Text = "";
            txtPassword.Text = "";
        }

        private void btnAcceder_Click(object sender, EventArgs e)
        {
            string nombre;
            string passw;

            nombre = txtNombre.Text;
            passw = txtPassword.Text;

            if(nombre.Length>3 && passw.Length >= 4)
            {
                Form2 Ingresado = new Form2();
                Form1 Acceso = new Form1();

                Acceso.Close();
                Ingresado.Show();
            }
        }
    }
}
