﻿using Login;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Base
{
    public partial class WebForm1 : System.Web.UI.Page
    {

        protected void Submit_Click(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Incio principal = new Incio();
            principal.comenzarPrograma(usuario.Text, password.Text);
            Response.Redirect("Apuesta.aspx");

        }
    }
}