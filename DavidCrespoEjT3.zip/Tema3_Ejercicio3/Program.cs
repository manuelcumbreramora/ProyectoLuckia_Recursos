﻿/*Implementa y diseña, una solución inventada, aplicando cada uno de los siguientes conceptos:
-Interfaces
-Clase estática
-Herencia

RESPETANDO Encapsulamiento y CREANDO Polimorfismo (tanto polimorfismo por herencia como polimorfismo por interfaz)
*/



using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema3_Ejercicio3
{
    class Program
    {
        static void Main(string[] args)
        {

            int eleccion;
            int costeReparacion;


            Propietario p = new Propietario();
            p.crearPropietario();

            //Elegir tipo de vehiculo, aunque no me gusta este metodo en la clase principal

            Console.WriteLine("Introduzca el tipo de vehiculo que quiere arreglar");
            Console.WriteLine("1: Turismo");
            Console.WriteLine("2: Furgoneta");
            Console.WriteLine("3: Moto");
            eleccion = Int32.Parse(Console.ReadLine());

            switch (eleccion)
                //Idealmente aqui implementaria los metodos para cada instancia creada
                //Pero no lo he hecho por falta de tiempo
            {
                case 1:
                    Turismo tur = new Turismo();
                    Console.WriteLine("Arreglando un turismo");
                    break;
                case 2:
                    Furgoneta fur = new Furgoneta();
                    Console.WriteLine("Arreglando una furgoneta");
                    break;
                case 3:
                    Moto mo = new Moto();
                    Console.WriteLine("Arreglando una moto");
                    break;
                default:
                    Console.WriteLine("Introduzca un valor válido");
                    break;

            }

            costeReparacion = CalcularPrecioReparacion.CalcularPrecioRep(2009);
            p.crearFactura("Fulanito", "Pérez López", costeReparacion);
            Console.ReadLine();








        }
    }
}
