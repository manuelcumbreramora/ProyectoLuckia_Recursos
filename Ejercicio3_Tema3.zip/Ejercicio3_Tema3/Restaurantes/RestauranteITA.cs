﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurantes
{
    public class RestauranteITA : Restaurante
    {
        public string nombre { get; set; }
        public string tipo { get; set; }
        public RestauranteITA()
        {
            this.nombre = "La albondiga de Tino";
            this.tipo = "Italiano";
        }
        public override void visita()
        {
            Console.WriteLine("Usted ha visitado el restaurante " + this.nombre);
        }
    }
}
