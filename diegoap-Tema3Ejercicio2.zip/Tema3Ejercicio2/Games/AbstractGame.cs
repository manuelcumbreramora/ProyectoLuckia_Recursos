﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Games
{
    public abstract class AbstractGame
    {
        public enum AvailableGame { Football = 0, Basketball = 10, Racing = 20};

        public AvailableGame Game { get; }

        public AbstractGame(AvailableGame game)
        {
            this.Game = game;
        }
    }
}
