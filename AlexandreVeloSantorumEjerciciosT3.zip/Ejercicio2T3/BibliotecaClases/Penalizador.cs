﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BibliotecaClases
{
    public abstract class Penalizador
    {
        public abstract int PenalizarFutbol();
        public abstract int PenalizarBoleibal();
        public abstract int PenalizarBalonmano();
        public virtual void AvisarPenalizacion()
        {
            Console.WriteLine("Se te va a penalizar en tú monedero");
        }
    }
}
