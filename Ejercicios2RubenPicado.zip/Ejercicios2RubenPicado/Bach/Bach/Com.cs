﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.IO;


namespace Bach
{
    partial class Com : ServiceBase
    {
        bool repetir = false;
        public Com()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            lapso.Start();
        }

        protected override void OnStop()
        {
            lapso.Stop();
        }

        private void lapso_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            if (repetir) return;

            try
            {
                repetir = true;
                EventLog.WriteEntry("Se inicio el copiado", EventLogEntryType.Information);
                string Ocarpeta1 = ConfigurationSettings.AppSettings["Ocarpeta1"].ToString();
                string Dcarpeta2 = ConfigurationSettings.AppSettings["Dcarpeta2"].ToString();

                DirectoryInfo directorio = new DirectoryInfo(Ocarpeta1);

                foreach (var doc in directorio.GetFiles())
                {
                    if (File.Exists(Ocarpeta1 + doc.Name))
                    {
                        File.SetAttributes(Ocarpeta1 + doc.Name, FileAttributes.Normal);
                        File.Delete(Ocarpeta1 + doc.Name);
                    }


                    File.Copy(Dcarpeta2 + doc.Name, Dcarpeta2 + doc.Name);
                    File.SetAttributes(Ocarpeta1 + doc.Name, FileAttributes.Normal);

                    if (File.Exists(Ocarpeta1 + doc.Name))
                        EventLog.WriteEntry(" se copio el archivo", EventLogEntryType.Information);
                    else EventLog.WriteEntry(" no se copio el archivo", EventLogEntryType.Information);
                }

            }
            catch (Exception mensaje)
            {
                EventLog.WriteEntry(mensaje.Message, EventLogEntryType.Error);
            }

            repetir = false;

        }
    }
}
